import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Navigation from "@/components/navigation";
import Dashboard from "@/pages/dashboard";
import Timetable from "@/pages/timetable";
import Teachers from "@/pages/teachers";
import Classrooms from "@/pages/classrooms";
import Rules from "@/pages/rules";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Navigation />
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/timetable" component={Timetable} />
        <Route path="/teachers" component={Teachers} />
        <Route path="/classrooms" component={Classrooms} />
        <Route path="/rules" component={Rules} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
