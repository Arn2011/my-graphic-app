import { useQuery } from "@tanstack/react-query";
import { Users, MapPin } from "lucide-react";
import type { Teacher, Classroom } from "@shared/schema";

interface AvailableResourcesProps {
  schoolId: number;
}

export default function AvailableResources({ schoolId }: AvailableResourcesProps) {
  const { data: teachers } = useQuery({
    queryKey: [`/api/schools/${schoolId}/teachers`],
  });

  const { data: classrooms } = useQuery({
    queryKey: [`/api/schools/${schoolId}/classrooms`],
  });

  // For simplicity, showing all teachers and classrooms as available
  // In a real implementation, this would filter based on current time slot
  const availableTeachers = teachers?.slice(0, 5) || [];
  const availableClassrooms = classrooms?.slice(0, 5) || [];

  return (
    <div className="bubble-card rounded-3xl p-6 shadow-xl">
      <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
        <Users className="text-green-500 mr-3" size={20} />
        Available Now
      </h3>
      
      <div className="space-y-4">
        <div>
          <h4 className="font-semibold text-gray-700 text-sm mb-3">Teachers</h4>
          <div className="space-y-2">
            {availableTeachers.length === 0 ? (
              <p className="text-sm text-gray-500">No teachers available</p>
            ) : (
              availableTeachers.map((teacher: Teacher) => (
                <div
                  key={teacher.id}
                  className="draggable-item bg-gradient-to-r from-green-100 to-green-200 border border-green-300 rounded-xl p-3 cursor-grab hover:shadow-md transition-shadow"
                  draggable
                >
                  <div className="font-medium text-green-800">{teacher.name}</div>
                  <div className="text-xs text-green-600">
                    {teacher.subjects?.join(', ') || 'No subjects assigned'}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
        
        <div>
          <h4 className="font-semibold text-gray-700 text-sm mb-3">Classrooms</h4>
          <div className="space-y-2">
            {availableClassrooms.length === 0 ? (
              <p className="text-sm text-gray-500">No classrooms available</p>
            ) : (
              availableClassrooms.map((classroom: Classroom) => (
                <div
                  key={classroom.id}
                  className="bg-gradient-to-r from-yellow-100 to-yellow-200 border border-yellow-300 rounded-xl p-3 hover:shadow-md transition-shadow"
                >
                  <div className="font-medium text-yellow-800 flex items-center">
                    <MapPin size={14} className="mr-1" />
                    {classroom.name}
                  </div>
                  <div className="text-xs text-yellow-600">
                    Capacity: {classroom.capacity} | Type: {classroom.type || 'General'}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
