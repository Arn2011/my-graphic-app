import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, X, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ConflictWithDetails } from "@shared/schema";

interface ConflictPanelProps {
  conflicts: ConflictWithDetails[];
}

export default function ConflictPanel({ conflicts }: ConflictPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const resolveConflictMutation = useMutation({
    mutationFn: async (conflictId: number) => {
      return await apiRequest('POST', `/api/conflicts/${conflictId}/resolve`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/schools'] });
      toast({
        title: "Conflict resolved",
        description: "The conflict has been resolved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to resolve conflict.",
        variant: "destructive",
      });
    },
  });

  const handleResolveConflict = (conflictId: number) => {
    resolveConflictMutation.mutate(conflictId);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'border-red-400 bg-red-50';
      case 'medium': return 'border-yellow-400 bg-yellow-50';
      case 'low': return 'border-blue-400 bg-blue-50';
      default: return 'border-red-400 bg-red-50';
    }
  };

  return (
    <div className="bubble-card rounded-3xl p-6 shadow-xl">
      <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
        <AlertTriangle className="text-red-500 mr-3" size={20} />
        Schedule Conflicts
      </h3>
      
      {conflicts.length === 0 ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="text-green-500" size={24} />
          </div>
          <p className="text-gray-500">No conflicts detected!</p>
          <p className="text-sm text-gray-400 mt-1">Your schedule is looking good.</p>
        </div>
      ) : (
        <>
          <div className="space-y-3 mb-4 max-h-96 overflow-y-auto">
            {conflicts.map((conflict) => (
              <div
                key={conflict.id}
                className={`border rounded-2xl p-4 ${getSeverityColor(conflict.severity)}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-700 capitalize">
                      {conflict.type.replace(/_/g, ' ')}
                    </h4>
                    <p className="text-sm text-gray-600 mt-1">{conflict.description}</p>
                    <div className="flex items-center mt-2 text-xs text-gray-500">
                      <Clock size={12} />
                      <span className="ml-1">
                        {new Date(conflict.createdAt!).toLocaleDateString()}
                      </span>
                      <span className="ml-3 px-2 py-1 bg-gray-200 rounded-full text-xs font-medium">
                        {conflict.severity}
                      </span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-600 hover:text-gray-800 ml-3"
                    onClick={() => handleResolveConflict(conflict.id)}
                    disabled={resolveConflictMutation.isPending}
                  >
                    <X size={16} />
                  </Button>
                </div>
              </div>
            ))}
          </div>
          
          <Button 
            className="w-full bg-gradient-to-r from-red-400 to-red-600 text-white rounded-2xl font-medium hover:shadow-lg transition-shadow"
            disabled={resolveConflictMutation.isPending}
          >
            Auto-Resolve All
          </Button>
        </>
      )}
    </div>
  );
}
