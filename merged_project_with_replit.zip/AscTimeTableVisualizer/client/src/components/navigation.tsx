import { Link, useLocation } from "wouter";
import { CalendarDays, LayoutDashboard, Calendar, User, MapPin, Settings, Bell, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: "Dashboard", icon: LayoutDashboard },
    { path: "/timetable", label: "Timetable", icon: Calendar },
    { path: "/teachers", label: "Teachers", icon: User },
    { path: "/classrooms", label: "Classrooms", icon: MapPin },
    { path: "/rules", label: "Rules", icon: Settings },
  ];

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <nav className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 gradient-bg rounded-full flex items-center justify-center">
              <CalendarDays className="text-white" size={20} />
            </div>
            <h1 className="text-xl font-bold text-gray-800">ASC Timetable</h1>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.path} href={item.path}>
                  <Button
                    variant={isActive(item.path) ? "default" : "ghost"}
                    className={`
                      rounded-2xl px-4 py-2 text-sm font-medium transition-all duration-200
                      ${isActive(item.path) 
                        ? "gradient-bg text-white shadow-lg" 
                        : "text-gray-700 hover:text-gray-900 hover:bg-gray-100"
                      }
                    `}
                  >
                    <Icon size={16} className="mr-2" />
                    {item.label}
                  </Button>
                </Link>
              );
            })}
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="rounded-full">
              <HelpCircle size={20} />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full">
              <Bell size={20} />
            </Button>
            <Button size="icon" className="gradient-bg rounded-full text-white">
              <User size={20} />
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}