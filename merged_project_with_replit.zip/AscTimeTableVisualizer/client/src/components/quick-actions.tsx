import { useState } from "react";
import { UserPlus, DoorOpen, Settings, Download, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertTeacherSchema, insertClassroomSchema } from "@shared/schema";
import { z } from "zod";

interface QuickActionsProps {
  onCreateRule: () => void;
  schoolId: number;
}

export default function QuickActions({ onCreateRule, schoolId }: QuickActionsProps) {
  const [isTeacherDialogOpen, setIsTeacherDialogOpen] = useState(false);
  const [isClassroomDialogOpen, setIsClassroomDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Teacher form
  const teacherForm = useForm({
    resolver: zodResolver(insertTeacherSchema.extend({
      subjects: z.string().transform(s => s.split(',').map(sub => sub.trim())).optional(),
    })),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      subjects: "",
    },
  });

  // Classroom form
  const classroomForm = useForm({
    resolver: zodResolver(insertClassroomSchema.extend({
      equipment: z.string().transform(s => s.split(',').map(eq => eq.trim())).optional(),
    })),
    defaultValues: {
      name: "",
      capacity: 30,
      type: "",
      equipment: "",
    },
  });

  const createTeacherMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('POST', `/api/schools/${schoolId}/teachers`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/schools/${schoolId}/teachers`] });
      teacherForm.reset();
      setIsTeacherDialogOpen(false);
      toast({
        title: "Teacher added",
        description: "The teacher has been added successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add teacher.",
        variant: "destructive",
      });
    },
  });

  const createClassroomMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('POST', `/api/schools/${schoolId}/classrooms`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/schools/${schoolId}/classrooms`] });
      classroomForm.reset();
      setIsClassroomDialogOpen(false);
      toast({
        title: "Classroom added",
        description: "The classroom has been added successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add classroom.",
        variant: "destructive",
      });
    },
  });

  const handleTeacherSubmit = (data: any) => {
    createTeacherMutation.mutate({
      ...data,
      schoolId,
      subjects: typeof data.subjects === 'string' ? data.subjects.split(',').map((s: string) => s.trim()) : [],
    });
  };

  const handleClassroomSubmit = (data: any) => {
    createClassroomMutation.mutate({
      ...data,
      schoolId,
      equipment: typeof data.equipment === 'string' ? data.equipment.split(',').map((e: string) => e.trim()) : [],
    });
  };

  const handleExportSchedule = () => {
    toast({
      title: "Export started",
      description: "Your schedule export will be ready shortly.",
    });
  };

  return (
    <div className="bubble-card rounded-3xl p-6 shadow-xl">
      <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
        <Plus className="text-yellow-500 mr-3" size={20} />
        Quick Actions
      </h3>
      
      <div className="space-y-3">
        <Dialog open={isTeacherDialogOpen} onOpenChange={setIsTeacherDialogOpen}>
          <DialogTrigger asChild>
            <Button className="w-full bg-gradient-to-r from-blue-400 to-blue-600 text-white rounded-2xl font-medium hover:shadow-lg transition-shadow flex items-center justify-center">
              <UserPlus size={16} className="mr-2" />
              Add Teacher
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Teacher</DialogTitle>
            </DialogHeader>
            <Form {...teacherForm}>
              <form onSubmit={teacherForm.handleSubmit(handleTeacherSubmit)} className="space-y-4">
                <FormField
                  control={teacherForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Teacher's full name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={teacherForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="teacher@school.edu" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={teacherForm.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone</FormLabel>
                      <FormControl>
                        <Input placeholder="Phone number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={teacherForm.control}
                  name="subjects"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subjects (comma-separated)</FormLabel>
                      <FormControl>
                        <Input placeholder="Mathematics, Physics, Chemistry" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsTeacherDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="gradient-bg text-white"
                    disabled={createTeacherMutation.isPending}
                  >
                    Add Teacher
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
        
        <Dialog open={isClassroomDialogOpen} onOpenChange={setIsClassroomDialogOpen}>
          <DialogTrigger asChild>
            <Button className="w-full bg-gradient-to-r from-green-400 to-green-600 text-white rounded-2xl font-medium hover:shadow-lg transition-shadow flex items-center justify-center">
              <DoorOpen size={16} className="mr-2" />
              Add Classroom
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Classroom</DialogTitle>
            </DialogHeader>
            <Form {...classroomForm}>
              <form onSubmit={classroomForm.handleSubmit(handleClassroomSubmit)} className="space-y-4">
                <FormField
                  control={classroomForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Room 101, Lab A, etc." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={classroomForm.control}
                  name="capacity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Capacity</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="30" {...field} onChange={e => field.onChange(parseInt(e.target.value))} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={classroomForm.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <FormControl>
                        <Input placeholder="Classroom, Lab, Gym, etc." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={classroomForm.control}
                  name="equipment"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Equipment (comma-separated)</FormLabel>
                      <FormControl>
                        <Input placeholder="Projector, Whiteboard, Computers" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsClassroomDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="gradient-bg text-white"
                    disabled={createClassroomMutation.isPending}
                  >
                    Add Classroom
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
        
        <Button 
          className="w-full bg-gradient-to-r from-purple-400 to-purple-600 text-white rounded-2xl font-medium hover:shadow-lg transition-shadow flex items-center justify-center"
          onClick={onCreateRule}
        >
          <Settings size={16} className="mr-2" />
          Create Rule
        </Button>
        
        <Button 
          className="w-full bg-gradient-to-r from-orange-400 to-orange-600 text-white rounded-2xl font-medium hover:shadow-lg transition-shadow flex items-center justify-center"
          onClick={handleExportSchedule}
        >
          <Download size={16} className="mr-2" />
          Export Schedule
        </Button>
      </div>
    </div>
  );
}
