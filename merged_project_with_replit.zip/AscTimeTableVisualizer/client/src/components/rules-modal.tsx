import { useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  schoolId: number;
}

interface RuleCondition {
  field: string;
  operator: string;
  value: string;
}

interface RuleAction {
  type: string;
  parameters: string;
}

export default function RulesModal({ isOpen, onClose, schoolId }: RulesModalProps) {
  const [ruleName, setRuleName] = useState("");
  const [ruleDescription, setRuleDescription] = useState("");
  const [condition, setCondition] = useState<RuleCondition>({
    field: "",
    operator: "",
    value: "",
  });
  const [action, setAction] = useState<RuleAction>({
    type: "",
    parameters: "",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createRuleMutation = useMutation({
    mutationFn: async (ruleData: any) => {
      return await apiRequest('POST', `/api/schools/${schoolId}/rules`, ruleData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/schools/${schoolId}/rules`] });
      handleClose();
      toast({
        title: "Rule created",
        description: "The scheduling rule has been created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create rule.",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setRuleName("");
    setRuleDescription("");
    setCondition({ field: "", operator: "", value: "" });
    setAction({ type: "", parameters: "" });
    onClose();
  };

  const handleSaveRule = () => {
    if (!ruleName || !condition.field || !condition.operator || !action.type) {
      toast({
        title: "Invalid rule",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const ruleData = {
      name: ruleName,
      description: ruleDescription,
      condition: JSON.stringify(condition),
      action: JSON.stringify(action),
    };

    createRuleMutation.mutate(ruleData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Custom Scheduling Rules
            <Button variant="ghost" size="icon" onClick={handleClose}>
              <X size={20} />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="ruleName">Rule Name</Label>
              <Input
                id="ruleName"
                placeholder="Enter rule name"
                value={ruleName}
                onChange={(e) => setRuleName(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="ruleDescription">Description (optional)</Label>
              <Textarea
                id="ruleDescription"
                placeholder="Describe what this rule does"
                value={ruleDescription}
                onChange={(e) => setRuleDescription(e.target.value)}
              />
            </div>
          </div>

          <div className="bg-gray-50 rounded-2xl p-4">
            <h4 className="font-semibold text-gray-700 mb-3">If-Then Rule Builder</h4>
            
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label>If</Label>
                  <Select value={condition.field} onValueChange={(value) => setCondition({...condition, field: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select field" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="teacher">Teacher</SelectItem>
                      <SelectItem value="classroom">Classroom</SelectItem>
                      <SelectItem value="time">Time</SelectItem>
                      <SelectItem value="subject">Subject</SelectItem>
                      <SelectItem value="class">Class</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label>Condition</Label>
                  <Select value={condition.operator} onValueChange={(value) => setCondition({...condition, operator: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="is_scheduled">is scheduled</SelectItem>
                      <SelectItem value="is_not_available">is not available</SelectItem>
                      <SelectItem value="has_conflict">has conflict</SelectItem>
                      <SelectItem value="equals">equals</SelectItem>
                      <SelectItem value="contains">contains</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label>Value</Label>
                  <Input
                    placeholder="Enter value"
                    value={condition.value}
                    onChange={(e) => setCondition({...condition, value: e.target.value})}
                  />
                </div>
              </div>
              
              <div className="text-center">
                <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
                  THEN
                </span>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Action</Label>
                  <Select value={action.type} onValueChange={(value) => setAction({...action, type: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select action" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="block_scheduling">Block scheduling</SelectItem>
                      <SelectItem value="send_alert">Send alert</SelectItem>
                      <SelectItem value="auto_resolve">Auto-resolve</SelectItem>
                      <SelectItem value="suggest_alternative">Suggest alternative</SelectItem>
                      <SelectItem value="require_approval">Require approval</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label>Parameters</Label>
                  <Input
                    placeholder="Additional parameters"
                    value={action.parameters}
                    onChange={(e) => setAction({...action, parameters: e.target.value})}
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3">
            <Button variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button 
              className="gradient-bg text-white" 
              onClick={handleSaveRule}
              disabled={createRuleMutation.isPending}
            >
              Save Rule
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
