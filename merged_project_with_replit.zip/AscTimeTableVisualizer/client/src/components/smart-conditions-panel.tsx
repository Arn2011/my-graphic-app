import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Brain, Plus, Trash2, Save, Lightbulb, Settings2, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Rule } from "@shared/schema";

interface SmartConditionsPanelProps {
  schoolId: number;
}

interface ConditionRule {
  id: string;
  name: string;
  description: string;
  priority: number;
  isActive: boolean;
  conditions: {
    field: string;
    operator: string;
    value: string;
  }[];
  actions: {
    type: string;
    message: string;
  }[];
}

const conditionFields = [
  { value: 'teacher', label: 'Teacher', icon: '👨‍🏫' },
  { value: 'classroom', label: 'Classroom', icon: '🏛️' },
  { value: 'subject', label: 'Subject', icon: '📚' },
  { value: 'timeSlot', label: 'Time Slot', icon: '⏰' },
  { value: 'dayOfWeek', label: 'Day of Week', icon: '📅' },
  { value: 'classSize', label: 'Class Size', icon: '👥' },
];

const conditionOperators = [
  { value: 'equals', label: 'equals' },
  { value: 'not_equals', label: 'does not equal' },
  { value: 'contains', label: 'contains' },
  { value: 'is_available', label: 'is available' },
  { value: 'is_not_available', label: 'is not available' },
  { value: 'has_conflict', label: 'has conflict' },
  { value: 'exceeds', label: 'exceeds' },
  { value: 'is_less_than', label: 'is less than' },
];

const actionTypes = [
  { value: 'block', label: 'Block Scheduling', icon: '🚫', color: 'bg-red-500' },
  { value: 'warn', label: 'Show Warning', icon: '⚠️', color: 'bg-yellow-500' },
  { value: 'suggest', label: 'Suggest Alternative', icon: '💡', color: 'bg-blue-500' },
  { value: 'auto_resolve', label: 'Auto-Resolve', icon: '🔧', color: 'bg-green-500' },
  { value: 'require_approval', label: 'Require Approval', icon: '✋', color: 'bg-purple-500' },
];

const presetRules = [
  {
    name: "No Teacher Double Booking",
    description: "Prevent teachers from being scheduled in multiple classes at the same time",
    conditions: [{ field: 'teacher', operator: 'has_conflict', value: 'same_time_slot' }],
    actions: [{ type: 'block', message: 'Teacher is already scheduled for another class at this time' }],
  },
  {
    name: "Classroom Capacity Check",
    description: "Ensure class size doesn't exceed classroom capacity",
    conditions: [{ field: 'classSize', operator: 'exceeds', value: 'classroom_capacity' }],
    actions: [{ type: 'warn', message: 'Class size exceeds classroom capacity' }],
  },
  {
    name: "Science Lab Requirements",
    description: "Science subjects should be scheduled in appropriate labs",
    conditions: [{ field: 'subject', operator: 'contains', value: 'Science|Chemistry|Physics|Biology' }],
    actions: [{ type: 'suggest', message: 'Consider scheduling in a science laboratory' }],
  },
];

export default function SmartConditionsPanel({ schoolId }: SmartConditionsPanelProps) {
  const [rules, setRules] = useState<ConditionRule[]>([]);
  const [newRule, setNewRule] = useState<ConditionRule>({
    id: '',
    name: '',
    description: '',
    priority: 5,
    isActive: true,
    conditions: [{ field: '', operator: '', value: '' }],
    actions: [{ type: '', message: '' }],
  });
  const [showRuleBuilder, setShowRuleBuilder] = useState(false);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: existingRules } = useQuery({
    queryKey: [`/api/schools/${schoolId}/rules`],
  });

  const createRuleMutation = useMutation({
    mutationFn: async (ruleData: any) => {
      return await apiRequest('POST', `/api/schools/${schoolId}/rules`, ruleData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/schools/${schoolId}/rules`] });
      setShowRuleBuilder(false);
      resetNewRule();
      toast({
        title: "Smart rule created!",
        description: "Your scheduling rule is now active and monitoring schedules.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create rule. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetNewRule = () => {
    setNewRule({
      id: '',
      name: '',
      description: '',
      priority: 5,
      isActive: true,
      conditions: [{ field: '', operator: '', value: '' }],
      actions: [{ type: '', message: '' }],
    });
  };

  const addCondition = () => {
    setNewRule(prev => ({
      ...prev,
      conditions: [...prev.conditions, { field: '', operator: '', value: '' }]
    }));
  };

  const removeCondition = (index: number) => {
    setNewRule(prev => ({
      ...prev,
      conditions: prev.conditions.filter((_, i) => i !== index)
    }));
  };

  const updateCondition = (index: number, field: keyof typeof newRule.conditions[0], value: string) => {
    setNewRule(prev => ({
      ...prev,
      conditions: prev.conditions.map((condition, i) => 
        i === index ? { ...condition, [field]: value } : condition
      )
    }));
  };

  const addAction = () => {
    setNewRule(prev => ({
      ...prev,
      actions: [...prev.actions, { type: '', message: '' }]
    }));
  };

  const removeAction = (index: number) => {
    setNewRule(prev => ({
      ...prev,
      actions: prev.actions.filter((_, i) => i !== index)
    }));
  };

  const updateAction = (index: number, field: keyof typeof newRule.actions[0], value: string) => {
    setNewRule(prev => ({
      ...prev,
      actions: prev.actions.map((action, i) => 
        i === index ? { ...action, [field]: value } : action
      )
    }));
  };

  const applyPresetRule = (preset: typeof presetRules[0]) => {
    setNewRule(prev => ({
      ...prev,
      name: preset.name,
      description: preset.description,
      conditions: preset.conditions,
      actions: preset.actions,
    }));
    setShowRuleBuilder(true);
  };

  const saveRule = () => {
    if (!newRule.name || newRule.conditions.some(c => !c.field || !c.operator) || newRule.actions.some(a => !a.type)) {
      toast({
        title: "Incomplete rule",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const ruleData = {
      name: newRule.name,
      description: newRule.description,
      condition: JSON.stringify(newRule.conditions),
      action: JSON.stringify(newRule.actions),
      priority: newRule.priority,
      isActive: newRule.isActive,
    };

    createRuleMutation.mutate(ruleData);
  };

  return (
    <div className="bubble-card rounded-3xl p-6 shadow-xl">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-800 flex items-center">
          <Brain className="text-purple-500 mr-3" size={24} />
          Smart Conditions
        </h3>
        <Button
          onClick={() => setShowRuleBuilder(!showRuleBuilder)}
          className="gradient-bg text-white rounded-2xl"
          size="sm"
        >
          <Plus size={16} className="mr-1" />
          New Rule
        </Button>
      </div>

      {/* Quick Preset Rules */}
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center">
          <Lightbulb size={16} className="mr-2 text-yellow-500" />
          Quick Setup Presets
        </h4>
        <div className="grid grid-cols-1 gap-3">
          {presetRules.map((preset, index) => (
            <div
              key={index}
              className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-2xl p-4 hover:shadow-md transition-all cursor-pointer"
              onClick={() => applyPresetRule(preset)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h5 className="font-medium text-gray-800">{preset.name}</h5>
                  <p className="text-sm text-gray-600 mt-1">{preset.description}</p>
                </div>
                <Button variant="ghost" size="sm" className="text-blue-600">
                  Use This
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Rules */}
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center">
          <Target size={16} className="mr-2 text-green-500" />
          Active Rules ({Array.isArray(existingRules) ? existingRules.length : 0})
        </h4>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {!existingRules || !Array.isArray(existingRules) || existingRules.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">
              No active rules yet. Create your first rule above!
            </p>
          ) : (
            existingRules.map((rule: Rule) => (
              <div
                key={rule.id}
                className="bg-white border border-gray-200 rounded-xl p-3 flex items-center justify-between"
              >
                <div>
                  <h6 className="font-medium text-gray-800">{rule.name}</h6>
                  <p className="text-xs text-gray-500">{rule.description}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant={rule.isActive ? "default" : "secondary"}>
                    {rule.isActive ? "Active" : "Inactive"}
                  </Badge>
                  <Button variant="ghost" size="sm">
                    <Settings2 size={14} />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Rule Builder */}
      {showRuleBuilder && (
        <Card className="border-2 border-purple-200 rounded-2xl">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg text-purple-800">Create New Rule</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Rule Basic Info */}
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="ruleName">Rule Name *</Label>
                <Input
                  id="ruleName"
                  placeholder="e.g., No Teacher Conflicts"
                  value={newRule.name}
                  onChange={(e) => setNewRule(prev => ({ ...prev, name: e.target.value }))}
                  className="rounded-xl"
                />
              </div>
              <div>
                <Label htmlFor="ruleDesc">Description</Label>
                <Textarea
                  id="ruleDesc"
                  placeholder="Explain what this rule does..."
                  value={newRule.description}
                  onChange={(e) => setNewRule(prev => ({ ...prev, description: e.target.value }))}
                  className="rounded-xl"
                  rows={2}
                />
              </div>
            </div>

            {/* Conditions */}
            <div>
              <Label className="flex items-center mb-3">
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-lg text-sm font-medium mr-2">
                  IF
                </span>
                Conditions
              </Label>
              {newRule.conditions.map((condition, index) => (
                <div key={index} className="flex items-center space-x-2 mb-2">
                  <Select value={condition.field} onValueChange={(value) => updateCondition(index, 'field', value)}>
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Select field" />
                    </SelectTrigger>
                    <SelectContent>
                      {conditionFields.map(field => (
                        <SelectItem key={field.value} value={field.value}>
                          <span className="flex items-center">
                            <span className="mr-2">{field.icon}</span>
                            {field.label}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select value={condition.operator} onValueChange={(value) => updateCondition(index, 'operator', value)}>
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      {conditionOperators.map(op => (
                        <SelectItem key={op.value} value={op.value}>{op.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Input
                    placeholder="Value"
                    value={condition.value}
                    onChange={(e) => updateCondition(index, 'value', e.target.value)}
                    className="rounded-xl"
                  />
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeCondition(index)}
                    disabled={newRule.conditions.length === 1}
                  >
                    <Trash2 size={16} />
                  </Button>
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={addCondition} className="rounded-xl">
                <Plus size={16} className="mr-1" />
                Add Condition
              </Button>
            </div>

            {/* Actions */}
            <div>
              <Label className="flex items-center mb-3">
                <span className="bg-green-100 text-green-800 px-2 py-1 rounded-lg text-sm font-medium mr-2">
                  THEN
                </span>
                Actions
              </Label>
              {newRule.actions.map((action, index) => (
                <div key={index} className="flex items-center space-x-2 mb-2">
                  <Select value={action.type} onValueChange={(value) => updateAction(index, 'type', value)}>
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Select action" />
                    </SelectTrigger>
                    <SelectContent>
                      {actionTypes.map(actionType => (
                        <SelectItem key={actionType.value} value={actionType.value}>
                          <span className="flex items-center">
                            <span className="mr-2">{actionType.icon}</span>
                            {actionType.label}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Input
                    placeholder="Custom message (optional)"
                    value={action.message}
                    onChange={(e) => updateAction(index, 'message', e.target.value)}
                    className="rounded-xl flex-1"
                  />
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeAction(index)}
                    disabled={newRule.actions.length === 1}
                  >
                    <Trash2 size={16} />
                  </Button>
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={addAction} className="rounded-xl">
                <Plus size={16} className="mr-1" />
                Add Action
              </Button>
            </div>

            {/* Rule Settings */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t">
              <div>
                <Label htmlFor="priority">Priority (1-10)</Label>
                <Input
                  id="priority"
                  type="number"
                  min="1"
                  max="10"
                  value={newRule.priority}
                  onChange={(e) => setNewRule(prev => ({ ...prev, priority: parseInt(e.target.value) }))}
                  className="rounded-xl"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={newRule.isActive}
                  onCheckedChange={(checked) => setNewRule(prev => ({ ...prev, isActive: checked }))}
                />
                <Label>Activate immediately</Label>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="outline" onClick={() => setShowRuleBuilder(false)} className="rounded-xl">
                Cancel
              </Button>
              <Button onClick={saveRule} className="gradient-bg text-white rounded-xl" disabled={createRuleMutation.isPending}>
                <Save size={16} className="mr-1" />
                Save Rule
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}