import { Presentation, Users, AlertTriangle, PieChart } from "lucide-react";

interface StatsCardsProps {
  stats?: {
    totalClasses: number;
    activeTeachers: number;
    conflicts: number;
    completion: number;
  };
}

export default function StatsCards({ stats }: StatsCardsProps) {
  if (!stats) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bubble-card rounded-3xl p-6 shadow-lg animate-pulse">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-24"></div>
                <div className="h-8 bg-gray-200 rounded w-16"></div>
              </div>
              <div className="w-12 h-12 bg-gray-200 rounded-2xl"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <div className="bubble-card rounded-3xl p-6 shadow-lg hover:shadow-xl transition-shadow animate-float">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-600 text-sm font-medium">Total Classes</p>
            <p className="text-2xl font-bold text-gray-800">{stats.totalClasses}</p>
          </div>
          <div className="w-12 h-12 bg-gradient-to-r from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center">
            <Presentation className="text-white" size={24} />
          </div>
        </div>
      </div>
      
      <div className="bubble-card rounded-3xl p-6 shadow-lg hover:shadow-xl transition-shadow animate-float-delay-1">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-600 text-sm font-medium">Active Teachers</p>
            <p className="text-2xl font-bold text-gray-800">{stats.activeTeachers}</p>
          </div>
          <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-green-600 rounded-2xl flex items-center justify-center">
            <Users className="text-white" size={24} />
          </div>
        </div>
      </div>
      
      <div className="bubble-card rounded-3xl p-6 shadow-lg hover:shadow-xl transition-shadow animate-float-delay-2">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-600 text-sm font-medium">Conflicts</p>
            <p className="text-2xl font-bold text-red-500">{stats.conflicts}</p>
          </div>
          <div className="w-12 h-12 bg-gradient-to-r from-red-400 to-red-600 rounded-2xl flex items-center justify-center animate-pulse">
            <AlertTriangle className="text-white" size={24} />
          </div>
        </div>
      </div>
      
      <div className="bubble-card rounded-3xl p-6 shadow-lg hover:shadow-xl transition-shadow animate-float-delay-3">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-600 text-sm font-medium">Completion</p>
            <p className="text-2xl font-bold text-gray-800">{stats.completion}%</p>
          </div>
          <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-purple-600 rounded-2xl flex items-center justify-center">
            <PieChart className="text-white" size={24} />
          </div>
        </div>
      </div>
    </div>
  );
}
