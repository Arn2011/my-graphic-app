import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, Clock, User, MapPin, BookOpen, Info, Plus } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { ScheduleWithDetails, TimeSlot } from "@shared/schema";

interface TimetableGridProps {
  schedules: ScheduleWithDetails[];
  timeSlots: TimeSlot[];
  selectedClassId: number;
  schoolId: number;
}

const weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

export default function TimetableGrid({ schedules, timeSlots, selectedClassId, schoolId }: TimetableGridProps) {
  const [draggedSchedule, setDraggedSchedule] = useState<ScheduleWithDetails | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateScheduleMutation = useMutation({
    mutationFn: async ({ scheduleId, timeSlotId, dayOfWeek }: { scheduleId: number; timeSlotId: number; dayOfWeek: number }) => {
      return await apiRequest('PUT', `/api/schedules/${scheduleId}`, {
        timeSlotId,
        dayOfWeek,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/classes/${selectedClassId}/schedules`] });
      queryClient.invalidateQueries({ queryKey: [`/api/schools/${schoolId}/conflicts`] });
      toast({
        title: "Schedule updated",
        description: "The schedule has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update schedule.",
        variant: "destructive",
      });
    },
  });

  const handleDragStart = (e: React.DragEvent, schedule: ScheduleWithDetails) => {
    setDraggedSchedule(schedule);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    e.currentTarget.classList.add('drag-over');
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.currentTarget.classList.remove('drag-over');
  };

  const handleDrop = (e: React.DragEvent, timeSlotId: number, dayOfWeek: number) => {
    e.preventDefault();
    e.currentTarget.classList.remove('drag-over');
    
    if (draggedSchedule && (draggedSchedule.timeSlotId !== timeSlotId || draggedSchedule.dayOfWeek !== dayOfWeek)) {
      updateScheduleMutation.mutate({
        scheduleId: draggedSchedule!.id,
        timeSlotId,
        dayOfWeek,
      });
    }
    
    setDraggedSchedule(null);
  };

  const getScheduleForSlot = (timeSlotId: number, dayOfWeek: number) => {
    return schedules.find(s => s.timeSlotId === timeSlotId && s.dayOfWeek === dayOfWeek);
  };

  const getSubjectClass = (subjectName: string) => {
    const name = subjectName.toLowerCase();
    if (name.includes('math')) return 'math';
    if (name.includes('science')) return 'science';
    if (name.includes('english')) return 'english';
    if (name.includes('history')) return 'history';
    if (name.includes('art')) return 'art';
    if (name.includes('music')) return 'music';
    if (name.includes('pe') || name.includes('physical')) return 'pe';
    return 'math'; // default
  };

  if (!timeSlots || timeSlots.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Clock className="text-blue-500" size={24} />
        </div>
        <h3 className="text-lg font-semibold text-gray-800 mb-2">No Time Slots Configured</h3>
        <p className="text-gray-500 mb-4">Create time slots to start building your timetable.</p>
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-left max-w-md mx-auto">
          <h4 className="font-semibold text-blue-800 text-sm mb-2">Quick Setup:</h4>
          <ol className="text-sm text-blue-700 space-y-1">
            <li>1. Use Quick Actions to add time slots</li>
            <li>2. Add teachers and classrooms</li>
            <li>3. Start creating your schedule!</li>
          </ol>
        </div>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <div className="min-w-full">
        {/* Header Row */}
        <div className="grid grid-cols-6 gap-2 mb-4">
          <div className="text-center font-medium text-gray-600 py-3"></div>
          {weekdays.map((day, index) => (
            <div key={day} className="text-center font-medium text-gray-600 py-3 bg-gray-50 rounded-2xl">
              {day}
            </div>
          ))}
        </div>
        
        {/* Time Slots */}
        {timeSlots.map((timeSlot) => (
          <div key={timeSlot.id} className="grid grid-cols-6 gap-2 mb-3">
            <div className="flex items-center justify-center font-medium text-gray-700 bg-gray-100 rounded-2xl py-4">
              {timeSlot.startTime} - {timeSlot.endTime}
            </div>
            
            {weekdays.map((day, dayIndex) => {
              const dayOfWeek = dayIndex + 1; // Monday = 1
              const schedule = getScheduleForSlot(timeSlot.id, dayOfWeek);
              
              return (
                <div
                  key={`${timeSlot.id}-${dayOfWeek}`}
                  className="time-slot bg-white border-2 border-dashed border-gray-200 rounded-2xl p-3 hover:border-primary transition-colors"
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, timeSlot.id, dayOfWeek)}
                >
                  {schedule ? (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div
                          className={`draggable-item schedule-item ${getSubjectClass(schedule.subject.name)} shadow-lg relative`}
                          draggable
                          onDragStart={(e) => handleDragStart(e, schedule)}
                        >
                          <div className="font-semibold flex items-center justify-between">
                            <span className="flex items-center">
                              <BookOpen size={12} className="mr-1 opacity-75" />
                              {schedule.subject.name}
                            </span>
                          </div>
                          <div className="text-xs opacity-90 flex items-center mt-1">
                            <User size={10} className="mr-1" />
                            {schedule.teacher.name}
                          </div>
                          <div className="text-xs opacity-75 flex items-center">
                            <MapPin size={10} className="mr-1" />
                            {schedule.classroom.name}
                          </div>
                          
                          {/* Drag indicator */}
                          <div className="absolute top-1 right-1 opacity-50">
                            <div className="grid grid-cols-2 gap-0.5">
                              {[...Array(4)].map((_, i) => (
                                <div key={i} className="w-1 h-1 bg-white rounded-full" />
                              ))}
                            </div>
                          </div>
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="bg-white border border-gray-200 shadow-lg">
                        <div className="space-y-1 text-xs">
                          <div><strong>Subject:</strong> {schedule.subject.name}</div>
                          <div><strong>Teacher:</strong> {schedule.teacher.name}</div>
                          <div><strong>Classroom:</strong> {schedule.classroom.name}</div>
                          <div><strong>Class:</strong> {schedule.class.name}</div>
                          <div className="text-gray-500 pt-1 border-t">
                            💡 Drag to move to a different time slot
                          </div>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  ) : (
                    <div className="h-full flex items-center justify-center text-gray-400">
                      <div className="text-center">
                        <div className="w-4 h-4 mx-auto mb-1 text-2xl">+</div>
                        <div className="text-xs">Add Class</div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
