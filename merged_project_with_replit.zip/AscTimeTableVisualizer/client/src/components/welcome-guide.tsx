import { useState } from "react";
import { X, ChevronRight, ChevronLeft, CheckCircle, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface WelcomeGuideProps {
  isOpen: boolean;
  onClose: () => void;
}

const guideSteps = [
  {
    title: "Welcome to ASC Timetable! 🎉",
    description: "Let's take a quick tour to help you get started with creating and managing your school schedules.",
    icon: "👋",
    content: (
      <div className="space-y-4">
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-4">
          <h4 className="font-semibold text-gray-800 mb-2">What you can do:</h4>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-center">
              <CheckCircle size={16} className="text-green-500 mr-2" />
              Create and manage class schedules with drag & drop
            </li>
            <li className="flex items-center">
              <CheckCircle size={16} className="text-green-500 mr-2" />
              Automatically detect scheduling conflicts
            </li>
            <li className="flex items-center">
              <CheckCircle size={16} className="text-green-500 mr-2" />
              Set up smart scheduling rules
            </li>
            <li className="flex items-center">
              <CheckCircle size={16} className="text-green-500 mr-2" />
              Manage teachers, classrooms, and resources
            </li>
          </ul>
        </div>
      </div>
    )
  },
  {
    title: "Dashboard Overview 📊",
    description: "Your dashboard shows everything you need at a glance.",
    icon: "📈",
    content: (
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
            <div className="font-semibold text-blue-800 text-sm">Stats Cards</div>
            <div className="text-xs text-blue-600 mt-1">Track classes, teachers, conflicts, and completion</div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-xl p-3">
            <div className="font-semibold text-green-800 text-sm">Timetable Grid</div>
            <div className="text-xs text-green-600 mt-1">Visual weekly schedule with drag & drop</div>
          </div>
          <div className="bg-red-50 border border-red-200 rounded-xl p-3">
            <div className="font-semibold text-red-800 text-sm">Conflicts Panel</div>
            <div className="text-xs text-red-600 mt-1">Real-time conflict detection and alerts</div>
          </div>
          <div className="bg-purple-50 border border-purple-200 rounded-xl p-3">
            <div className="font-semibold text-purple-800 text-sm">Smart Rules</div>
            <div className="text-xs text-purple-600 mt-1">Automated scheduling intelligence</div>
          </div>
        </div>
      </div>
    )
  },
  {
    title: "Creating Your Schedule 🗓️",
    description: "Learn how to create and manage your timetable easily.",
    icon: "⚡",
    content: (
      <div className="space-y-4">
        <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-4">
          <h4 className="font-semibold text-gray-800 mb-3">Quick Start Steps:</h4>
          <ol className="space-y-3 text-sm">
            <li className="flex items-start">
              <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs mr-3 mt-0.5">1</span>
              <div>
                <strong>Add Teachers & Classrooms:</strong> Use the Quick Actions panel to add your staff and facilities
              </div>
            </li>
            <li className="flex items-start">
              <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs mr-3 mt-0.5">2</span>
              <div>
                <strong>Select a Class:</strong> Choose which class schedule you want to work on from the dropdown
              </div>
            </li>
            <li className="flex items-start">
              <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs mr-3 mt-0.5">3</span>
              <div>
                <strong>Drag & Drop:</strong> Simply drag schedule items to different time slots to organize your week
              </div>
            </li>
            <li className="flex items-start">
              <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs mr-3 mt-0.5">4</span>
              <div>
                <strong>Monitor Conflicts:</strong> Watch for automatic conflict detection and resolution suggestions
              </div>
            </li>
          </ol>
        </div>
      </div>
    )
  },
  {
    title: "Smart Conditions 🧠",
    description: "Set up intelligent rules to automate your scheduling decisions.",
    icon: "🤖",
    content: (
      <div className="space-y-4">
        <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-4">
          <h4 className="font-semibold text-gray-800 mb-3">Smart Rules Examples:</h4>
          <div className="space-y-3">
            <div className="bg-white border border-purple-200 rounded-xl p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-sm">No Teacher Double Booking</div>
                  <div className="text-xs text-gray-600">Prevents scheduling conflicts automatically</div>
                </div>
                <Badge variant="secondary">High Priority</Badge>
              </div>
            </div>
            <div className="bg-white border border-blue-200 rounded-xl p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-sm">Science Lab Requirements</div>
                  <div className="text-xs text-gray-600">Suggests appropriate rooms for science subjects</div>
                </div>
                <Badge variant="secondary">Smart Suggestion</Badge>
              </div>
            </div>
            <div className="bg-white border border-green-200 rounded-xl p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-sm">Classroom Capacity Check</div>
                  <div className="text-xs text-gray-600">Warns when class size exceeds room capacity</div>
                </div>
                <Badge variant="secondary">Warning System</Badge>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  },
  {
    title: "You're All Set! 🚀",
    description: "You're ready to create amazing schedules. Remember, we're here to help!",
    icon: "✨",
    content: (
      <div className="space-y-4">
        <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-4">
          <h4 className="font-semibold text-gray-800 mb-3">Pro Tips:</h4>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-start">
              <span className="text-green-500 mr-2">💡</span>
              Start with preset rules for common scheduling scenarios
            </li>
            <li className="flex items-start">
              <span className="text-blue-500 mr-2">🎯</span>
              Use the conflict panel to quickly identify and resolve issues
            </li>
            <li className="flex items-start">
              <span className="text-purple-500 mr-2">⚡</span>
              Drag items from Available Resources directly onto the timetable
            </li>
            <li className="flex items-start">
              <span className="text-orange-500 mr-2">📊</span>
              Monitor your completion percentage in the stats cards
            </li>
          </ul>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-3 text-center">
          <div className="text-sm font-medium text-yellow-800">Need help?</div>
          <div className="text-xs text-yellow-600 mt-1">
            Look for the help tooltips throughout the interface or check the documentation
          </div>
        </div>
      </div>
    )
  }
];

export default function WelcomeGuide({ isOpen, onClose }: WelcomeGuideProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const nextStep = () => {
    if (currentStep < guideSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const isLastStep = currentStep === guideSteps.length - 1;
  const isFirstStep = currentStep === 0;

  if (!isOpen) return null;

  const currentGuide = guideSteps[currentStep];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center text-2xl">
                {currentGuide.icon}
              </div>
              <div>
                <CardTitle className="text-lg">{currentGuide.title}</CardTitle>
                <p className="text-sm text-gray-600 mt-1">{currentGuide.description}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X size={20} />
            </Button>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-4">
            <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
              <span>Step {currentStep + 1} of {guideSteps.length}</span>
              <span>{Math.round(((currentStep + 1) / guideSteps.length) * 100)}% Complete</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentStep + 1) / guideSteps.length) * 100}%` }}
              />
            </div>
          </div>
        </CardHeader>

        <CardContent>
          <div className="mb-6">
            {currentGuide.content}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between pt-4 border-t">
            <Button
              variant="outline"
              onClick={prevStep}
              disabled={isFirstStep}
              className="flex items-center space-x-2"
            >
              <ChevronLeft size={16} />
              <span>Previous</span>
            </Button>

            <div className="flex space-x-1">
              {guideSteps.map((_, index) => (
                <button
                  key={index}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentStep ? 'bg-blue-500' : 'bg-gray-300'
                  }`}
                  onClick={() => setCurrentStep(index)}
                />
              ))}
            </div>

            {!isLastStep ? (
              <Button
                onClick={nextStep}
                className="gradient-bg text-white flex items-center space-x-2"
              >
                <span>Next</span>
                <ChevronRight size={16} />
              </Button>
            ) : (
              <Button
                onClick={onClose}
                className="gradient-bg text-white flex items-center space-x-2"
              >
                <Play size={16} />
                <span>Get Started</span>
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}