import type { ScheduleWithDetails } from "@shared/schema";

export interface ConflictDetectionResult {
  hasConflicts: boolean;
  conflicts: {
    type: 'teacher_double_booking' | 'classroom_double_booking' | 'time_overlap';
    description: string;
    severity: 'low' | 'medium' | 'high';
    scheduleIds: number[];
  }[];
}

export function detectScheduleConflicts(schedules: ScheduleWithDetails[]): ConflictDetectionResult {
  const conflicts = [];

  // Check for teacher double booking
  const teacherSlots = new Map<string, ScheduleWithDetails>();
  schedules.forEach(schedule => {
    const key = `${schedule.teacherId}-${schedule.timeSlotId}-${schedule.dayOfWeek}`;
    if (teacherSlots.has(key)) {
      const existingSchedule = teacherSlots.get(key)!;
      conflicts.push({
        type: 'teacher_double_booking' as const,
        description: `${schedule.teacher.name} is scheduled for multiple classes at the same time`,
        severity: 'high' as const,
        scheduleIds: [existingSchedule.id, schedule.id],
      });
    } else {
      teacherSlots.set(key, schedule);
    }
  });

  // Check for classroom double booking
  const classroomSlots = new Map<string, ScheduleWithDetails>();
  schedules.forEach(schedule => {
    const key = `${schedule.classroomId}-${schedule.timeSlotId}-${schedule.dayOfWeek}`;
    if (classroomSlots.has(key)) {
      const existingSchedule = classroomSlots.get(key)!;
      conflicts.push({
        type: 'classroom_double_booking' as const,
        description: `${schedule.classroom.name} is booked for multiple classes at the same time`,
        severity: 'high' as const,
        scheduleIds: [existingSchedule.id, schedule.id],
      });
    } else {
      classroomSlots.set(key, schedule);
    }
  });

  return {
    hasConflicts: conflicts.length > 0,
    conflicts,
  };
}

export function getConflictScheduleIds(schedules: ScheduleWithDetails[]): Set<number> {
  const result = detectScheduleConflicts(schedules);
  const conflictIds = new Set<number>();
  
  result.conflicts.forEach(conflict => {
    conflict.scheduleIds.forEach(id => conflictIds.add(id));
  });
  
  return conflictIds;
}
