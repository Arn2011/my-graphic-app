export interface DragItem {
  type: string;
  id: number;
  data: any;
}

export const ItemTypes = {
  SCHEDULE: 'schedule',
  TEACHER: 'teacher',
  CLASSROOM: 'classroom',
} as const;

export function createDragData(type: string, id: number, data: any): DragItem {
  return { type, id, data };
}

export function parseDragData(dataTransfer: DataTransfer): DragItem | null {
  try {
    const data = dataTransfer.getData('application/json');
    return JSON.parse(data);
  } catch {
    return null;
  }
}

export function setDragData(dataTransfer: DataTransfer, item: DragItem): void {
  dataTransfer.setData('application/json', JSON.stringify(item));
}
