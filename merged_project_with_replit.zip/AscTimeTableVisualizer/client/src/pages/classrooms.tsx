import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MapPin, Plus, Edit, Users, Monitor, Wifi, Coffee } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Classrooms() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const schoolId = 1;
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: classrooms = [], isLoading } = useQuery({
    queryKey: [`/api/schools/${schoolId}/classrooms`],
  });

  const addClassroomMutation = useMutation({
    mutationFn: async (classroomData: any) => {
      const response = await apiRequest("POST", `/api/schools/${schoolId}/classrooms`, classroomData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/schools/${schoolId}/classrooms`] });
      toast({ title: "Classroom added successfully!" });
      setIsAddModalOpen(false);
    },
  });

  const filteredClassrooms = Array.isArray(classrooms) ? classrooms.filter((classroom: any) =>
    classroom.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    classroom.building?.toLowerCase().includes(searchTerm.toLowerCase())
  ) : [];

  const handleAddClassroom = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const classroomData = {
      name: formData.get("name"),
      building: formData.get("building"),
      floor: parseInt(formData.get("floor") as string) || 1,
      capacity: parseInt(formData.get("capacity") as string) || 30,
      type: formData.get("type"),
      hasProjector: formData.get("hasProjector") === "on",
      hasWhiteboard: formData.get("hasWhiteboard") === "on",
      hasAC: formData.get("hasAC") === "on",
    };
    addClassroomMutation.mutate(classroomData);
  };

  const getClassroomIcon = (type: string) => {
    switch (type?.toLowerCase()) {
      case "lab": return <Monitor size={20} />;
      case "auditorium": return <Users size={20} />;
      case "library": return <Coffee size={20} />;
      default: return <MapPin size={20} />;
    }
  };

  const getStatusColor = (isAvailable: boolean) => {
    return isAvailable ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center">
                <MapPin className="text-white" size={24} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">Classrooms Management</h1>
                <p className="text-gray-600">Manage school facilities and resources</p>
              </div>
            </div>
            
            <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
              <DialogTrigger asChild>
                <Button className="gradient-bg text-white rounded-2xl">
                  <Plus size={16} className="mr-2" />
                  Add Classroom
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Classroom</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddClassroom} className="space-y-4">
                  <Input name="name" placeholder="Room Name/Number" required />
                  <Input name="building" placeholder="Building Name" />
                  <Input name="floor" type="number" placeholder="Floor Number" />
                  <Input name="capacity" type="number" placeholder="Seating Capacity" />
                  <select name="type" className="w-full p-2 border rounded-lg">
                    <option value="">Select Room Type</option>
                    <option value="classroom">Regular Classroom</option>
                    <option value="lab">Laboratory</option>
                    <option value="auditorium">Auditorium</option>
                    <option value="library">Library</option>
                    <option value="gym">Gymnasium</option>
                  </select>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium text-gray-700">Facilities</h4>
                    <div className="space-y-2">
                      <label className="flex items-center space-x-2">
                        <input type="checkbox" name="hasProjector" />
                        <span className="text-sm">Projector</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input type="checkbox" name="hasWhiteboard" />
                        <span className="text-sm">Whiteboard</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input type="checkbox" name="hasAC" />
                        <span className="text-sm">Air Conditioning</span>
                      </label>
                    </div>
                  </div>
                  
                  <Button type="submit" className="w-full gradient-bg text-white" disabled={addClassroomMutation.isPending}>
                    {addClassroomMutation.isPending ? "Adding..." : "Add Classroom"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filters */}
        <div className="bubble-card rounded-3xl p-6 shadow-xl mb-8">
          <div className="flex items-center space-x-4">
            <Input
              placeholder="Search classrooms by name or building..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 rounded-2xl"
            />
            <Button variant="outline" className="rounded-2xl">
              Filter by Building
            </Button>
            <Button variant="outline" className="rounded-2xl">
              Filter by Type
            </Button>
          </div>
        </div>

        {/* Classrooms Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bubble-card rounded-2xl p-6 animate-pulse">
                <div className="w-16 h-16 bg-gray-300 rounded-full mx-auto mb-4"></div>
                <div className="h-4 bg-gray-300 rounded mb-2"></div>
                <div className="h-3 bg-gray-300 rounded mb-4"></div>
                <div className="h-8 bg-gray-300 rounded"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredClassrooms.map((classroom: any) => (
              <Card key={classroom.id} className="bubble-card rounded-2xl shadow-lg hover:shadow-xl transition-shadow border-0">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-3">
                    {getClassroomIcon(classroom.type)}
                  </div>
                  <CardTitle className="text-lg font-bold text-gray-800">{classroom.name}</CardTitle>
                  <div className="flex justify-center space-x-2">
                    <Badge className={getStatusColor(true)}>
                      Available
                    </Badge>
                    <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                      {classroom.type || "Classroom"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center text-sm text-gray-600">
                    <MapPin size={14} className="mr-2" />
                    {classroom.building || "Main Building"}, Floor {classroom.floor || 1}
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Users size={14} className="mr-2" />
                    Capacity: {classroom.capacity || 30} students
                  </div>
                  
                  {/* Facilities */}
                  <div className="pt-2">
                    <h4 className="text-xs font-medium text-gray-500 mb-2">FACILITIES</h4>
                    <div className="flex flex-wrap gap-1">
                      {classroom.hasProjector && (
                        <Badge variant="outline" className="text-xs">
                          <Monitor size={10} className="mr-1" />
                          Projector
                        </Badge>
                      )}
                      {classroom.hasWhiteboard && (
                        <Badge variant="outline" className="text-xs">
                          Whiteboard
                        </Badge>
                      )}
                      {classroom.hasAC && (
                        <Badge variant="outline" className="text-xs">
                          <Wifi size={10} className="mr-1" />
                          A/C
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex space-x-2 pt-3">
                    <Button variant="outline" size="sm" className="flex-1 rounded-xl">
                      <Edit size={12} className="mr-1" />
                      Edit
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 rounded-xl">
                      View Schedule
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {Array.isArray(classrooms) ? classrooms.length : 0}
            </div>
            <div className="text-gray-600 text-sm">Total Rooms</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {Array.isArray(classrooms) ? classrooms.filter((c: any) => c.type === 'lab').length : 0}
            </div>
            <div className="text-gray-600 text-sm">Laboratories</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">
              {Array.isArray(classrooms) ? classrooms.reduce((acc: number, c: any) => acc + (c.capacity || 30), 0) : 0}
            </div>
            <div className="text-gray-600 text-sm">Total Capacity</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">92%</div>
            <div className="text-gray-600 text-sm">Utilization Rate</div>
          </div>
        </div>
      </div>
    </div>
  );
}