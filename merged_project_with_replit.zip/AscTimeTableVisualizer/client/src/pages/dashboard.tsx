import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { CalendarDays, Bell, User, HelpCircle, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import StatsCards from "@/components/stats-cards";
import TimetableGrid from "@/components/timetable-grid";
import ConflictPanel from "@/components/conflict-panel";
import QuickActions from "@/components/quick-actions";
import AvailableResources from "@/components/available-resources";
import RulesModal from "@/components/rules-modal";
import SmartConditionsPanel from "@/components/smart-conditions-panel";
import WelcomeGuide from "@/components/welcome-guide";

export default function Dashboard() {
  const [selectedClassId, setSelectedClassId] = useState<number>(1);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);
  const [isWelcomeGuideOpen, setIsWelcomeGuideOpen] = useState(false);
  
  // For demo purposes, using schoolId = 1
  const schoolId = 1;

  // Check if user is new (you can implement proper user preferences later)
  useEffect(() => {
    const hasSeenGuide = localStorage.getItem('asc-timetable-guide-seen');
    if (!hasSeenGuide) {
      setIsWelcomeGuideOpen(true);
    }
  }, []);

  const handleGuideClose = () => {
    setIsWelcomeGuideOpen(false);
    localStorage.setItem('asc-timetable-guide-seen', 'true');
  };

  const { data: classes = [] } = useQuery({
    queryKey: [`/api/schools/${schoolId}/classes`],
  });

  const { data: stats } = useQuery({
    queryKey: [`/api/schools/${schoolId}/stats`],
  });

  const { data: schedules = [] } = useQuery({
    queryKey: [`/api/classes/${selectedClassId}/schedules`],
  });

  const { data: conflicts = [] } = useQuery({
    queryKey: [`/api/schools/${schoolId}/conflicts`],
  });

  const { data: timeSlots = [] } = useQuery({
    queryKey: [`/api/schools/${schoolId}/time-slots`],
  });

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 gradient-bg rounded-full flex items-center justify-center">
                <CalendarDays className="text-white" size={20} />
              </div>
              <h1 className="text-xl font-bold text-gray-800">ASC Timetable</h1>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#dashboard" className="text-primary font-medium hover:text-secondary transition-colors">
                Dashboard
              </a>
              <a href="#timetable" className="text-gray-600 hover:text-primary transition-colors">
                Timetable
              </a>
              <a href="#teachers" className="text-gray-600 hover:text-primary transition-colors">
                Teachers
              </a>
              <a href="#classrooms" className="text-gray-600 hover:text-primary transition-colors">
                Classrooms
              </a>
              <a href="#rules" className="text-gray-600 hover:text-primary transition-colors">
                Rules
              </a>
            </nav>
            
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="icon" 
                className="rounded-full"
                onClick={() => setIsWelcomeGuideOpen(true)}
                title="Help & Tutorial"
              >
                <HelpCircle size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Bell size={20} />
              </Button>
              <Button size="icon" className="gradient-bg rounded-full text-white">
                <User size={20} />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <StatsCards stats={stats as any} />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8 mt-8">
          {/* Timetable View - Takes 2 columns */}
          <div className="xl:col-span-2">
            <div className="bubble-card rounded-3xl p-6 shadow-xl">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800 flex items-center">
                  📅 Weekly Timetable
                </h2>
                <div className="flex items-center space-x-3">
                  <Select value={selectedClassId.toString()} onValueChange={(value) => setSelectedClassId(parseInt(value))}>
                    <SelectTrigger className="bg-gray-50 border border-gray-200 rounded-2xl px-4 py-2 text-sm min-w-32">
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.isArray(classes) && classes.map((cls: any) => (
                        <SelectItem key={cls.id} value={cls.id.toString()}>
                          {cls.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button className="gradient-bg text-white rounded-2xl text-sm font-medium hover:shadow-lg transition-shadow">
                    ➕ Add Period
                  </Button>
                </div>
              </div>
              
              <TimetableGrid 
                schedules={Array.isArray(schedules) ? schedules : []} 
                timeSlots={Array.isArray(timeSlots) ? timeSlots : []}
                selectedClassId={selectedClassId}
                schoolId={schoolId}
              />
            </div>
          </div>

          {/* Smart Panels - Takes 2 columns */}
          <div className="xl:col-span-2 grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-1 gap-6">
            {/* Top Priority Panels */}
            <div className="space-y-6">
              <ConflictPanel conflicts={Array.isArray(conflicts) ? conflicts : []} />
              <SmartConditionsPanel schoolId={schoolId} />
            </div>
            
            {/* Action Panels */}
            <div className="space-y-6">
              <QuickActions onCreateRule={() => setIsRulesModalOpen(true)} schoolId={schoolId} />
              <AvailableResources schoolId={schoolId} />
            </div>
          </div>
        </div>
      </div>

      {/* Rules Modal */}
      <RulesModal 
        isOpen={isRulesModalOpen} 
        onClose={() => setIsRulesModalOpen(false)}
        schoolId={schoolId}
      />

      {/* Welcome Guide */}
      <WelcomeGuide 
        isOpen={isWelcomeGuideOpen} 
        onClose={handleGuideClose}
      />
    </div>
  );
}
