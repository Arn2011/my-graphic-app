import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Settings, Plus, Edit, ToggleLeft, Trash2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import RulesModal from "@/components/rules-modal";
import SmartConditionsPanel from "@/components/smart-conditions-panel";

export default function Rules() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);
  const schoolId = 1;

  const { data: rules = [], isLoading } = useQuery({
    queryKey: [`/api/schools/${schoolId}/rules`],
  });

  const filteredRules = Array.isArray(rules) ? rules.filter((rule: any) =>
    rule.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    rule.description?.toLowerCase().includes(searchTerm.toLowerCase())
  ) : [];

  const getSeverityColor = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getRuleTypeIcon = (type: string) => {
    switch (type?.toLowerCase()) {
      case "conflict": return <AlertTriangle size={16} />;
      case "assignment": return <Settings size={16} />;
      default: return <ToggleLeft size={16} />;
    }
  };

  // Mock data for demonstration since no rules exist yet
  const mockRules = [
    {
      id: 1,
      name: "No Teacher Double Booking",
      description: "Prevent teachers from being assigned to multiple classes at the same time",
      type: "conflict",
      isActive: true,
      severity: "high",
      conditions: ["teacher_overlap", "same_time_slot"],
      actions: ["block_assignment", "show_warning"]
    },
    {
      id: 2,
      name: "Classroom Capacity Check",
      description: "Ensure classroom capacity is not exceeded by class size",
      type: "constraint",
      isActive: true,
      severity: "medium",
      conditions: ["classroom_capacity", "class_size"],
      actions: ["suggest_alternative", "flag_issue"]
    },
    {
      id: 3,
      name: "Lunch Break Protection",
      description: "Ensure at least 30 minutes lunch break for all classes",
      type: "schedule",
      isActive: false,
      severity: "low",
      conditions: ["lunch_time", "minimum_duration"],
      actions: ["adjust_schedule"]
    }
  ];

  const displayRules = filteredRules.length > 0 ? filteredRules : mockRules;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center">
                <Settings className="text-white" size={24} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">Rules & Conditions</h1>
                <p className="text-gray-600">Manage smart scheduling rules and constraints</p>
              </div>
            </div>
            
            <Button 
              onClick={() => setIsRulesModalOpen(true)}
              className="gradient-bg text-white rounded-2xl"
            >
              <Plus size={16} className="mr-2" />
              Create Rule
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Smart Conditions Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2">
            <div className="bubble-card rounded-3xl p-6 shadow-xl">
              <div className="flex items-center space-x-4 mb-6">
                <Input
                  placeholder="Search rules by name or description..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1 rounded-2xl"
                />
                <Button variant="outline" className="rounded-2xl">
                  Filter by Type
                </Button>
              </div>
              
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Active Rules</h3>
              
              {/* Rules List */}
              <div className="space-y-4">
                {displayRules.map((rule: any) => (
                  <Card key={rule.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                              {getRuleTypeIcon(rule.type)}
                            </div>
                            <h4 className="font-semibold text-gray-800">{rule.name}</h4>
                            <Badge className={getSeverityColor(rule.severity)}>
                              {rule.severity}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{rule.description}</p>
                          
                          <div className="flex flex-wrap gap-2">
                            <div className="text-xs text-gray-500">
                              <strong>Conditions:</strong> {rule.conditions?.join(", ") || "None"}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <Switch checked={rule.isActive} />
                          <Button variant="ghost" size="sm">
                            <Edit size={14} />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600">
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                {displayRules.length === 0 && (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Settings className="text-gray-400" size={24} />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-700 mb-2">No Rules Found</h3>
                    <p className="text-gray-500 mb-4">Create your first scheduling rule to get started.</p>
                    <Button 
                      onClick={() => setIsRulesModalOpen(true)}
                      className="gradient-bg text-white rounded-2xl"
                    >
                      <Plus size={16} className="mr-2" />
                      Create First Rule
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-1">
            <SmartConditionsPanel schoolId={schoolId} />
          </div>
        </div>

        {/* Rule Templates */}
        <div className="bubble-card rounded-3xl p-6 shadow-xl">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Rule Templates</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4 text-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <AlertTriangle className="text-red-600" size={20} />
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Conflict Prevention</h4>
                <p className="text-xs text-gray-600">Prevent scheduling conflicts</p>
              </CardContent>
            </Card>
            
            <Card className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4 text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Settings className="text-blue-600" size={20} />
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Resource Management</h4>
                <p className="text-xs text-gray-600">Manage classroom and teacher allocation</p>
              </CardContent>
            </Card>
            
            <Card className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4 text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <ToggleLeft className="text-green-600" size={20} />
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Schedule Optimization</h4>
                <p className="text-xs text-gray-600">Optimize class scheduling</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {displayRules.length}
            </div>
            <div className="text-gray-600 text-sm">Total Rules</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {displayRules.filter((r: any) => r.isActive).length}
            </div>
            <div className="text-gray-600 text-sm">Active Rules</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-red-600 mb-2">
              {displayRules.filter((r: any) => r.severity === "high").length}
            </div>
            <div className="text-gray-600 text-sm">High Priority</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">98%</div>
            <div className="text-gray-600 text-sm">Rule Compliance</div>
          </div>
        </div>
      </div>

      {/* Rules Modal */}
      <RulesModal 
        isOpen={isRulesModalOpen} 
        onClose={() => setIsRulesModalOpen(false)}
        schoolId={schoolId}
      />
    </div>
  );
}