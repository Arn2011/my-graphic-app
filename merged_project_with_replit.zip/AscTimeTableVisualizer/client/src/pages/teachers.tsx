import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { User, Plus, Edit, Calendar, BookOpen, Mail, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Teachers() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const schoolId = 1;
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: teachers = [], isLoading } = useQuery({
    queryKey: [`/api/schools/${schoolId}/teachers`],
  });

  const { data: subjects = [] } = useQuery({
    queryKey: [`/api/schools/${schoolId}/subjects`],
  });

  const addTeacherMutation = useMutation({
    mutationFn: async (teacherData: any) => {
      const response = await apiRequest("POST", `/api/schools/${schoolId}/teachers`, teacherData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/schools/${schoolId}/teachers`] });
      toast({ title: "Teacher added successfully!" });
      setIsAddModalOpen(false);
    },
  });

  const filteredTeachers = Array.isArray(teachers) ? teachers.filter((teacher: any) =>
    teacher.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    teacher.email?.toLowerCase().includes(searchTerm.toLowerCase())
  ) : [];

  const getSubjectName = (subjectId: number) => {
    const subject = Array.isArray(subjects) ? subjects.find((s: any) => s.id === subjectId) : null;
    return subject?.name || "Unknown Subject";
  };

  const handleAddTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const teacherData = {
      name: formData.get("name"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      subjectId: parseInt(formData.get("subjectId") as string),
      qualification: formData.get("qualification"),
      experience: parseInt(formData.get("experience") as string) || 0,
    };
    addTeacherMutation.mutate(teacherData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center">
                <User className="text-white" size={24} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">Teachers Management</h1>
                <p className="text-gray-600">Manage faculty and their assignments</p>
              </div>
            </div>
            
            <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
              <DialogTrigger asChild>
                <Button className="gradient-bg text-white rounded-2xl">
                  <Plus size={16} className="mr-2" />
                  Add Teacher
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Teacher</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddTeacher} className="space-y-4">
                  <Input name="name" placeholder="Full Name" required />
                  <Input name="email" type="email" placeholder="Email Address" />
                  <Input name="phone" placeholder="Phone Number" />
                  <select name="subjectId" className="w-full p-2 border rounded-lg" required>
                    <option value="">Select Subject</option>
                    {Array.isArray(subjects) && subjects.map((subject: any) => (
                      <option key={subject.id} value={subject.id}>
                        {subject.name}
                      </option>
                    ))}
                  </select>
                  <Input name="qualification" placeholder="Qualification" />
                  <Input name="experience" type="number" placeholder="Years of Experience" />
                  <Button type="submit" className="w-full gradient-bg text-white" disabled={addTeacherMutation.isPending}>
                    {addTeacherMutation.isPending ? "Adding..." : "Add Teacher"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filters */}
        <div className="bubble-card rounded-3xl p-6 shadow-xl mb-8">
          <div className="flex items-center space-x-4">
            <Input
              placeholder="Search teachers by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 rounded-2xl"
            />
            <Button variant="outline" className="rounded-2xl">
              Filter by Subject
            </Button>
          </div>
        </div>

        {/* Teachers Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bubble-card rounded-2xl p-6 animate-pulse">
                <div className="w-16 h-16 bg-gray-300 rounded-full mx-auto mb-4"></div>
                <div className="h-4 bg-gray-300 rounded mb-2"></div>
                <div className="h-3 bg-gray-300 rounded mb-4"></div>
                <div className="h-8 bg-gray-300 rounded"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTeachers.map((teacher: any) => (
              <Card key={teacher.id} className="bubble-card rounded-2xl shadow-lg hover:shadow-xl transition-shadow border-0">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-3">
                    <User className="text-white" size={24} />
                  </div>
                  <CardTitle className="text-lg font-bold text-gray-800">{teacher.name}</CardTitle>
                  <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                    {getSubjectName(teacher.subjectId)}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-3">
                  {teacher.email && (
                    <div className="flex items-center text-sm text-gray-600">
                      <Mail size={14} className="mr-2" />
                      {teacher.email}
                    </div>
                  )}
                  {teacher.phone && (
                    <div className="flex items-center text-sm text-gray-600">
                      <Phone size={14} className="mr-2" />
                      {teacher.phone}
                    </div>
                  )}
                  <div className="flex items-center text-sm text-gray-600">
                    <BookOpen size={14} className="mr-2" />
                    {teacher.qualification || "No qualification listed"}
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Calendar size={14} className="mr-2" />
                    {teacher.experience || 0} years experience
                  </div>
                  <div className="flex space-x-2 pt-3">
                    <Button variant="outline" size="sm" className="flex-1 rounded-xl">
                      <Edit size={12} className="mr-1" />
                      Edit
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 rounded-xl">
                      <Calendar size={12} className="mr-1" />
                      Schedule
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {Array.isArray(teachers) ? teachers.length : 0}
            </div>
            <div className="text-gray-600 text-sm">Total Teachers</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {Array.isArray(subjects) ? subjects.length : 0}
            </div>
            <div className="text-gray-600 text-sm">Subjects Taught</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">
              {Array.isArray(teachers) ? Math.round(teachers.reduce((acc: number, t: any) => acc + (t.experience || 0), 0) / teachers.length) || 0 : 0}
            </div>
            <div className="text-gray-600 text-sm">Avg Experience</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">95%</div>
            <div className="text-gray-600 text-sm">Attendance Rate</div>
          </div>
        </div>
      </div>
    </div>
  );
}