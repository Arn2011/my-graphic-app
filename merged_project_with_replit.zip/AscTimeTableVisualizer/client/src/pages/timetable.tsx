import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CalendarDays, Clock, Filter, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import TimetableGrid from "@/components/timetable-grid";

export default function Timetable() {
  const [selectedClassId, setSelectedClassId] = useState<number>(1);
  const [selectedWeek, setSelectedWeek] = useState<string>("current");
  
  const schoolId = 1;

  const { data: classes = [] } = useQuery({
    queryKey: [`/api/schools/${schoolId}/classes`],
  });

  const { data: schedules = [] } = useQuery({
    queryKey: [`/api/classes/${selectedClassId}/schedules`],
  });

  const { data: timeSlots = [] } = useQuery({
    queryKey: [`/api/schools/${schoolId}/time-slots`],
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center">
                <CalendarDays className="text-white" size={24} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">Timetable Management</h1>
                <p className="text-gray-600">Manage and view school schedules</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <Button variant="outline" className="rounded-2xl">
                <Filter size={16} className="mr-2" />
                Filter
              </Button>
              <Button variant="outline" className="rounded-2xl">
                <Download size={16} className="mr-2" />
                Export
              </Button>
              <Button className="gradient-bg text-white rounded-2xl">
                <Clock size={16} className="mr-2" />
                New Period
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Controls */}
        <div className="bubble-card rounded-3xl p-6 shadow-xl mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-800">Timetable View</h2>
            <div className="flex items-center space-x-4">
              <Select value={selectedClassId.toString()} onValueChange={(value) => setSelectedClassId(parseInt(value))}>
                <SelectTrigger className="bg-gray-50 border border-gray-200 rounded-2xl px-4 py-2 min-w-40">
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  {Array.isArray(classes) && classes.map((cls: any) => (
                    <SelectItem key={cls.id} value={cls.id.toString()}>
                      {cls.name} ({cls.studentCount} students)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={selectedWeek} onValueChange={setSelectedWeek}>
                <SelectTrigger className="bg-gray-50 border border-gray-200 rounded-2xl px-4 py-2 min-w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="current">Current Week</SelectItem>
                  <SelectItem value="next">Next Week</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <TimetableGrid 
            schedules={Array.isArray(schedules) ? schedules : []} 
            timeSlots={Array.isArray(timeSlots) ? timeSlots : []}
            selectedClassId={selectedClassId}
            schoolId={schoolId}
          />
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {Array.isArray(schedules) ? schedules.length : 0}
            </div>
            <div className="text-gray-600 text-sm">Total Periods</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {Array.isArray(timeSlots) ? timeSlots.length : 0}
            </div>
            <div className="text-gray-600 text-sm">Time Slots</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">5</div>
            <div className="text-gray-600 text-sm">School Days</div>
          </div>
          <div className="bubble-card rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">85%</div>
            <div className="text-gray-600 text-sm">Utilization</div>
          </div>
        </div>
      </div>
    </div>
  );
}