# ASC Timetable Management System

## Overview

ASC Timetable is a comprehensive school timetable management system built with modern web technologies. The application enables schools to create, manage, and optimize their class schedules while automatically detecting conflicts and providing intelligent resource allocation. The system features a modern, responsive UI with drag-and-drop functionality for intuitive schedule management.

## System Architecture

The application follows a full-stack architecture with clear separation between frontend and backend components:

**Frontend Architecture:**
- React-based single-page application with TypeScript
- Component-based architecture using shadcn/ui components
- State management via TanStack Query for server state
- Vite as the build tool and development server
- Tailwind CSS for styling with custom design system

**Backend Architecture:**
- Express.js REST API server
- PostgreSQL database with Drizzle ORM
- Neon serverless database integration
- Session-based architecture with PostgreSQL session store
- Modular route handling and storage abstraction

**Development Architecture:**
- Monorepo structure with shared schema definitions
- TypeScript throughout the entire stack
- Hot module replacement in development
- Production-ready build pipeline

## Key Components

### Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: Neon serverless PostgreSQL
- **Schema**: Comprehensive school management schema including schools, teachers, classrooms, subjects, classes, time slots, schedules, conflicts, and rules
- **Relations**: Well-defined relationships between entities with proper foreign key constraints

### API Layer
- **REST Endpoints**: Comprehensive CRUD operations for all entities
- **Conflict Detection**: Automated conflict detection system for schedule overlaps
- **Resource Management**: APIs for managing teachers, classrooms, and availability
- **Validation**: Zod schema validation for all API inputs

### Frontend Components
- **Dashboard**: Central management interface with statistics and quick actions
- **Timetable Grid**: Interactive drag-and-drop schedule management
- **Conflict Panel**: Real-time conflict display and resolution tools
- **Resource Management**: Teacher and classroom availability tracking
- **Quick Actions**: Modal-based forms for rapid data entry

### User Interface
- **Design System**: Modern bubble-themed UI with gradient accents
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Accessibility**: ARIA-compliant components with keyboard navigation
- **Animation**: Smooth transitions and micro-interactions

## Data Flow

1. **User Interaction**: Users interact with React components through the dashboard interface
2. **State Management**: TanStack Query manages server state and caching
3. **API Communication**: RESTful API calls handle data persistence
4. **Database Operations**: Drizzle ORM translates operations to SQL queries
5. **Real-time Updates**: Automatic cache invalidation ensures data consistency
6. **Conflict Detection**: Server-side algorithms detect and report scheduling conflicts

## External Dependencies

### Core Dependencies
- **Database**: Neon serverless PostgreSQL for data persistence
- **ORM**: Drizzle for type-safe database operations
- **UI Components**: Radix UI primitives for accessibility
- **Validation**: Zod for runtime type checking
- **Styling**: Tailwind CSS for utility-first styling

### Development Dependencies
- **Build Tools**: Vite for fast development and optimized builds
- **TypeScript**: Full type safety across the stack
- **ESBuild**: Fast JavaScript bundling for production

### Third-party Integrations
- **Replit**: Integration with Replit development environment
- **Session Management**: PostgreSQL-based session storage
- **WebSocket**: Real-time communication for development tools

## Deployment Strategy

**Development Environment:**
- Vite development server with hot module replacement
- Express middleware integration for full-stack development
- Replit-specific tooling for cloud development

**Production Build:**
- Vite builds the frontend to static assets
- ESBuild bundles the backend for Node.js deployment
- Static file serving through Express in production

**Database Strategy:**
- Neon serverless PostgreSQL for scalable data storage
- Connection pooling for optimal performance
- Migration system using Drizzle Kit

**Environment Configuration:**
- Environment variables for database connection
- Separate development and production configurations
- Secure credential management

## Changelog

```
Changelog:
- July 02, 2025. Initial setup with comprehensive ASC timetabling system
- July 02, 2025. Added smart conditions panel for custom rule management
- July 02, 2025. Enhanced user experience with welcome guide and tooltips
- July 02, 2025. Implemented bubble-themed UI with glassmorphism effects
- July 02, 2025. Added drag-and-drop functionality for schedule management
- July 02, 2025. Integrated real-time conflict detection system
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
User interface preference: Bubble-themed design with user-friendly features
Requested features: Custom condition panel, smart management system, if-then rules
```