import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertSchoolSchema, insertTeacherSchema, insertClassroomSchema, insertSubjectSchema,
  insertClassSchema, insertTimeSlotSchema, insertScheduleSchema, insertConflictSchema, insertRuleSchema
} from "@shared/schema";


export async function registerRoutes(app: Express): Promise<Server> {
  // Schools
  app.get("/api/schools/:id", async (req, res) => {
    try {
      const school = await storage.getSchool(parseInt(req.params.id));
      if (!school) {
        return res.status(404).json({ message: "School not found" });
      }
      res.json(school);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch school" });
    }
  });

  app.post("/api/schools", async (req, res) => {
    try {
      const schoolData = insertSchoolSchema.parse(req.body);
      const school = await storage.createSchool(schoolData);
      res.status(201).json(school);
    } catch (error) {
      res.status(400).json({ message: "Invalid school data" });
    }
  });

  // Teachers
  app.get("/api/schools/:schoolId/teachers", async (req, res) => {
    try {
      const teachers = await storage.getTeachersBySchool(parseInt(req.params.schoolId));
      res.json(teachers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teachers" });
    }
  });

  app.get("/api/schools/:schoolId/teachers/available", async (req, res) => {
    try {
      const { timeSlotId, dayOfWeek } = req.query;
      const teachers = await storage.getAvailableTeachers(
        parseInt(req.params.schoolId),
        parseInt(timeSlotId as string),
        parseInt(dayOfWeek as string)
      );
      res.json(teachers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch available teachers" });
    }
  });

  app.post("/api/schools/:schoolId/teachers", async (req, res) => {
    try {
      const teacherData = insertTeacherSchema.parse({
        ...req.body,
        schoolId: parseInt(req.params.schoolId),
      });
      const teacher = await storage.createTeacher(teacherData);
      res.status(201).json(teacher);
    } catch (error) {
      res.status(400).json({ message: "Invalid teacher data" });
    }
  });

  // Classrooms
  app.get("/api/schools/:schoolId/classrooms", async (req, res) => {
    try {
      const classrooms = await storage.getClassroomsBySchool(parseInt(req.params.schoolId));
      res.json(classrooms);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch classrooms" });
    }
  });

  app.get("/api/schools/:schoolId/classrooms/available", async (req, res) => {
    try {
      const { timeSlotId, dayOfWeek } = req.query;
      const classrooms = await storage.getAvailableClassrooms(
        parseInt(req.params.schoolId),
        parseInt(timeSlotId as string),
        parseInt(dayOfWeek as string)
      );
      res.json(classrooms);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch available classrooms" });
    }
  });

  app.post("/api/schools/:schoolId/classrooms", async (req, res) => {
    try {
      const classroomData = insertClassroomSchema.parse({
        ...req.body,
        schoolId: parseInt(req.params.schoolId),
      });
      const classroom = await storage.createClassroom(classroomData);
      res.status(201).json(classroom);
    } catch (error) {
      res.status(400).json({ message: "Invalid classroom data" });
    }
  });

  // Subjects
  app.get("/api/schools/:schoolId/subjects", async (req, res) => {
    try {
      const subjects = await storage.getSubjectsBySchool(parseInt(req.params.schoolId));
      res.json(subjects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subjects" });
    }
  });

  app.post("/api/schools/:schoolId/subjects", async (req, res) => {
    try {
      const subjectData = insertSubjectSchema.parse({
        ...req.body,
        schoolId: parseInt(req.params.schoolId),
      });
      const subject = await storage.createSubject(subjectData);
      res.status(201).json(subject);
    } catch (error) {
      res.status(400).json({ message: "Invalid subject data" });
    }
  });

  // Classes
  app.get("/api/schools/:schoolId/classes", async (req, res) => {
    try {
      const classes = await storage.getClassesBySchool(parseInt(req.params.schoolId));
      res.json(classes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch classes" });
    }
  });

  app.post("/api/schools/:schoolId/classes", async (req, res) => {
    try {
      const classData = insertClassSchema.parse({
        ...req.body,
        schoolId: parseInt(req.params.schoolId),
      });
      const newClass = await storage.createClass(classData);
      res.status(201).json(newClass);
    } catch (error) {
      res.status(400).json({ message: "Invalid class data" });
    }
  });

  // Time Slots
  app.get("/api/schools/:schoolId/time-slots", async (req, res) => {
    try {
      const timeSlots = await storage.getTimeSlotsBySchool(parseInt(req.params.schoolId));
      res.json(timeSlots);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch time slots" });
    }
  });

  app.post("/api/schools/:schoolId/time-slots", async (req, res) => {
    try {
      const timeSlotData = insertTimeSlotSchema.parse({
        ...req.body,
        schoolId: parseInt(req.params.schoolId),
      });
      const timeSlot = await storage.createTimeSlot(timeSlotData);
      res.status(201).json(timeSlot);
    } catch (error) {
      res.status(400).json({ message: "Invalid time slot data" });
    }
  });

  // Schedules
  app.get("/api/schools/:schoolId/schedules", async (req, res) => {
    try {
      const schedules = await storage.getSchedulesBySchool(parseInt(req.params.schoolId));
      res.json(schedules);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch schedules" });
    }
  });

  app.get("/api/classes/:classId/schedules", async (req, res) => {
    try {
      const schedules = await storage.getSchedulesByClass(parseInt(req.params.classId));
      res.json(schedules);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch class schedules" });
    }
  });

  app.post("/api/schools/:schoolId/schedules", async (req, res) => {
    try {
      const scheduleData = insertScheduleSchema.parse({
        ...req.body,
        schoolId: parseInt(req.params.schoolId),
      });
      
      const schedule = await storage.createSchedule(scheduleData);
      
      // Check for conflicts after creating schedule
      const conflicts = await detectConflicts(parseInt(req.params.schoolId), storage);
      
      res.status(201).json({ schedule, conflicts });
    } catch (error) {
      res.status(400).json({ message: "Invalid schedule data" });
    }
  });

  app.put("/api/schedules/:id", async (req, res) => {
    try {
      const scheduleData = insertScheduleSchema.partial().parse(req.body);
      const schedule = await storage.updateSchedule(parseInt(req.params.id), scheduleData);
      
      // Check for conflicts after updating schedule
      const conflicts = await detectConflicts(schedule.schoolId, storage);
      
      res.json({ schedule, conflicts });
    } catch (error) {
      res.status(400).json({ message: "Invalid schedule data" });
    }
  });

  app.delete("/api/schedules/:id", async (req, res) => {
    try {
      await storage.deleteSchedule(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete schedule" });
    }
  });

  // Conflicts
  app.get("/api/schools/:schoolId/conflicts", async (req, res) => {
    try {
      const conflicts = await storage.getConflictsBySchool(parseInt(req.params.schoolId));
      res.json(conflicts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conflicts" });
    }
  });

  app.post("/api/conflicts/:id/resolve", async (req, res) => {
    try {
      const conflict = await storage.resolveConflict(parseInt(req.params.id));
      res.json(conflict);
    } catch (error) {
      res.status(500).json({ message: "Failed to resolve conflict" });
    }
  });

  // Rules
  app.get("/api/schools/:schoolId/rules", async (req, res) => {
    try {
      const rules = await storage.getRulesBySchool(parseInt(req.params.schoolId));
      res.json(rules);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rules" });
    }
  });

  app.post("/api/schools/:schoolId/rules", async (req, res) => {
    try {
      const ruleData = insertRuleSchema.parse({
        ...req.body,
        schoolId: parseInt(req.params.schoolId),
      });
      const rule = await storage.createRule(ruleData);
      res.status(201).json(rule);
    } catch (error) {
      res.status(400).json({ message: "Invalid rule data" });
    }
  });

  app.put("/api/rules/:id", async (req, res) => {
    try {
      const ruleData = insertRuleSchema.partial().parse(req.body);
      const rule = await storage.updateRule(parseInt(req.params.id), ruleData);
      res.json(rule);
    } catch (error) {
      res.status(400).json({ message: "Invalid rule data" });
    }
  });

  app.delete("/api/rules/:id", async (req, res) => {
    try {
      await storage.deleteRule(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete rule" });
    }
  });

  // Stats
  app.get("/api/schools/:schoolId/stats", async (req, res) => {
    try {
      const stats = await storage.getScheduleStats(parseInt(req.params.schoolId));
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Conflict detection endpoint
  app.post("/api/schools/:schoolId/detect-conflicts", async (req, res) => {
    try {
      const conflicts = await detectConflicts(parseInt(req.params.schoolId), storage);
      res.json(conflicts);
    } catch (error) {
      res.status(500).json({ message: "Failed to detect conflicts" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Conflict detection service
async function detectConflicts(schoolId: number, storage: any): Promise<any[]> {
  const schedules = await storage.getSchedulesBySchool(schoolId);
  const conflicts: any[] = [];

  // Check for teacher double booking
  const teacherSlots = new Map();
  schedules.forEach((schedule: any) => {
    const key = `${schedule.teacherId}-${schedule.timeSlotId}-${schedule.dayOfWeek}`;
    if (teacherSlots.has(key)) {
      conflicts.push({
        type: "teacher_double_booking",
        description: `${schedule.teacher.name} is scheduled for multiple classes at the same time`,
        severity: "high",
        scheduleIds: [teacherSlots.get(key), schedule.id],
        schoolId,
      });
    } else {
      teacherSlots.set(key, schedule.id);
    }
  });

  // Check for classroom double booking
  const classroomSlots = new Map();
  schedules.forEach((schedule: any) => {
    const key = `${schedule.classroomId}-${schedule.timeSlotId}-${schedule.dayOfWeek}`;
    if (classroomSlots.has(key)) {
      conflicts.push({
        type: "classroom_double_booking",
        description: `${schedule.classroom.name} is booked for multiple classes at the same time`,
        severity: "high",
        scheduleIds: [classroomSlots.get(key), schedule.id],
        schoolId,
      });
    } else {
      classroomSlots.set(key, schedule.id);
    }
  });

  // Save conflicts to database
  for (const conflict of conflicts) {
    await storage.createConflict(conflict);
  }

  return conflicts;
}
