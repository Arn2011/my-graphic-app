import {
  schools, teachers, classrooms, subjects, classes, timeSlots, schedules, conflicts, rules,
  type School, type Teacher, type Classroom, type Subject, type Class, type TimeSlot, 
  type Schedule, type Conflict, type Rule, type ScheduleWithDetails, type ConflictWithDetails,
  type InsertSchool, type InsertTeacher, type InsertClassroom, type InsertSubject, 
  type InsertClass, type InsertTimeSlot, type InsertSchedule, type InsertConflict, type InsertRule
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, inArray } from "drizzle-orm";

export interface IStorage {
  // Schools
  getSchool(id: number): Promise<School | undefined>;
  createSchool(school: InsertSchool): Promise<School>;
  
  // Teachers
  getTeacher(id: number): Promise<Teacher | undefined>;
  getTeachersBySchool(schoolId: number): Promise<Teacher[]>;
  getAvailableTeachers(schoolId: number, timeSlotId: number, dayOfWeek: number): Promise<Teacher[]>;
  createTeacher(teacher: InsertTeacher): Promise<Teacher>;
  updateTeacher(id: number, teacher: Partial<InsertTeacher>): Promise<Teacher>;
  
  // Classrooms
  getClassroom(id: number): Promise<Classroom | undefined>;
  getClassroomsBySchool(schoolId: number): Promise<Classroom[]>;
  getAvailableClassrooms(schoolId: number, timeSlotId: number, dayOfWeek: number): Promise<Classroom[]>;
  createClassroom(classroom: InsertClassroom): Promise<Classroom>;
  updateClassroom(id: number, classroom: Partial<InsertClassroom>): Promise<Classroom>;
  
  // Subjects
  getSubject(id: number): Promise<Subject | undefined>;
  getSubjectsBySchool(schoolId: number): Promise<Subject[]>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  updateSubject(id: number, subject: Partial<InsertSubject>): Promise<Subject>;
  
  // Classes
  getClass(id: number): Promise<Class | undefined>;
  getClassesBySchool(schoolId: number): Promise<Class[]>;
  createClass(classData: InsertClass): Promise<Class>;
  updateClass(id: number, classData: Partial<InsertClass>): Promise<Class>;
  
  // Time Slots
  getTimeSlot(id: number): Promise<TimeSlot | undefined>;
  getTimeSlotsBySchool(schoolId: number): Promise<TimeSlot[]>;
  createTimeSlot(timeSlot: InsertTimeSlot): Promise<TimeSlot>;
  updateTimeSlot(id: number, timeSlot: Partial<InsertTimeSlot>): Promise<TimeSlot>;
  
  // Schedules
  getSchedule(id: number): Promise<ScheduleWithDetails | undefined>;
  getSchedulesBySchool(schoolId: number): Promise<ScheduleWithDetails[]>;
  getSchedulesByClass(classId: number): Promise<ScheduleWithDetails[]>;
  createSchedule(schedule: InsertSchedule): Promise<Schedule>;
  updateSchedule(id: number, schedule: Partial<InsertSchedule>): Promise<Schedule>;
  deleteSchedule(id: number): Promise<void>;
  
  // Conflicts
  getConflict(id: number): Promise<ConflictWithDetails | undefined>;
  getConflictsBySchool(schoolId: number): Promise<ConflictWithDetails[]>;
  createConflict(conflict: InsertConflict): Promise<Conflict>;
  resolveConflict(id: number): Promise<Conflict>;
  
  // Rules
  getRule(id: number): Promise<Rule | undefined>;
  getRulesBySchool(schoolId: number): Promise<Rule[]>;
  createRule(rule: InsertRule): Promise<Rule>;
  updateRule(id: number, rule: Partial<InsertRule>): Promise<Rule>;
  deleteRule(id: number): Promise<void>;
  
  // Stats
  getScheduleStats(schoolId: number): Promise<{
    totalClasses: number;
    activeTeachers: number;
    conflicts: number;
    completion: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // Schools
  async getSchool(id: number): Promise<School | undefined> {
    const [school] = await db.select().from(schools).where(eq(schools.id, id));
    return school || undefined;
  }

  async createSchool(school: InsertSchool): Promise<School> {
    const [newSchool] = await db.insert(schools).values(school).returning();
    return newSchool;
  }

  // Teachers
  async getTeacher(id: number): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.id, id));
    return teacher || undefined;
  }

  async getTeachersBySchool(schoolId: number): Promise<Teacher[]> {
    return await db.select().from(teachers).where(eq(teachers.schoolId, schoolId));
  }

  async getAvailableTeachers(schoolId: number, timeSlotId: number, dayOfWeek: number): Promise<Teacher[]> {
    const busyTeachers = await db
      .select({ teacherId: schedules.teacherId })
      .from(schedules)
      .where(
        and(
          eq(schedules.schoolId, schoolId),
          eq(schedules.timeSlotId, timeSlotId),
          eq(schedules.dayOfWeek, dayOfWeek),
          eq(schedules.isActive, true)
        )
      );

    const busyTeacherIds = busyTeachers.map(t => t.teacherId);
    
    if (busyTeacherIds.length === 0) {
      return await db.select().from(teachers).where(
        and(eq(teachers.schoolId, schoolId), eq(teachers.isActive, true))
      );
    }

    return await db.select().from(teachers).where(
      and(
        eq(teachers.schoolId, schoolId),
        eq(teachers.isActive, true),
        // @ts-ignore
        !inArray(teachers.id, busyTeacherIds)
      )
    );
  }

  async createTeacher(teacher: InsertTeacher): Promise<Teacher> {
    const [newTeacher] = await db.insert(teachers).values(teacher).returning();
    return newTeacher;
  }

  async updateTeacher(id: number, teacher: Partial<InsertTeacher>): Promise<Teacher> {
    const [updatedTeacher] = await db.update(teachers).set(teacher).where(eq(teachers.id, id)).returning();
    return updatedTeacher;
  }

  // Classrooms
  async getClassroom(id: number): Promise<Classroom | undefined> {
    const [classroom] = await db.select().from(classrooms).where(eq(classrooms.id, id));
    return classroom || undefined;
  }

  async getClassroomsBySchool(schoolId: number): Promise<Classroom[]> {
    return await db.select().from(classrooms).where(eq(classrooms.schoolId, schoolId));
  }

  async getAvailableClassrooms(schoolId: number, timeSlotId: number, dayOfWeek: number): Promise<Classroom[]> {
    const busyClassrooms = await db
      .select({ classroomId: schedules.classroomId })
      .from(schedules)
      .where(
        and(
          eq(schedules.schoolId, schoolId),
          eq(schedules.timeSlotId, timeSlotId),
          eq(schedules.dayOfWeek, dayOfWeek),
          eq(schedules.isActive, true)
        )
      );

    const busyClassroomIds = busyClassrooms.map(c => c.classroomId);
    
    if (busyClassroomIds.length === 0) {
      return await db.select().from(classrooms).where(
        and(eq(classrooms.schoolId, schoolId), eq(classrooms.isActive, true))
      );
    }

    return await db.select().from(classrooms).where(
      and(
        eq(classrooms.schoolId, schoolId),
        eq(classrooms.isActive, true),
        // @ts-ignore
        !inArray(classrooms.id, busyClassroomIds)
      )
    );
  }

  async createClassroom(classroom: InsertClassroom): Promise<Classroom> {
    const [newClassroom] = await db.insert(classrooms).values(classroom).returning();
    return newClassroom;
  }

  async updateClassroom(id: number, classroom: Partial<InsertClassroom>): Promise<Classroom> {
    const [updatedClassroom] = await db.update(classrooms).set(classroom).where(eq(classrooms.id, id)).returning();
    return updatedClassroom;
  }

  // Subjects
  async getSubject(id: number): Promise<Subject | undefined> {
    const [subject] = await db.select().from(subjects).where(eq(subjects.id, id));
    return subject || undefined;
  }

  async getSubjectsBySchool(schoolId: number): Promise<Subject[]> {
    return await db.select().from(subjects).where(eq(subjects.schoolId, schoolId));
  }

  async createSubject(subject: InsertSubject): Promise<Subject> {
    const [newSubject] = await db.insert(subjects).values(subject).returning();
    return newSubject;
  }

  async updateSubject(id: number, subject: Partial<InsertSubject>): Promise<Subject> {
    const [updatedSubject] = await db.update(subjects).set(subject).where(eq(subjects.id, id)).returning();
    return updatedSubject;
  }

  // Classes
  async getClass(id: number): Promise<Class | undefined> {
    const [classData] = await db.select().from(classes).where(eq(classes.id, id));
    return classData || undefined;
  }

  async getClassesBySchool(schoolId: number): Promise<Class[]> {
    return await db.select().from(classes).where(eq(classes.schoolId, schoolId));
  }

  async createClass(classData: InsertClass): Promise<Class> {
    const [newClass] = await db.insert(classes).values(classData).returning();
    return newClass;
  }

  async updateClass(id: number, classData: Partial<InsertClass>): Promise<Class> {
    const [updatedClass] = await db.update(classes).set(classData).where(eq(classes.id, id)).returning();
    return updatedClass;
  }

  // Time Slots
  async getTimeSlot(id: number): Promise<TimeSlot | undefined> {
    const [timeSlot] = await db.select().from(timeSlots).where(eq(timeSlots.id, id));
    return timeSlot || undefined;
  }

  async getTimeSlotsBySchool(schoolId: number): Promise<TimeSlot[]> {
    return await db.select().from(timeSlots).where(eq(timeSlots.schoolId, schoolId));
  }

  async createTimeSlot(timeSlot: InsertTimeSlot): Promise<TimeSlot> {
    const [newTimeSlot] = await db.insert(timeSlots).values(timeSlot).returning();
    return newTimeSlot;
  }

  async updateTimeSlot(id: number, timeSlot: Partial<InsertTimeSlot>): Promise<TimeSlot> {
    const [updatedTimeSlot] = await db.update(timeSlots).set(timeSlot).where(eq(timeSlots.id, id)).returning();
    return updatedTimeSlot;
  }

  // Schedules
  async getSchedule(id: number): Promise<ScheduleWithDetails | undefined> {
    const [schedule] = await db
      .select()
      .from(schedules)
      .leftJoin(classes, eq(schedules.classId, classes.id))
      .leftJoin(teachers, eq(schedules.teacherId, teachers.id))
      .leftJoin(subjects, eq(schedules.subjectId, subjects.id))
      .leftJoin(classrooms, eq(schedules.classroomId, classrooms.id))
      .leftJoin(timeSlots, eq(schedules.timeSlotId, timeSlots.id))
      .where(eq(schedules.id, id));

    if (!schedule || !schedule.classes || !schedule.teachers || !schedule.subjects || !schedule.classrooms || !schedule.time_slots) {
      return undefined;
    }

    return {
      ...schedule.schedules,
      class: schedule.classes,
      teacher: schedule.teachers,
      subject: schedule.subjects,
      classroom: schedule.classrooms,
      timeSlot: schedule.time_slots,
    };
  }

  async getSchedulesBySchool(schoolId: number): Promise<ScheduleWithDetails[]> {
    const scheduleData = await db
      .select()
      .from(schedules)
      .leftJoin(classes, eq(schedules.classId, classes.id))
      .leftJoin(teachers, eq(schedules.teacherId, teachers.id))
      .leftJoin(subjects, eq(schedules.subjectId, subjects.id))
      .leftJoin(classrooms, eq(schedules.classroomId, classrooms.id))
      .leftJoin(timeSlots, eq(schedules.timeSlotId, timeSlots.id))
      .where(eq(schedules.schoolId, schoolId));

    return scheduleData
      .filter(s => s.classes && s.teachers && s.subjects && s.classrooms && s.time_slots)
      .map(s => ({
        ...s.schedules,
        class: s.classes!,
        teacher: s.teachers!,
        subject: s.subjects!,
        classroom: s.classrooms!,
        timeSlot: s.time_slots!,
      }));
  }

  async getSchedulesByClass(classId: number): Promise<ScheduleWithDetails[]> {
    const scheduleData = await db
      .select()
      .from(schedules)
      .leftJoin(classes, eq(schedules.classId, classes.id))
      .leftJoin(teachers, eq(schedules.teacherId, teachers.id))
      .leftJoin(subjects, eq(schedules.subjectId, subjects.id))
      .leftJoin(classrooms, eq(schedules.classroomId, classrooms.id))
      .leftJoin(timeSlots, eq(schedules.timeSlotId, timeSlots.id))
      .where(eq(schedules.classId, classId));

    return scheduleData
      .filter(s => s.classes && s.teachers && s.subjects && s.classrooms && s.time_slots)
      .map(s => ({
        ...s.schedules,
        class: s.classes!,
        teacher: s.teachers!,
        subject: s.subjects!,
        classroom: s.classrooms!,
        timeSlot: s.time_slots!,
      }));
  }

  async createSchedule(schedule: InsertSchedule): Promise<Schedule> {
    const [newSchedule] = await db.insert(schedules).values(schedule).returning();
    return newSchedule;
  }

  async updateSchedule(id: number, schedule: Partial<InsertSchedule>): Promise<Schedule> {
    const [updatedSchedule] = await db.update(schedules).set(schedule).where(eq(schedules.id, id)).returning();
    return updatedSchedule;
  }

  async deleteSchedule(id: number): Promise<void> {
    await db.update(schedules).set({ isActive: false }).where(eq(schedules.id, id));
  }

  // Conflicts
  async getConflict(id: number): Promise<ConflictWithDetails | undefined> {
    const [conflict] = await db.select().from(conflicts).where(eq(conflicts.id, id));
    return conflict || undefined;
  }

  async getConflictsBySchool(schoolId: number): Promise<ConflictWithDetails[]> {
    return await db.select().from(conflicts).where(
      and(eq(conflicts.schoolId, schoolId), eq(conflicts.isResolved, false))
    );
  }

  async createConflict(conflict: InsertConflict): Promise<Conflict> {
    const [newConflict] = await db.insert(conflicts).values(conflict).returning();
    return newConflict;
  }

  async resolveConflict(id: number): Promise<Conflict> {
    const [resolvedConflict] = await db
      .update(conflicts)
      .set({ isResolved: true, resolvedAt: new Date() })
      .where(eq(conflicts.id, id))
      .returning();
    return resolvedConflict;
  }

  // Rules
  async getRule(id: number): Promise<Rule | undefined> {
    const [rule] = await db.select().from(rules).where(eq(rules.id, id));
    return rule || undefined;
  }

  async getRulesBySchool(schoolId: number): Promise<Rule[]> {
    return await db.select().from(rules).where(eq(rules.schoolId, schoolId));
  }

  async createRule(rule: InsertRule): Promise<Rule> {
    const [newRule] = await db.insert(rules).values(rule).returning();
    return newRule;
  }

  async updateRule(id: number, rule: Partial<InsertRule>): Promise<Rule> {
    const [updatedRule] = await db.update(rules).set(rule).where(eq(rules.id, id)).returning();
    return updatedRule;
  }

  async deleteRule(id: number): Promise<void> {
    await db.update(rules).set({ isActive: false }).where(eq(rules.id, id));
  }

  // Stats
  async getScheduleStats(schoolId: number): Promise<{
    totalClasses: number;
    activeTeachers: number;
    conflicts: number;
    completion: number;
  }> {
    const totalSchedules = await db
      .select()
      .from(schedules)
      .where(and(eq(schedules.schoolId, schoolId), eq(schedules.isActive, true)));

    const activeTeachersCount = await db
      .select()
      .from(teachers)
      .where(and(eq(teachers.schoolId, schoolId), eq(teachers.isActive, true)));

    const conflictsCount = await db
      .select()
      .from(conflicts)
      .where(and(eq(conflicts.schoolId, schoolId), eq(conflicts.isResolved, false)));

    const totalTimeSlots = await db
      .select()
      .from(timeSlots)
      .where(and(eq(timeSlots.schoolId, schoolId), eq(timeSlots.isActive, true)));

    const completion = totalTimeSlots.length > 0 ? Math.round((totalSchedules.length / totalTimeSlots.length) * 100) : 0;

    return {
      totalClasses: totalSchedules.length,
      activeTeachers: activeTeachersCount.length,
      conflicts: conflictsCount.length,
      completion: Math.min(completion, 100),
    };
  }
}

export const storage = new DatabaseStorage();
