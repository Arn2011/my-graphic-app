import { pgTable, text, serial, integer, boolean, timestamp, time, uuid, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const schools = pgTable("schools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").references(() => schools.id).notNull(),
  name: text("name").notNull(),
  email: text("email").unique(),
  phone: text("phone"),
  subjects: text("subjects").array(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const classrooms = pgTable("classrooms", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").references(() => schools.id).notNull(),
  name: text("name").notNull(),
  capacity: integer("capacity").default(30),
  type: text("type"), // lab, classroom, gym, etc.
  equipment: text("equipment").array(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").references(() => schools.id).notNull(),
  name: text("name").notNull(),
  code: text("code"),
  color: text("color").default("#667eea"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").references(() => schools.id).notNull(),
  name: text("name").notNull(), // Grade 10A, Grade 11B, etc.
  level: text("level"), // Grade 10, Grade 11, etc.
  section: text("section"), // A, B, C, etc.
  studentCount: integer("student_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const timeSlots = pgTable("time_slots", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").references(() => schools.id).notNull(),
  name: text("name").notNull(), // Period 1, Period 2, etc.
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
  dayOfWeek: integer("day_of_week").notNull(), // 1-7 (Monday-Sunday)
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").references(() => schools.id).notNull(),
  classId: integer("class_id").references(() => classes.id).notNull(),
  teacherId: integer("teacher_id").references(() => teachers.id).notNull(),
  subjectId: integer("subject_id").references(() => subjects.id).notNull(),
  classroomId: integer("classroom_id").references(() => classrooms.id).notNull(),
  timeSlotId: integer("time_slot_id").references(() => timeSlots.id).notNull(),
  dayOfWeek: integer("day_of_week").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const conflicts = pgTable("conflicts", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").references(() => schools.id).notNull(),
  type: text("type").notNull(), // teacher_double_booking, room_unavailable, etc.
  description: text("description").notNull(),
  severity: text("severity").default("medium"), // low, medium, high
  scheduleIds: integer("schedule_ids").array().notNull(),
  isResolved: boolean("is_resolved").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

export const rules = pgTable("rules", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").references(() => schools.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  condition: text("condition").notNull(), // JSON string of if-then conditions
  action: text("action").notNull(), // JSON string of actions
  isActive: boolean("is_active").default(true),
  priority: integer("priority").default(5),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const schoolsRelations = relations(schools, ({ many }) => ({
  teachers: many(teachers),
  classrooms: many(classrooms),
  subjects: many(subjects),
  classes: many(classes),
  timeSlots: many(timeSlots),
  schedules: many(schedules),
  conflicts: many(conflicts),
  rules: many(rules),
}));

export const teachersRelations = relations(teachers, ({ one, many }) => ({
  school: one(schools, {
    fields: [teachers.schoolId],
    references: [schools.id],
  }),
  schedules: many(schedules),
}));

export const classroomsRelations = relations(classrooms, ({ one, many }) => ({
  school: one(schools, {
    fields: [classrooms.schoolId],
    references: [schools.id],
  }),
  schedules: many(schedules),
}));

export const subjectsRelations = relations(subjects, ({ one, many }) => ({
  school: one(schools, {
    fields: [subjects.schoolId],
    references: [schools.id],
  }),
  schedules: many(schedules),
}));

export const classesRelations = relations(classes, ({ one, many }) => ({
  school: one(schools, {
    fields: [classes.schoolId],
    references: [schools.id],
  }),
  schedules: many(schedules),
}));

export const timeSlotsRelations = relations(timeSlots, ({ one, many }) => ({
  school: one(schools, {
    fields: [timeSlots.schoolId],
    references: [schools.id],
  }),
  schedules: many(schedules),
}));

export const schedulesRelations = relations(schedules, ({ one }) => ({
  school: one(schools, {
    fields: [schedules.schoolId],
    references: [schools.id],
  }),
  class: one(classes, {
    fields: [schedules.classId],
    references: [classes.id],
  }),
  teacher: one(teachers, {
    fields: [schedules.teacherId],
    references: [teachers.id],
  }),
  subject: one(subjects, {
    fields: [schedules.subjectId],
    references: [subjects.id],
  }),
  classroom: one(classrooms, {
    fields: [schedules.classroomId],
    references: [classrooms.id],
  }),
  timeSlot: one(timeSlots, {
    fields: [schedules.timeSlotId],
    references: [timeSlots.id],
  }),
}));

export const conflictsRelations = relations(conflicts, ({ one }) => ({
  school: one(schools, {
    fields: [conflicts.schoolId],
    references: [schools.id],
  }),
}));

export const rulesRelations = relations(rules, ({ one }) => ({
  school: one(schools, {
    fields: [rules.schoolId],
    references: [schools.id],
  }),
}));

// Insert schemas
export const insertSchoolSchema = createInsertSchema(schools).omit({
  id: true,
  createdAt: true,
});

export const insertTeacherSchema = createInsertSchema(teachers).omit({
  id: true,
  createdAt: true,
});

export const insertClassroomSchema = createInsertSchema(classrooms).omit({
  id: true,
  createdAt: true,
});

export const insertSubjectSchema = createInsertSchema(subjects).omit({
  id: true,
  createdAt: true,
});

export const insertClassSchema = createInsertSchema(classes).omit({
  id: true,
  createdAt: true,
});

export const insertTimeSlotSchema = createInsertSchema(timeSlots).omit({
  id: true,
  createdAt: true,
});

export const insertScheduleSchema = createInsertSchema(schedules).omit({
  id: true,
  createdAt: true,
});

export const insertConflictSchema = createInsertSchema(conflicts).omit({
  id: true,
  createdAt: true,
  resolvedAt: true,
});

export const insertRuleSchema = createInsertSchema(rules).omit({
  id: true,
  createdAt: true,
});

// Types
export type School = typeof schools.$inferSelect;
export type Teacher = typeof teachers.$inferSelect;
export type Classroom = typeof classrooms.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type Class = typeof classes.$inferSelect;
export type TimeSlot = typeof timeSlots.$inferSelect;
export type Schedule = typeof schedules.$inferSelect;
export type Conflict = typeof conflicts.$inferSelect;
export type Rule = typeof rules.$inferSelect;

export type InsertSchool = z.infer<typeof insertSchoolSchema>;
export type InsertTeacher = z.infer<typeof insertTeacherSchema>;
export type InsertClassroom = z.infer<typeof insertClassroomSchema>;
export type InsertSubject = z.infer<typeof insertSubjectSchema>;
export type InsertClass = z.infer<typeof insertClassSchema>;
export type InsertTimeSlot = z.infer<typeof insertTimeSlotSchema>;
export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
export type InsertConflict = z.infer<typeof insertConflictSchema>;
export type InsertRule = z.infer<typeof insertRuleSchema>;

// Extended types for API responses
export type ScheduleWithDetails = Schedule & {
  class: Class;
  teacher: Teacher;
  subject: Subject;
  classroom: Classroom;
  timeSlot: TimeSlot;
};

export type ConflictWithDetails = Conflict & {
  schedules?: ScheduleWithDetails[];
};
