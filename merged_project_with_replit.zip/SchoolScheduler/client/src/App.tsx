import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Sidebar from "@/components/layout/sidebar";
import TimetablePage from "@/pages/timetable";
import TeachersPage from "@/pages/teachers";
import ClassesPage from "@/pages/classes";
import RoomsPage from "@/pages/rooms";
import SubjectsPage from "@/pages/subjects";
import ExportPage from "@/pages/export";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Switch>
          <Route path="/" component={TimetablePage} />
          <Route path="/timetables" component={TimetablePage} />
          <Route path="/teachers" component={TeachersPage} />
          <Route path="/classes" component={ClassesPage} />
          <Route path="/rooms" component={RoomsPage} />
          <Route path="/subjects" component={SubjectsPage} />
          <Route path="/export" component={ExportPage} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
