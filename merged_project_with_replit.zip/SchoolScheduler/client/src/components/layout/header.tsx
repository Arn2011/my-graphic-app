import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Class } from "@shared/schema";

interface HeaderProps {
  title: string;
  subtitle: string;
  showViewSwitcher?: boolean;
  showClassSelector?: boolean;
  showAddButton?: boolean;
  onAddClick?: () => void;
  currentView?: "class" | "teacher" | "room";
  onViewChange?: (view: "class" | "teacher" | "room") => void;
  selectedClassId?: number;
  onClassChange?: (classId: number) => void;
}

export default function Header({
  title,
  subtitle,
  showViewSwitcher = false,
  showClassSelector = false,
  showAddButton = false,
  onAddClick,
  currentView = "class",
  onViewChange,
  selectedClassId,
  onClassChange,
}: HeaderProps) {
  const { data: classes = [] } = useQuery<Class[]>({
    queryKey: ["/api/classes"],
    enabled: showClassSelector,
  });

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">{title}</h2>
          <p className="text-gray-600 mt-1">{subtitle}</p>
        </div>
        
        <div className="flex items-center space-x-4">
          {showViewSwitcher && (
            <div className="bg-gray-100 p-1 rounded-lg">
              <Button
                variant={currentView === "class" ? "default" : "ghost"}
                size="sm"
                onClick={() => onViewChange?.("class")}
              >
                By Class
              </Button>
              <Button
                variant={currentView === "teacher" ? "default" : "ghost"}
                size="sm"
                onClick={() => onViewChange?.("teacher")}
              >
                By Teacher
              </Button>
              <Button
                variant={currentView === "room" ? "default" : "ghost"}
                size="sm"
                onClick={() => onViewChange?.("room")}
              >
                By Room
              </Button>
            </div>
          )}
          
          {showClassSelector && (
            <Select
              value={selectedClassId?.toString()}
              onValueChange={(value) => onClassChange?.(Number(value))}
            >
              <SelectTrigger className="w-56">
                <SelectValue placeholder="Select Class" />
              </SelectTrigger>
              <SelectContent>
                {classes.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id.toString()}>
                    {cls.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          
          {showAddButton && (
            <Button onClick={onAddClick} className="bg-secondary hover:bg-secondary/90">
              <Plus className="mr-2" size={16} />
              Add Period
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
