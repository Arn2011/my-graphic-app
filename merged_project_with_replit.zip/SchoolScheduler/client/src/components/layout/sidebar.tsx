import { Link, useLocation } from "wouter";
import { 
  Calendar, 
  Presentation, 
  Users, 
  DoorOpen, 
  Book, 
  Download, 
  User 
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { path: "/timetables", icon: Calendar, label: "Timetables" },
    { path: "/teachers", icon: Presentation, label: "Teachers" },
    { path: "/classes", icon: Users, label: "Classes" },
    { path: "/rooms", icon: DoorOpen, label: "Rooms" },
    { path: "/subjects", icon: Book, label: "Subjects" },
    { path: "/export", icon: Download, label: "Export" },
  ];

  return (
    <div className="w-64 bg-white shadow-lg flex flex-col border-r">
      {/* Logo/Header */}
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-xl font-bold text-gray-800">
          <Calendar className="inline mr-2 text-primary" size={20} />
          SVPHIS Timetable
        </h1>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path || (location === "/" && item.path === "/timetables");
          
          return (
            <Link key={item.path} href={item.path}>
              <div
                className={`flex items-center px-4 py-3 rounded-lg transition-colors cursor-pointer ${
                  isActive
                    ? "text-primary bg-blue-50 border-l-4 border-primary"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                <Icon className="mr-3" size={20} />
                {item.label}
              </div>
            </Link>
          );
        })}
      </nav>
      
      {/* User Profile */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
            <User className="text-white" size={20} />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-800">Admin User</p>
            <p className="text-xs text-gray-500">Administrator</p>
          </div>
        </div>
      </div>
    </div>
  );
}
