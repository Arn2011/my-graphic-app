import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, AlertCircle } from "lucide-react";
import type { PeriodWithDetails } from "@shared/schema";

export default function ConflictAlerts() {
  const { data: periods = [] } = useQuery<PeriodWithDetails[]>({
    queryKey: ["/api/periods"],
  });

  // Simple conflict detection logic
  const conflicts = periods.reduce((acc: string[], period, index) => {
    const conflictingPeriods = periods.slice(index + 1).filter(other => 
      period.dayOfWeek === other.dayOfWeek &&
      period.startTime === other.startTime &&
      (period.teacherId === other.teacherId || period.roomId === other.roomId)
    );

    conflictingPeriods.forEach(conflicting => {
      if (period.teacherId === conflicting.teacherId) {
        acc.push(`${period.teacher.name} has conflicting classes on ${getDayName(period.dayOfWeek)} at ${period.startTime}`);
      }
      if (period.roomId === conflicting.roomId) {
        acc.push(`${period.room.name} is double-booked on ${getDayName(period.dayOfWeek)} at ${period.startTime}`);
      }
    });

    return acc;
  }, []);

  const getDayName = (dayOfWeek: number) => {
    const days = ["", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
    return days[dayOfWeek];
  };

  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Scheduling Alerts</h3>
      <div className="space-y-3">
        {conflicts.length === 0 ? (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-start">
              <AlertCircle className="h-5 w-5 text-green-500 mt-0.5 mr-3" />
              <div>
                <h4 className="font-medium text-green-800">No Conflicts</h4>
                <p className="text-sm text-green-700 mt-1">All schedules are properly coordinated</p>
              </div>
            </div>
          </div>
        ) : (
          conflicts.map((conflict, index) => (
            <div key={index} className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-start">
                <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5 mr-3" />
                <div>
                  <h4 className="font-medium text-red-800">Conflict Detected</h4>
                  <p className="text-sm text-red-700 mt-1">{conflict}</p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
