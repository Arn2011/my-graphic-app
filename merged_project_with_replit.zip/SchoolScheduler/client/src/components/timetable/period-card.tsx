import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { PeriodWithDetails } from "@shared/schema";

interface PeriodCardProps {
  period: PeriodWithDetails;
  colorClass: string;
}

export default function PeriodCard({ period, colorClass }: PeriodCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deletePeriod = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/periods/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/periods"] });
      toast({
        title: "Success",
        description: "Period deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete period",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this period?")) {
      deletePeriod.mutate(period.id);
    }
  };

  return (
    <div
      className={`${colorClass} border-l-4 p-3 rounded-lg cursor-move hover:shadow-md transition-shadow group relative`}
      draggable
    >
      <div className="font-medium text-sm text-gray-800">{period.subject.name}</div>
      <div className="text-xs text-gray-600">
        {period.teacher.name} • {period.room.name}
      </div>
      <button
        onClick={handleDelete}
        className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity text-gray-400 hover:text-red-500 text-xs"
      >
        ×
      </button>
    </div>
  );
}
