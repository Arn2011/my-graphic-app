import { useQuery } from "@tanstack/react-query";
import type { Subject, Teacher } from "@shared/schema";

export default function SubjectPool() {
  const { data: subjects = [] } = useQuery<Subject[]>({
    queryKey: ["/api/subjects"],
  });

  const { data: teachers = [] } = useQuery<Teacher[]>({
    queryKey: ["/api/teachers"],
  });

  const getSubjectColorClass = (subjectName: string) => {
    const subject = subjectName.toLowerCase();
    if (subject.includes("math")) return "subject-math";
    if (subject.includes("physic") || subject.includes("chemistr") || subject.includes("biolog")) return "subject-science";
    if (subject.includes("english") || subject.includes("literatur")) return "subject-english";
    if (subject.includes("history") || subject.includes("geograph") || subject.includes("social")) return "subject-history";
    if (subject.includes("physical") || subject.includes("pe") || subject.includes("sport")) return "subject-pe";
    if (subject.includes("art") || subject.includes("music")) return "subject-art";
    return "subject-math";
  };

  const getTeacherForSubject = (subjectName: string) => {
    return teachers.find(teacher => 
      teacher.subject.toLowerCase().includes(subjectName.toLowerCase()) ||
      subjectName.toLowerCase().includes(teacher.subject.toLowerCase())
    )?.name || "Available";
  };

  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Available Subjects</h3>
      <div className="space-y-2">
        {subjects.map((subject) => (
          <div
            key={subject.id}
            className={`${getSubjectColorClass(subject.name)} border-l-4 p-3 rounded-lg cursor-move hover:shadow-md transition-shadow`}
            draggable
          >
            <div className="font-medium text-sm text-gray-800">{subject.name}</div>
            <div className="text-xs text-gray-600">{getTeacherForSubject(subject.name)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
