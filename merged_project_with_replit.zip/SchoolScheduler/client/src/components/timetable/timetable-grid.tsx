import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import PeriodCard from "./period-card";
import type { PeriodWithDetails, Class } from "@shared/schema";

interface TimetableGridProps {
  periods: PeriodWithDetails[];
  selectedClass?: Class;
  viewType: "class" | "teacher" | "room";
}

const timeSlots = [
  { time: "8:50 AM", hour: 8, minute: 50, period: 0, isPrayer: true },
  { time: "9:40 AM", hour: 9, minute: 40, period: 1 },
  { time: "10:25 AM", hour: 10, minute: 25, period: 2 },
  { time: "11:15 AM", hour: 11, minute: 15, period: 3 },
  { time: "12:00 PM", hour: 12, minute: 0, period: 4 },
  { time: "12:45 PM", hour: 12, minute: 45, period: 5 },
  { time: "1:45 PM", hour: 13, minute: 45, period: 6 },
  { time: "2:30 PM", hour: 14, minute: 30, period: 7 },
  { time: "3:15 PM", hour: 15, minute: 15, period: 8 },
  { time: "4:00 PM", hour: 16, minute: 0, period: 9, isPrep: true },
];

const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export default function TimetableGrid({ periods, selectedClass, viewType }: TimetableGridProps) {
  const organizedPeriods = useMemo(() => {
    const grid: { [key: string]: PeriodWithDetails | null } = {};
    
    periods.forEach(period => {
      // Convert time string to comparable format
      const [hourStr, minuteStr] = period.startTime.split(":");
      const hour = parseInt(hourStr);
      const minute = parseInt(minuteStr);
      
      // Find matching time slot
      const timeSlot = timeSlots.find(slot => 
        slot.hour === hour && slot.minute === minute
      );
      
      if (timeSlot) {
        const key = `${period.dayOfWeek}-${timeSlot.time}`;
        grid[key] = period;
      }
    });
    
    return grid;
  }, [periods]);

  const getPeriodForSlot = (day: number, time: string) => {
    return organizedPeriods[`${day}-${time}`];
  };

  const getSubjectColorClass = (subjectName: string) => {
    const subject = subjectName.toLowerCase();
    if (subject.includes("math")) return "subject-math";
    if (subject.includes("physic") || subject.includes("chemistr") || subject.includes("biolog")) return "subject-science";
    if (subject.includes("english") || subject.includes("literatur")) return "subject-english";
    if (subject.includes("history") || subject.includes("geograph") || subject.includes("social")) return "subject-history";
    if (subject.includes("physical") || subject.includes("pe") || subject.includes("sport")) return "subject-pe";
    if (subject.includes("art") || subject.includes("music")) return "subject-art";
    return "subject-math";
  };

  return (
    <Card className="shadow-lg">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">
            Weekly Timetable - {selectedClass?.name || "All Classes"}
          </CardTitle>
          <div className="flex items-center space-x-3">
            <span className="text-sm text-gray-500">Academic Year 2025-26</span>
            <Button variant="ghost" size="sm">
              <Printer className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                  Time
                </th>
                {days.map((day) => (
                  <th key={day} className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {day}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {timeSlots.map((slot, index) => (
                <tr key={slot.time}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {slot.time}
                  </td>
                  {days.map((day, dayIndex) => {
                    const period = getPeriodForSlot(dayIndex + 1, slot.time);
                    
                    return (
                      <td key={`${day}-${slot.time}`} className="px-6 py-4 whitespace-nowrap">
                        {slot.isPrayer ? (
                          <div className="p-3 min-h-[60px] rounded-lg bg-blue-100 border border-blue-300 flex items-center justify-center text-blue-700 text-sm font-medium">
                            🙏 Prayer Time
                          </div>
                        ) : slot.isPrep ? (
                          <div className="p-3 min-h-[60px] rounded-lg bg-purple-100 border border-purple-300 flex items-center justify-center text-purple-700 text-sm font-medium">
                            📚 Prep Time (15 min)
                          </div>
                        ) : period ? (
                          <PeriodCard
                            period={period}
                            colorClass={getSubjectColorClass(period.subject.name)}
                          />
                        ) : (
                          <div className="p-3 min-h-[60px] rounded-lg border-2 border-dashed border-gray-200 flex items-center justify-center text-gray-400 text-sm">
                            Empty
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
              
              {/* Break rows */}
              <tr className="bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  10:55 AM
                </td>
                <td colSpan={6} className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                  <div className="bg-yellow-100 border border-yellow-300 rounded-lg p-3">
                    ☕ Short Break (20 minutes)
                  </div>
                </td>
              </tr>
              
              <tr className="bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  1:15 PM
                </td>
                <td colSpan={6} className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                  <div className="bg-green-100 border border-green-300 rounded-lg p-3">
                    🍽️ Lunch Break (30 minutes)
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}