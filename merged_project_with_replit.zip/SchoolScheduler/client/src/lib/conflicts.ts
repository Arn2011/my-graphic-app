import { PeriodWithDetails, Period, InsertPeriod } from "@shared/schema";

export interface ConflictResult {
  hasConflicts: boolean;
  conflicts: ConflictDetails[];
  warnings: ConflictDetails[];
}

export interface ConflictDetails {
  type: 'teacher' | 'room' | 'class' | 'capacity' | 'preference';
  severity: 'error' | 'warning' | 'info';
  message: string;
  conflictingPeriods: PeriodWithDetails[];
  suggestions?: string[];
}

export class ConflictDetector {
  private periods: PeriodWithDetails[];

  constructor(periods: PeriodWithDetails[]) {
    this.periods = periods;
  }

  // Main conflict detection method
  detectConflicts(newPeriod: InsertPeriod | PeriodWithDetails, excludePeriodId?: number): ConflictResult {
    const conflicts: ConflictDetails[] = [];
    const warnings: ConflictDetails[] = [];

    // Filter out the excluded period (for updates)
    const relevantPeriods = this.periods.filter(p => p.id !== excludePeriodId);

    // Find potentially conflicting periods (same day and overlapping time)
    const potentialConflicts = relevantPeriods.filter(period => 
      period.dayOfWeek === newPeriod.dayOfWeek &&
      this.hasTimeOverlap(period.startTime, period.endTime, newPeriod.startTime, this.getEndTime(newPeriod.startTime))
    );

    // Check for teacher conflicts
    const teacherConflicts = potentialConflicts.filter(period => period.teacherId === newPeriod.teacherId);
    if (teacherConflicts.length > 0) {
      conflicts.push({
        type: 'teacher',
        severity: 'error',
        message: `Teacher is already scheduled at this time`,
        conflictingPeriods: teacherConflicts,
        suggestions: ['Choose a different time slot', 'Assign a different teacher']
      });
    }

    // Check for room conflicts
    const roomConflicts = potentialConflicts.filter(period => period.roomId === newPeriod.roomId);
    if (roomConflicts.length > 0) {
      conflicts.push({
        type: 'room',
        severity: 'error',
        message: `Room is already booked at this time`,
        conflictingPeriods: roomConflicts,
        suggestions: ['Choose a different time slot', 'Select a different room']
      });
    }

    // Check for class conflicts
    const classConflicts = potentialConflicts.filter(period => period.classId === newPeriod.classId);
    if (classConflicts.length > 0) {
      conflicts.push({
        type: 'class',
        severity: 'error',
        message: `Class already has a period scheduled at this time`,
        conflictingPeriods: classConflicts,
        suggestions: ['Choose a different time slot', 'Move the existing period']
      });
    }

    // Check for soft conflicts (warnings)
    this.checkSoftConflicts(newPeriod, relevantPeriods, warnings);

    return {
      hasConflicts: conflicts.length > 0,
      conflicts,
      warnings
    };
  }

  // Check for soft conflicts that are warnings rather than errors
  private checkSoftConflicts(newPeriod: InsertPeriod | PeriodWithDetails, relevantPeriods: PeriodWithDetails[], warnings: ConflictDetails[]) {
    // Check for back-to-back classes for the same teacher
    const teacherPeriods = relevantPeriods.filter(p => p.teacherId === newPeriod.teacherId && p.dayOfWeek === newPeriod.dayOfWeek);
    const backToBackPeriods = teacherPeriods.filter(period => {
      const newEndTime = this.getEndTime(newPeriod.startTime);
      const periodEndTime = period.endTime;
      return period.startTime === newEndTime || periodEndTime === newPeriod.startTime;
    });

    if (backToBackPeriods.length > 0) {
      warnings.push({
        type: 'teacher',
        severity: 'warning',
        message: `Teacher has back-to-back classes`,
        conflictingPeriods: backToBackPeriods,
        suggestions: ['Consider adding a break between classes', 'Ensure the teacher can move between rooms quickly']
      });
    }

    // Check for room capacity issues (if we have student count data)
    if ('class' in newPeriod && 'room' in newPeriod) {
      const cls = (newPeriod as any).class;
      const room = (newPeriod as any).room;
      
      if (cls?.studentCount && room?.capacity && cls.studentCount > room.capacity) {
        warnings.push({
          type: 'capacity',
          severity: 'warning',
          message: `Room capacity (${room.capacity}) is less than class size (${cls.studentCount})`,
          conflictingPeriods: [],
          suggestions: ['Choose a larger room', 'Split the class into smaller groups']
        });
      }
    }

    // Check for subject-room type mismatches
    if ('subject' in newPeriod && 'room' in newPeriod) {
      const subject = (newPeriod as any).subject;
      const room = (newPeriod as any).room;
      
      if (this.isSubjectRoomMismatch(subject?.name, room?.type)) {
        warnings.push({
          type: 'preference',
          severity: 'info',
          message: `Subject "${subject?.name}" might be better suited for a different room type`,
          conflictingPeriods: [],
          suggestions: [`Consider using a ${this.getPreferredRoomType(subject?.name)} instead`]
        });
      }
    }
  }

  // Check if there's a time overlap between two periods
  private hasTimeOverlap(start1: string, end1: string, start2: string, end2: string): boolean {
    const s1 = this.timeToMinutes(start1);
    const e1 = this.timeToMinutes(end1);
    const s2 = this.timeToMinutes(start2);
    const e2 = this.timeToMinutes(end2);

    return s1 < e2 && s2 < e1;
  }

  // Convert time string to minutes for comparison
  private timeToMinutes(timeStr: string): number {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
  }

  // Get end time for a period (assuming 1 hour duration)
  private getEndTime(startTime: string): string {
    const [hours, minutes] = startTime.split(':').map(Number);
    const endHours = hours + 1;
    return `${endHours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  }

  // Check if subject and room type are mismatched
  private isSubjectRoomMismatch(subjectName?: string, roomType?: string): boolean {
    if (!subjectName || !roomType) return false;

    const subject = subjectName.toLowerCase();
    const type = roomType.toLowerCase();

    // Science subjects should be in labs
    if ((subject.includes('physics') || subject.includes('chemistry') || subject.includes('biology')) && type !== 'lab') {
      return true;
    }

    // PE should be in gym
    if (subject.includes('physical') && type !== 'gym') {
      return true;
    }

    // Art/Music should be in studios
    if ((subject.includes('art') || subject.includes('music')) && type !== 'studio') {
      return true;
    }

    return false;
  }

  // Get preferred room type for a subject
  private getPreferredRoomType(subjectName?: string): string {
    if (!subjectName) return 'classroom';

    const subject = subjectName.toLowerCase();

    if (subject.includes('physics') || subject.includes('chemistry') || subject.includes('biology')) {
      return 'laboratory';
    }

    if (subject.includes('physical') || subject.includes('pe')) {
      return 'gymnasium';
    }

    if (subject.includes('art') || subject.includes('music')) {
      return 'studio';
    }

    return 'classroom';
  }

  // Get conflicts for a specific day
  getConflictsForDay(dayOfWeek: number): ConflictDetails[] {
    const dayPeriods = this.periods.filter(p => p.dayOfWeek === dayOfWeek);
    const conflicts: ConflictDetails[] = [];

    for (let i = 0; i < dayPeriods.length; i++) {
      for (let j = i + 1; j < dayPeriods.length; j++) {
        const period1 = dayPeriods[i];
        const period2 = dayPeriods[j];

        if (this.hasTimeOverlap(period1.startTime, period1.endTime, period2.startTime, period2.endTime)) {
          // Check what type of conflict this is
          if (period1.teacherId === period2.teacherId) {
            conflicts.push({
              type: 'teacher',
              severity: 'error',
              message: `${period1.teacher.name} has conflicting schedules`,
              conflictingPeriods: [period1, period2]
            });
          }

          if (period1.roomId === period2.roomId) {
            conflicts.push({
              type: 'room',
              severity: 'error',
              message: `${period1.room.name} is double-booked`,
              conflictingPeriods: [period1, period2]
            });
          }

          if (period1.classId === period2.classId) {
            conflicts.push({
              type: 'class',
              severity: 'error',
              message: `${period1.class.name} has overlapping periods`,
              conflictingPeriods: [period1, period2]
            });
          }
        }
      }
    }

    return conflicts;
  }

  // Get all conflicts in the timetable
  getAllConflicts(): ConflictDetails[] {
    const allConflicts: ConflictDetails[] = [];

    for (let day = 1; day <= 5; day++) {
      allConflicts.push(...this.getConflictsForDay(day));
    }

    return allConflicts;
  }

  // Get conflict summary
  getConflictSummary(): { total: number; byType: Record<string, number>; bySeverity: Record<string, number> } {
    const conflicts = this.getAllConflicts();
    const byType: Record<string, number> = {};
    const bySeverity: Record<string, number> = {};

    conflicts.forEach(conflict => {
      byType[conflict.type] = (byType[conflict.type] || 0) + 1;
      bySeverity[conflict.severity] = (bySeverity[conflict.severity] || 0) + 1;
    });

    return {
      total: conflicts.length,
      byType,
      bySeverity
    };
  }
}

// Utility functions for conflict detection
export const detectPeriodConflicts = (periods: PeriodWithDetails[], newPeriod: InsertPeriod | PeriodWithDetails, excludePeriodId?: number): ConflictResult => {
  const detector = new ConflictDetector(periods);
  return detector.detectConflicts(newPeriod, excludePeriodId);
};

export const getConflictColor = (severity: 'error' | 'warning' | 'info'): string => {
  switch (severity) {
    case 'error':
      return 'text-red-600 bg-red-50 border-red-200';
    case 'warning':
      return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    case 'info':
      return 'text-blue-600 bg-blue-50 border-blue-200';
    default:
      return 'text-gray-600 bg-gray-50 border-gray-200';
  }
};

export const getConflictIcon = (type: string): string => {
  switch (type) {
    case 'teacher':
      return '👨‍🏫';
    case 'room':
      return '🏢';
    case 'class':
      return '👥';
    case 'capacity':
      return '📊';
    case 'preference':
      return '💡';
    default:
      return '⚠️';
  }
};

export const formatConflictTime = (startTime: string, endTime: string): string => {
  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':').map(Number);
    const period = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours > 12 ? hours - 12 : hours === 0 ? 12 : hours;
    return `${displayHours}:${minutes.toString().padStart(2, '0')} ${period}`;
  };

  return `${formatTime(startTime)} - ${formatTime(endTime)}`;
};

export const getDayName = (dayOfWeek: number): string => {
  const days = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  return days[dayOfWeek] || '';
};
