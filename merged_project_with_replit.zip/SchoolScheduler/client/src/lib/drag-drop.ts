import { PeriodWithDetails } from "@shared/schema";

export interface DragDropConfig {
  onDrop: (period: PeriodWithDetails, targetDay: number, targetTime: string) => void;
  onDragStart?: (period: PeriodWithDetails) => void;
  onDragEnd?: () => void;
  onConflict?: (conflicts: string[]) => void;
}

export class DragDropManager {
  private config: DragDropConfig;
  private draggedPeriod: PeriodWithDetails | null = null;
  private dragOverElement: HTMLElement | null = null;

  constructor(config: DragDropConfig) {
    this.config = config;
  }

  // Initialize drag and drop for period cards
  initializePeriodDrag(element: HTMLElement, period: PeriodWithDetails) {
    element.draggable = true;
    
    element.addEventListener('dragstart', (e) => {
      this.draggedPeriod = period;
      element.style.opacity = '0.5';
      
      // Store period data in dataTransfer for cross-component compatibility
      if (e.dataTransfer) {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', JSON.stringify(period));
      }
      
      this.config.onDragStart?.(period);
    });

    element.addEventListener('dragend', () => {
      element.style.opacity = '1';
      this.draggedPeriod = null;
      this.clearDragOverEffects();
      this.config.onDragEnd?.();
    });
  }

  // Initialize drop zones (table cells)
  initializeDropZone(element: HTMLElement, day: number, time: string) {
    element.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      if (this.draggedPeriod) {
        this.setDragOverEffect(element);
      }
    });

    element.addEventListener('dragleave', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      // Only clear if we're actually leaving the element
      if (!element.contains(e.relatedTarget as Node)) {
        this.clearDragOverEffect(element);
      }
    });

    element.addEventListener('drop', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      this.clearDragOverEffect(element);
      
      if (this.draggedPeriod) {
        this.config.onDrop(this.draggedPeriod, day, time);
      }
    });
  }

  // Visual feedback for drag over
  private setDragOverEffect(element: HTMLElement) {
    if (this.dragOverElement !== element) {
      this.clearDragOverEffects();
      this.dragOverElement = element;
      element.classList.add('drag-over');
    }
  }

  private clearDragOverEffect(element: HTMLElement) {
    element.classList.remove('drag-over');
    if (this.dragOverElement === element) {
      this.dragOverElement = null;
    }
  }

  private clearDragOverEffects() {
    if (this.dragOverElement) {
      this.dragOverElement.classList.remove('drag-over');
      this.dragOverElement = null;
    }
  }

  // Get currently dragged period
  getDraggedPeriod(): PeriodWithDetails | null {
    return this.draggedPeriod;
  }

  // Check if a drop is valid
  isValidDrop(period: PeriodWithDetails, targetDay: number, targetTime: string): boolean {
    // Basic validation - can be extended with more complex rules
    return targetDay >= 1 && targetDay <= 5 && targetTime.length > 0;
  }

  // Convert time string to comparable format for conflict detection
  parseTime(timeStr: string): { hour: number; minute: number } {
    const [hourStr, minuteStr] = timeStr.split(':');
    return {
      hour: parseInt(hourStr),
      minute: parseInt(minuteStr)
    };
  }

  // Check for time overlap
  hasTimeOverlap(time1: string, time2: string, duration: number = 60): boolean {
    const t1 = this.parseTime(time1);
    const t2 = this.parseTime(time2);
    
    const t1Minutes = t1.hour * 60 + t1.minute;
    const t2Minutes = t2.hour * 60 + t2.minute;
    
    return Math.abs(t1Minutes - t2Minutes) < duration;
  }
}

// Hook for using drag and drop in React components
export const useDragDrop = (config: DragDropConfig) => {
  const dragDropManager = new DragDropManager(config);

  const initializePeriodDrag = (element: HTMLElement | null, period: PeriodWithDetails) => {
    if (element) {
      dragDropManager.initializePeriodDrag(element, period);
    }
  };

  const initializeDropZone = (element: HTMLElement | null, day: number, time: string) => {
    if (element) {
      dragDropManager.initializeDropZone(element, day, time);
    }
  };

  return {
    initializePeriodDrag,
    initializeDropZone,
    getDraggedPeriod: () => dragDropManager.getDraggedPeriod(),
    isValidDrop: (period: PeriodWithDetails, day: number, time: string) => 
      dragDropManager.isValidDrop(period, day, time),
  };
};

// Utility functions for drag and drop operations
export const createDragImage = (period: PeriodWithDetails): HTMLElement => {
  const dragImage = document.createElement('div');
  dragImage.className = 'bg-white border-2 border-primary rounded-lg p-2 shadow-lg';
  dragImage.innerHTML = `
    <div class="font-medium text-sm">${period.subject.name}</div>
    <div class="text-xs text-gray-600">${period.teacher.name}</div>
  `;
  
  // Position off-screen
  dragImage.style.position = 'absolute';
  dragImage.style.top = '-1000px';
  dragImage.style.left = '-1000px';
  
  document.body.appendChild(dragImage);
  
  // Clean up after a short delay
  setTimeout(() => {
    document.body.removeChild(dragImage);
  }, 100);
  
  return dragImage;
};

export const getDropZoneCoordinates = (element: HTMLElement) => {
  const rect = element.getBoundingClientRect();
  return {
    x: rect.left + rect.width / 2,
    y: rect.top + rect.height / 2,
    width: rect.width,
    height: rect.height
  };
};

export const animateDropSuccess = (element: HTMLElement) => {
  element.style.transform = 'scale(1.05)';
  element.style.transition = 'transform 0.2s ease';
  
  setTimeout(() => {
    element.style.transform = 'scale(1)';
    setTimeout(() => {
      element.style.transition = '';
    }, 200);
  }, 100);
};

export const animateDropFailure = (element: HTMLElement) => {
  element.style.backgroundColor = 'rgba(239, 68, 68, 0.1)';
  element.style.borderColor = 'rgb(239, 68, 68)';
  element.style.transition = 'background-color 0.3s ease, border-color 0.3s ease';
  
  setTimeout(() => {
    element.style.backgroundColor = '';
    element.style.borderColor = '';
    setTimeout(() => {
      element.style.transition = '';
    }, 300);
  }, 1000);
};
