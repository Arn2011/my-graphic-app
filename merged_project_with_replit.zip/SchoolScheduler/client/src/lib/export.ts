import { PeriodWithDetails, Class, Teacher, Room } from "@shared/schema";

export interface ExportOptions {
  format: 'pdf' | 'excel' | 'csv' | 'print';
  orientation: 'portrait' | 'landscape';
  includeBreaks: boolean;
  includeEmptySlots: boolean;
  colorCoded: boolean;
  title?: string;
  subtitle?: string;
  schoolName?: string;
  academicYear?: string;
}

export interface TimetableData {
  periods: PeriodWithDetails[];
  classes?: Class[];
  teachers?: Teacher[];
  rooms?: Room[];
  timeSlots: TimeSlot[];
  days: string[];
}

export interface TimeSlot {
  time: string;
  label: string;
  isBreak?: boolean;
  breakTitle?: string;
}

export class TimetableExporter {
  private defaultTimeSlots: TimeSlot[] = [
    { time: "08:00", label: "8:00 AM" },
    { time: "09:00", label: "9:00 AM" },
    { time: "10:00", label: "10:00 AM", isBreak: true, breakTitle: "Morning Break" },
    { time: "10:15", label: "10:15 AM" },
    { time: "11:15", label: "11:15 AM" },
    { time: "12:15", label: "12:15 PM", isBreak: true, breakTitle: "Lunch Break" },
    { time: "13:00", label: "1:00 PM" },
    { time: "14:00", label: "2:00 PM" },
  ];

  private defaultDays: string[] = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

  // Export timetable for a specific class
  async exportClassTimetable(classId: number, data: TimetableData, options: ExportOptions): Promise<string> {
    const classData = data.classes?.find(c => c.id === classId);
    const classPeriods = data.periods.filter(p => p.classId === classId);
    
    const exportData = {
      ...data,
      periods: classPeriods,
      title: options.title || `Timetable - ${classData?.name}`,
      subtitle: options.subtitle || `Grade ${classData?.grade}`,
    };

    return this.generateExport(exportData, options);
  }

  // Export timetable for a specific teacher
  async exportTeacherTimetable(teacherId: number, data: TimetableData, options: ExportOptions): Promise<string> {
    const teacherData = data.teachers?.find(t => t.id === teacherId);
    const teacherPeriods = data.periods.filter(p => p.teacherId === teacherId);
    
    const exportData = {
      ...data,
      periods: teacherPeriods,
      title: options.title || `Schedule - ${teacherData?.name}`,
      subtitle: options.subtitle || `${teacherData?.subject} Teacher`,
    };

    return this.generateExport(exportData, options);
  }

  // Export timetable for a specific room
  async exportRoomTimetable(roomId: number, data: TimetableData, options: ExportOptions): Promise<string> {
    const roomData = data.rooms?.find(r => r.id === roomId);
    const roomPeriods = data.periods.filter(p => p.roomId === roomId);
    
    const exportData = {
      ...data,
      periods: roomPeriods,
      title: options.title || `Schedule - ${roomData?.name}`,
      subtitle: options.subtitle || `Room Utilization`,
    };

    return this.generateExport(exportData, options);
  }

  // Export master timetable with all periods
  async exportMasterTimetable(data: TimetableData, options: ExportOptions): Promise<string> {
    const exportData = {
      ...data,
      title: options.title || "Master Timetable",
      subtitle: options.subtitle || "Complete School Schedule",
    };

    return this.generateExport(exportData, options);
  }

  // Main export generation method
  private async generateExport(data: TimetableData, options: ExportOptions): Promise<string> {
    switch (options.format) {
      case 'pdf':
        return this.generatePDF(data, options);
      case 'excel':
        return this.generateExcel(data, options);
      case 'csv':
        return this.generateCSV(data, options);
      case 'print':
        return this.generatePrintHTML(data, options);
      default:
        throw new Error(`Unsupported export format: ${options.format}`);
    }
  }

  // Generate PDF export
  private async generatePDF(data: TimetableData, options: ExportOptions): Promise<string> {
    const html = this.generateTimetableHTML(data, options);
    
    // In a real implementation, this would use a library like jsPDF or puppeteer
    // For now, we'll simulate the PDF generation
    const pdfBlob = await this.htmlToPDF(html, options);
    
    // Create download link
    const url = URL.createObjectURL(pdfBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `timetable-${Date.now()}.pdf`;
    link.click();
    
    URL.revokeObjectURL(url);
    return url;
  }

  // Generate Excel export
  private async generateExcel(data: TimetableData, options: ExportOptions): Promise<string> {
    const csvData = this.generateCSVData(data, options);
    
    // Convert CSV to Excel format (simplified)
    const excelContent = this.csvToExcel(csvData);
    
    const blob = new Blob([excelContent], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `timetable-${Date.now()}.xlsx`;
    link.click();
    
    URL.revokeObjectURL(url);
    return url;
  }

  // Generate CSV export
  private async generateCSV(data: TimetableData, options: ExportOptions): Promise<string> {
    const csvData = this.generateCSVData(data, options);
    
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `timetable-${Date.now()}.csv`;
    link.click();
    
    URL.revokeObjectURL(url);
    return url;
  }

  // Generate print-friendly HTML
  private generatePrintHTML(data: TimetableData, options: ExportOptions): Promise<string> {
    const html = this.generateTimetableHTML(data, options);
    
    // Open in new window for printing
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(html);
      printWindow.document.close();
      printWindow.print();
    }
    
    return Promise.resolve(html);
  }

  // Generate HTML for timetable
  private generateTimetableHTML(data: TimetableData, options: ExportOptions): string {
    const timeSlots = data.timeSlots.length > 0 ? data.timeSlots : this.defaultTimeSlots;
    const days = data.days.length > 0 ? data.days : this.defaultDays;
    
    const organizedPeriods = this.organizePeriods(data.periods);
    
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${data.title || 'Timetable'}</title>
        <style>
          ${this.getTimetableCSS(options)}
        </style>
      </head>
      <body>
        <div class="timetable-container">
          <header class="timetable-header">
            <h1>${data.title || 'Timetable'}</h1>
            ${data.subtitle ? `<h2>${data.subtitle}</h2>` : ''}
            ${options.schoolName ? `<p class="school-name">${options.schoolName}</p>` : ''}
            ${options.academicYear ? `<p class="academic-year">${options.academicYear}</p>` : ''}
          </header>
          
          <table class="timetable">
            <thead>
              <tr>
                <th class="time-header">Time</th>
                ${days.map(day => `<th class="day-header">${day}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${timeSlots.map(slot => this.generateTimeSlotRow(slot, days, organizedPeriods, options)).join('')}
            </tbody>
          </table>
          
          <footer class="timetable-footer">
            <p>Generated on ${new Date().toLocaleDateString()}</p>
            ${options.colorCoded ? this.generateLegend(data.periods) : ''}
          </footer>
        </div>
      </body>
      </html>
    `;
  }

  // Generate CSS for timetable
  private getTimetableCSS(options: ExportOptions): string {
    return `
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }
      
      body {
        font-family: 'Arial', sans-serif;
        font-size: 12px;
        line-height: 1.4;
        color: #333;
        background: white;
      }
      
      .timetable-container {
        max-width: 100%;
        margin: 0 auto;
        padding: 20px;
      }
      
      .timetable-header {
        text-align: center;
        margin-bottom: 30px;
        border-bottom: 2px solid #333;
        padding-bottom: 20px;
      }
      
      .timetable-header h1 {
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 10px;
      }
      
      .timetable-header h2 {
        font-size: 18px;
        color: #666;
        margin-bottom: 5px;
      }
      
      .school-name, .academic-year {
        font-size: 14px;
        color: #888;
      }
      
      .timetable {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 30px;
        font-size: 11px;
      }
      
      .timetable th, .timetable td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: center;
        vertical-align: middle;
      }
      
      .timetable th {
        background-color: #f5f5f5;
        font-weight: bold;
        font-size: 12px;
      }
      
      .time-header {
        width: 80px;
        background-color: #e9ecef;
      }
      
      .day-header {
        background-color: #f8f9fa;
      }
      
      .period-cell {
        min-height: 60px;
        position: relative;
        padding: 4px;
      }
      
      .period-content {
        background: #f0f9ff;
        border-left: 4px solid #3b82f6;
        padding: 6px;
        border-radius: 4px;
        height: 100%;
      }
      
      .period-subject {
        font-weight: bold;
        font-size: 11px;
        margin-bottom: 2px;
      }
      
      .period-details {
        font-size: 9px;
        color: #666;
      }
      
      .break-cell {
        background-color: #fff3cd;
        border-color: #ffeaa7;
        font-style: italic;
        color: #856404;
      }
      
      .empty-cell {
        background-color: #f8f9fa;
        color: #6c757d;
        font-style: italic;
      }
      
      .timetable-footer {
        text-align: center;
        margin-top: 30px;
        padding-top: 20px;
        border-top: 1px solid #ddd;
        font-size: 10px;
        color: #666;
      }
      
      .legend {
        margin-top: 20px;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 10px;
      }
      
      .legend-item {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 10px;
      }
      
      .legend-color {
        width: 12px;
        height: 12px;
        border-radius: 2px;
        border: 1px solid #ddd;
      }
      
      @media print {
        .timetable-container {
          padding: 10px;
        }
        
        .timetable {
          font-size: 10px;
        }
        
        .timetable-header h1 {
          font-size: 20px;
        }
        
        .timetable-header h2 {
          font-size: 16px;
        }
      }
      
      ${options.orientation === 'landscape' ? `
        @page {
          size: landscape;
        }
        
        .timetable {
          font-size: 10px;
        }
        
        .period-cell {
          min-height: 50px;
        }
      ` : ''}
    `;
  }

  // Generate time slot row
  private generateTimeSlotRow(slot: TimeSlot, days: string[], organizedPeriods: Record<string, PeriodWithDetails | null>, options: ExportOptions): string {
    if (slot.isBreak && options.includeBreaks) {
      return `
        <tr class="break-row">
          <td class="time-cell">${slot.label}</td>
          <td colspan="${days.length}" class="break-cell">
            ${slot.breakTitle || 'Break'}
          </td>
        </tr>
      `;
    }
    
    if (slot.isBreak && !options.includeBreaks) {
      return '';
    }
    
    return `
      <tr>
        <td class="time-cell">${slot.label}</td>
        ${days.map((day, dayIndex) => {
          const period = organizedPeriods[`${dayIndex + 1}-${slot.time}`];
          return this.generatePeriodCell(period, options);
        }).join('')}
      </tr>
    `;
  }

  // Generate period cell
  private generatePeriodCell(period: PeriodWithDetails | null, options: ExportOptions): string {
    if (!period) {
      return options.includeEmptySlots 
        ? '<td class="period-cell empty-cell">Free</td>'
        : '<td class="period-cell empty-cell">-</td>';
    }
    
    const backgroundColor = options.colorCoded ? this.getSubjectColor(period.subject.name) : '#f0f9ff';
    const borderColor = options.colorCoded ? period.subject.color : '#3b82f6';
    
    return `
      <td class="period-cell">
        <div class="period-content" style="background-color: ${backgroundColor}; border-left-color: ${borderColor};">
          <div class="period-subject">${period.subject.name}</div>
          <div class="period-details">${period.teacher.name}</div>
          <div class="period-details">${period.room.name}</div>
        </div>
      </td>
    `;
  }

  // Generate legend for color-coded export
  private generateLegend(periods: PeriodWithDetails[]): string {
    const subjects = Array.from(new Set(periods.map(p => p.subject.name)))
      .map(name => periods.find(p => p.subject.name === name)?.subject)
      .filter(Boolean);
    
    return `
      <div class="legend">
        ${subjects.map(subject => `
          <div class="legend-item">
            <div class="legend-color" style="background-color: ${subject!.color};"></div>
            <span>${subject!.name}</span>
          </div>
        `).join('')}
      </div>
    `;
  }

  // Organize periods by day and time
  private organizePeriods(periods: PeriodWithDetails[]): Record<string, PeriodWithDetails | null> {
    const organized: Record<string, PeriodWithDetails | null> = {};
    
    periods.forEach(period => {
      const key = `${period.dayOfWeek}-${period.startTime}`;
      organized[key] = period;
    });
    
    return organized;
  }

  // Generate CSV data
  private generateCSVData(data: TimetableData, options: ExportOptions): string {
    const timeSlots = data.timeSlots.length > 0 ? data.timeSlots : this.defaultTimeSlots;
    const days = data.days.length > 0 ? data.days : this.defaultDays;
    const organizedPeriods = this.organizePeriods(data.periods);
    
    const csvRows: string[] = [];
    
    // Header
    csvRows.push(`"Time","${days.join('","')}"`);
    
    // Data rows
    timeSlots.forEach(slot => {
      if (slot.isBreak && !options.includeBreaks) return;
      
      const row = [slot.label];
      
      if (slot.isBreak) {
        row.push(...Array(days.length).fill(slot.breakTitle || 'Break'));
      } else {
        days.forEach((day, dayIndex) => {
          const period = organizedPeriods[`${dayIndex + 1}-${slot.time}`];
          if (period) {
            row.push(`${period.subject.name} (${period.teacher.name} - ${period.room.name})`);
          } else {
            row.push(options.includeEmptySlots ? 'Free' : '');
          }
        });
      }
      
      csvRows.push(`"${row.join('","')}"`);
    });
    
    return csvRows.join('\n');
  }

  // Convert CSV to Excel (simplified)
  private csvToExcel(csvData: string): string {
    // In a real implementation, this would use a library like xlsx or exceljs
    // For now, we'll return the CSV data as-is
    return csvData;
  }

  // Convert HTML to PDF (simplified)
  private async htmlToPDF(html: string, options: ExportOptions): Promise<Blob> {
    // In a real implementation, this would use a library like jsPDF with html2canvas
    // or puppeteer for server-side PDF generation
    // For now, we'll create a simple text blob
    return new Blob([html], { type: 'text/html' });
  }

  // Get subject color for display
  private getSubjectColor(subjectName: string): string {
    const subject = subjectName.toLowerCase();
    if (subject.includes('math')) return '#e3f2fd';
    if (subject.includes('science')) return '#e8f5e8';
    if (subject.includes('english')) return '#fff3e0';
    if (subject.includes('history')) return '#f3e5f5';
    if (subject.includes('physical')) return '#ffebee';
    if (subject.includes('art')) return '#e0f2f1';
    return '#f0f9ff';
  }
}

// Export utility functions
export const exportTimetable = async (
  type: 'class' | 'teacher' | 'room' | 'master',
  id: number | null,
  data: TimetableData,
  options: ExportOptions
): Promise<string> => {
  const exporter = new TimetableExporter();
  
  switch (type) {
    case 'class':
      if (!id) throw new Error('Class ID is required');
      return exporter.exportClassTimetable(id, data, options);
    case 'teacher':
      if (!id) throw new Error('Teacher ID is required');
      return exporter.exportTeacherTimetable(id, data, options);
    case 'room':
      if (!id) throw new Error('Room ID is required');
      return exporter.exportRoomTimetable(id, data, options);
    case 'master':
      return exporter.exportMasterTimetable(data, options);
    default:
      throw new Error(`Unsupported export type: ${type}`);
  }
};

export const getDefaultExportOptions = (): ExportOptions => ({
  format: 'pdf',
  orientation: 'landscape',
  includeBreaks: true,
  includeEmptySlots: true,
  colorCoded: true,
  schoolName: 'TimeTable Pro School',
  academicYear: '2024-2025'
});

export const downloadFile = (content: string, filename: string, mimeType: string) => {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  
  URL.revokeObjectURL(url);
};
