import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, FileText, Calendar } from "lucide-react";
import Header from "@/components/layout/header";
import { useToast } from "@/hooks/use-toast";
import type { Class, Teacher, Room } from "@shared/schema";

export default function ExportPage() {
  const [exportType, setExportType] = useState<"class" | "teacher" | "room">("class");
  const [selectedId, setSelectedId] = useState<string>("");
  const { toast } = useToast();

  const { data: classes = [] } = useQuery<Class[]>({
    queryKey: ["/api/classes"],
  });

  const { data: teachers = [] } = useQuery<Teacher[]>({
    queryKey: ["/api/teachers"],
  });

  const { data: rooms = [] } = useQuery<Room[]>({
    queryKey: ["/api/rooms"],
  });

  const handleExport = (format: "pdf" | "excel" | "csv") => {
    if (!selectedId) {
      toast({
        title: "Error",
        description: "Please select an item to export",
        variant: "destructive",
      });
      return;
    }

    // Simulate export functionality
    toast({
      title: "Export Started",
      description: `Exporting ${exportType} timetable as ${format.toUpperCase()}...`,
    });

    // In a real implementation, this would generate and download the file
    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: `Timetable exported successfully as ${format.toUpperCase()}`,
      });
    }, 2000);
  };

  const getOptions = () => {
    switch (exportType) {
      case "class":
        return classes.map(cls => ({ value: cls.id.toString(), label: cls.name }));
      case "teacher":
        return teachers.map(teacher => ({ value: teacher.id.toString(), label: teacher.name }));
      case "room":
        return rooms.map(room => ({ value: room.id.toString(), label: room.name }));
      default:
        return [];
    }
  };

  return (
    <>
      <Header
        title="Export Timetables"
        subtitle="Export timetables in various formats for printing or sharing"
      />

      <div className="flex-1 p-6">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Download className="mr-2 h-5 w-5" />
                Export Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Export Type
                </label>
                <Select value={exportType} onValueChange={(value: any) => {
                  setExportType(value);
                  setSelectedId("");
                }}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="class">By Class</SelectItem>
                    <SelectItem value="teacher">By Teacher</SelectItem>
                    <SelectItem value="room">By Room</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select {exportType === "class" ? "Class" : exportType === "teacher" ? "Teacher" : "Room"}
                </label>
                <Select value={selectedId} onValueChange={setSelectedId}>
                  <SelectTrigger>
                    <SelectValue placeholder={`Select ${exportType}`} />
                  </SelectTrigger>
                  <SelectContent>
                    {getOptions().map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">Export Formats</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-4 text-center">
                      <FileText className="h-8 w-8 text-red-500 mx-auto mb-2" />
                      <h4 className="font-medium mb-2">PDF</h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Perfect for printing and sharing
                      </p>
                      <Button 
                        onClick={() => handleExport("pdf")}
                        className="w-full"
                        size="sm"
                      >
                        Export PDF
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-4 text-center">
                      <FileText className="h-8 w-8 text-green-500 mx-auto mb-2" />
                      <h4 className="font-medium mb-2">Excel</h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Editable spreadsheet format
                      </p>
                      <Button 
                        onClick={() => handleExport("excel")}
                        className="w-full"
                        size="sm"
                        variant="outline"
                      >
                        Export Excel
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-4 text-center">
                      <FileText className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                      <h4 className="font-medium mb-2">CSV</h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Data import/export format
                      </p>
                      <Button 
                        onClick={() => handleExport("csv")}
                        className="w-full"
                        size="sm"
                        variant="outline"
                      >
                        Export CSV
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button className="w-full" variant="outline">
                    <Calendar className="mr-2 h-4 w-4" />
                    Export All Class Timetables
                  </Button>
                  <Button className="w-full" variant="outline">
                    <FileText className="mr-2 h-4 w-4" />
                    Export Master Schedule
                  </Button>
                  <Button className="w-full" variant="outline">
                    <Download className="mr-2 h-4 w-4" />
                    Export Room Utilization Report
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
