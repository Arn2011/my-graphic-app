import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import TimetableGrid from "@/components/timetable/timetable-grid";
import ConflictAlerts from "@/components/timetable/conflict-alerts";
import SubjectPool from "@/components/timetable/subject-pool";
import AddPeriodModal from "@/components/timetable/add-period-modal";
import { Button } from "@/components/ui/button";
import { WandSparkles, Check, Download, Save } from "lucide-react";
import type { Class, PeriodWithDetails } from "@shared/schema";

export default function TimetablePage() {
  const [currentView, setCurrentView] = useState<"class" | "teacher" | "room">("class");
  const [selectedClassId, setSelectedClassId] = useState<number>();
  const [showAddModal, setShowAddModal] = useState(false);

  const { data: classes = [] } = useQuery<Class[]>({
    queryKey: ["/api/classes"],
  });

  const { data: periods = [] } = useQuery<PeriodWithDetails[]>({
    queryKey: ["/api/periods/class", selectedClassId],
    enabled: currentView === "class" && !!selectedClassId,
  });

  const selectedClass = classes.find(c => c.id === selectedClassId);

  // Auto-select first class if none selected
  useEffect(() => {
    if (classes.length > 0 && !selectedClassId) {
      setSelectedClassId(classes[0].id);
    }
  }, [classes, selectedClassId]);

  return (
    <>
      <Header
        title="Timetable Management"
        subtitle="8:50 AM - 4:00 PM • Prayer: 8:50-9:40 • Short Break: 10:55-11:15 • Lunch: 1:15-1:45 • Prep: 15 min"
        showViewSwitcher
        showClassSelector={currentView === "class"}
        showAddButton
        currentView={currentView}
        onViewChange={setCurrentView}
        selectedClassId={selectedClassId}
        onClassChange={setSelectedClassId}
        onAddClick={() => setShowAddModal(true)}
      />

      <div className="flex-1 flex overflow-hidden">
        <div className="flex-1 p-6 overflow-auto">
          <TimetableGrid
            periods={periods}
            selectedClass={selectedClass}
            viewType={currentView}
          />
        </div>
        
        <div className="w-80 bg-white shadow-lg border-l border-gray-200 p-6 overflow-y-auto">
          <ConflictAlerts />
          
          <div className="mt-6">
            <SubjectPool />
          </div>
          
          <div className="mt-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <Button className="w-full" variant="default">
                <WandSparkles className="mr-2" size={16} />
                Auto-Generate Schedule
              </Button>
              <Button className="w-full bg-secondary hover:bg-secondary/90">
                <Check className="mr-2" size={16} />
                Validate Schedule
              </Button>
              <Button className="w-full bg-accent hover:bg-accent/90 text-white">
                <Download className="mr-2" size={16} />
                Export PDF
              </Button>
              <Button className="w-full" variant="outline">
                <Save className="mr-2" size={16} />
                Save Changes
              </Button>
            </div>
          </div>
        </div>
      </div>

      <AddPeriodModal
        open={showAddModal}
        onOpenChange={setShowAddModal}
        selectedClassId={selectedClassId}
      />
    </>
  );
}
