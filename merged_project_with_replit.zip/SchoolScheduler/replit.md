# SVPHIS Timetable Management System

## Overview

A comprehensive timetable management system built for Sri Vivekananda Public Higher Secondary School (SVPHIS) using React, Express, and in-memory storage. The application provides a full-stack solution for managing school schedules, including teachers, classes, rooms, subjects, and periods with real-time conflict detection and drag-and-drop functionality. Currently populated with real SVPHIS data including 32 teachers, 20 classes (from Nursery to Grade 9), and comprehensive subject allocations.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom color variables
- **State Management**: TanStack React Query for server state
- **Routing**: Wouter for client-side routing
- **Forms**: React Hook Form with Zod validation
- **Build Tool**: Vite with custom configuration

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **API Design**: RESTful API with full CRUD operations
- **Validation**: Zod schemas shared between client and server
- **Development**: Hot reload with Vite integration

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Migration**: Drizzle Kit for schema migrations
- **Schema Location**: Shared schema definitions in `/shared/schema.ts`
- **Database Config**: Environment-based configuration with `DATABASE_URL`

## Key Components

### Database Schema
Five main entities with relationships:
- **Teachers**: Name, email, subject specialization
- **Subjects**: Name with color coding for visual organization
- **Rooms**: Name, capacity, and type (classroom, lab, gym, etc.)
- **Classes**: Name, grade level, student count
- **Periods**: Time slots linking teachers, subjects, rooms, and classes

### API Endpoints
Full CRUD operations for each entity:
- `GET/POST/PUT/DELETE /api/teachers`
- `GET/POST/PUT/DELETE /api/subjects`
- `GET/POST/PUT/DELETE /api/rooms`
- `GET/POST/PUT/DELETE /api/classes`
- `GET/POST/PUT/DELETE /api/periods`

### Frontend Features
- **Timetable Grid**: Interactive weekly schedule display
- **Drag & Drop**: Period management with conflict detection
- **Multi-View Support**: Class, teacher, and room perspectives
- **Form Management**: Modal-based CRUD operations
- **Real-time Validation**: Client and server-side validation
- **Export Functionality**: PDF, Excel, CSV export options

## Data Flow

1. **Client Request**: React components trigger API calls through TanStack Query
2. **API Processing**: Express routes handle requests with Zod validation
3. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
4. **Response Handling**: JSON responses with proper error handling
5. **State Updates**: React Query manages cache invalidation and updates
6. **UI Updates**: Components re-render with new data

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form
- **Backend**: Express.js, Node.js runtime
- **Database**: PostgreSQL, Drizzle ORM, Neon Database
- **Build Tools**: Vite, TypeScript, ESBuild

### UI Component Libraries
- **Radix UI**: Complete set of accessible components
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **Date-fns**: Date manipulation utilities

### Development Tools
- **Validation**: Zod for runtime type checking
- **Routing**: Wouter for lightweight routing
- **State Management**: TanStack React Query
- **Development**: Replit integration plugins

## Deployment Strategy

### Development Environment
- **Local Development**: `npm run dev` starts both frontend and backend
- **Hot Reload**: Vite integration for immediate feedback
- **Database Push**: `npm run db:push` for schema updates
- **Type Checking**: `npm run check` for TypeScript validation

### Production Build
- **Frontend Build**: Vite builds optimized React application
- **Backend Build**: ESBuild bundles Express server
- **Static Assets**: Served from `/dist/public`
- **Database**: Neon Database for production PostgreSQL

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **NODE_ENV**: Environment mode (development/production)
- **Replit Integration**: Cartographer plugin for development
- **CORS**: Configured for cross-origin requests

## Recent Changes
- July 04, 2025: Initial setup with sample data
- July 04, 2025: Updated with real SVPHIS data including 32 teachers, 20 classes from Nursery to Grade 9, comprehensive subject allocations, appropriate room assignments, and sample period scheduling
- July 04, 2025: Fixed sidebar navigation warnings and updated branding to SVPHIS
- July 05, 2025: Fixed scrolling issues in all data tables (teachers, classes, rooms, subjects)
- July 05, 2025: Implemented 9-period timetable system with Saturday classes
- July 05, 2025: Updated break timings (20min morning break, 30min lunch break)
- July 05, 2025: Added 9th period as dedicated prep time for all teachers

## User Preferences
Preferred communication style: Simple, everyday language.
School context: Sri Vivekananda Public Higher Secondary School (SVPHIS) with grades from Nursery to Grade 9.