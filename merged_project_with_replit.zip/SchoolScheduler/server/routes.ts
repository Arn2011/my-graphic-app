import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTeacherSchema, insertSubjectSchema, insertRoomSchema, insertClassSchema, insertPeriodSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Teachers
  app.get("/api/teachers", async (req, res) => {
    try {
      const teachers = await storage.getTeachers();
      res.json(teachers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch teachers" });
    }
  });

  app.get("/api/teachers/:id", async (req, res) => {
    try {
      const teacher = await storage.getTeacher(Number(req.params.id));
      if (!teacher) {
        return res.status(404).json({ error: "Teacher not found" });
      }
      res.json(teacher);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch teacher" });
    }
  });

  app.post("/api/teachers", async (req, res) => {
    try {
      const result = insertTeacherSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const teacher = await storage.createTeacher(result.data);
      res.status(201).json(teacher);
    } catch (error) {
      res.status(500).json({ error: "Failed to create teacher" });
    }
  });

  app.put("/api/teachers/:id", async (req, res) => {
    try {
      const result = insertTeacherSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const teacher = await storage.updateTeacher(Number(req.params.id), result.data);
      if (!teacher) {
        return res.status(404).json({ error: "Teacher not found" });
      }
      res.json(teacher);
    } catch (error) {
      res.status(500).json({ error: "Failed to update teacher" });
    }
  });

  app.delete("/api/teachers/:id", async (req, res) => {
    try {
      const success = await storage.deleteTeacher(Number(req.params.id));
      if (!success) {
        return res.status(404).json({ error: "Teacher not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete teacher" });
    }
  });

  // Subjects
  app.get("/api/subjects", async (req, res) => {
    try {
      const subjects = await storage.getSubjects();
      res.json(subjects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch subjects" });
    }
  });

  app.post("/api/subjects", async (req, res) => {
    try {
      const result = insertSubjectSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const subject = await storage.createSubject(result.data);
      res.status(201).json(subject);
    } catch (error) {
      res.status(500).json({ error: "Failed to create subject" });
    }
  });

  app.put("/api/subjects/:id", async (req, res) => {
    try {
      const result = insertSubjectSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const subject = await storage.updateSubject(Number(req.params.id), result.data);
      if (!subject) {
        return res.status(404).json({ error: "Subject not found" });
      }
      res.json(subject);
    } catch (error) {
      res.status(500).json({ error: "Failed to update subject" });
    }
  });

  app.delete("/api/subjects/:id", async (req, res) => {
    try {
      const success = await storage.deleteSubject(Number(req.params.id));
      if (!success) {
        return res.status(404).json({ error: "Subject not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete subject" });
    }
  });

  // Rooms
  app.get("/api/rooms", async (req, res) => {
    try {
      const rooms = await storage.getRooms();
      res.json(rooms);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch rooms" });
    }
  });

  app.post("/api/rooms", async (req, res) => {
    try {
      const result = insertRoomSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const room = await storage.createRoom(result.data);
      res.status(201).json(room);
    } catch (error) {
      res.status(500).json({ error: "Failed to create room" });
    }
  });

  app.put("/api/rooms/:id", async (req, res) => {
    try {
      const result = insertRoomSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const room = await storage.updateRoom(Number(req.params.id), result.data);
      if (!room) {
        return res.status(404).json({ error: "Room not found" });
      }
      res.json(room);
    } catch (error) {
      res.status(500).json({ error: "Failed to update room" });
    }
  });

  app.delete("/api/rooms/:id", async (req, res) => {
    try {
      const success = await storage.deleteRoom(Number(req.params.id));
      if (!success) {
        return res.status(404).json({ error: "Room not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete room" });
    }
  });

  // Classes
  app.get("/api/classes", async (req, res) => {
    try {
      const classes = await storage.getClasses();
      res.json(classes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch classes" });
    }
  });

  app.post("/api/classes", async (req, res) => {
    try {
      const result = insertClassSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const cls = await storage.createClass(result.data);
      res.status(201).json(cls);
    } catch (error) {
      res.status(500).json({ error: "Failed to create class" });
    }
  });

  app.put("/api/classes/:id", async (req, res) => {
    try {
      const result = insertClassSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const cls = await storage.updateClass(Number(req.params.id), result.data);
      if (!cls) {
        return res.status(404).json({ error: "Class not found" });
      }
      res.json(cls);
    } catch (error) {
      res.status(500).json({ error: "Failed to update class" });
    }
  });

  app.delete("/api/classes/:id", async (req, res) => {
    try {
      const success = await storage.deleteClass(Number(req.params.id));
      if (!success) {
        return res.status(404).json({ error: "Class not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete class" });
    }
  });

  // Periods
  app.get("/api/periods", async (req, res) => {
    try {
      const periods = await storage.getPeriodsWithDetails();
      res.json(periods);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch periods" });
    }
  });

  app.get("/api/periods/class/:classId", async (req, res) => {
    try {
      const periods = await storage.getPeriodsForClass(Number(req.params.classId));
      res.json(periods);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch periods for class" });
    }
  });

  app.get("/api/periods/teacher/:teacherId", async (req, res) => {
    try {
      const periods = await storage.getPeriodsForTeacher(Number(req.params.teacherId));
      res.json(periods);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch periods for teacher" });
    }
  });

  app.get("/api/periods/room/:roomId", async (req, res) => {
    try {
      const periods = await storage.getPeriodsForRoom(Number(req.params.roomId));
      res.json(periods);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch periods for room" });
    }
  });

  app.post("/api/periods", async (req, res) => {
    try {
      const result = insertPeriodSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      
      // Check for conflicts
      const conflicts = await storage.checkConflicts(result.data);
      if (conflicts.length > 0) {
        return res.status(409).json({ error: "Scheduling conflicts detected", conflicts });
      }

      const period = await storage.createPeriod(result.data);
      res.status(201).json(period);
    } catch (error) {
      res.status(500).json({ error: "Failed to create period" });
    }
  });

  app.put("/api/periods/:id", async (req, res) => {
    try {
      const result = insertPeriodSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }

      // Get existing period to merge with updates
      const existingPeriod = await storage.getPeriod(Number(req.params.id));
      if (!existingPeriod) {
        return res.status(404).json({ error: "Period not found" });
      }

      const updatedPeriod = { ...existingPeriod, ...result.data };
      
      // Check for conflicts (excluding the current period)
      const conflicts = await storage.checkConflicts(updatedPeriod);
      if (conflicts.length > 0) {
        return res.status(409).json({ error: "Scheduling conflicts detected", conflicts });
      }

      const period = await storage.updatePeriod(Number(req.params.id), result.data);
      res.json(period);
    } catch (error) {
      res.status(500).json({ error: "Failed to update period" });
    }
  });

  app.delete("/api/periods/:id", async (req, res) => {
    try {
      const success = await storage.deletePeriod(Number(req.params.id));
      if (!success) {
        return res.status(404).json({ error: "Period not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete period" });
    }
  });

  // Conflict checking endpoint
  app.post("/api/periods/check-conflicts", async (req, res) => {
    try {
      const result = insertPeriodSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      
      const conflicts = await storage.checkConflicts(result.data);
      res.json({ conflicts });
    } catch (error) {
      res.status(500).json({ error: "Failed to check conflicts" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
