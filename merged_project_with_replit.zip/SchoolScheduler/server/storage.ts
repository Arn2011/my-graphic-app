import { 
  teachers, subjects, rooms, classes, periods,
  type Teacher, type Subject, type Room, type Class, type Period, type PeriodWithDetails,
  type InsertTeacher, type InsertSubject, type InsertRoom, type InsertClass, type InsertPeriod
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Teachers
  getTeachers(): Promise<Teacher[]>;
  getTeacher(id: number): Promise<Teacher | undefined>;
  createTeacher(teacher: InsertTeacher): Promise<Teacher>;
  updateTeacher(id: number, teacher: Partial<InsertTeacher>): Promise<Teacher | undefined>;
  deleteTeacher(id: number): Promise<boolean>;

  // Subjects
  getSubjects(): Promise<Subject[]>;
  getSubject(id: number): Promise<Subject | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  updateSubject(id: number, subject: Partial<InsertSubject>): Promise<Subject | undefined>;
  deleteSubject(id: number): Promise<boolean>;

  // Rooms
  getRooms(): Promise<Room[]>;
  getRoom(id: number): Promise<Room | undefined>;
  createRoom(room: InsertRoom): Promise<Room>;
  updateRoom(id: number, room: Partial<InsertRoom>): Promise<Room | undefined>;
  deleteRoom(id: number): Promise<boolean>;

  // Classes
  getClasses(): Promise<Class[]>;
  getClass(id: number): Promise<Class | undefined>;
  createClass(cls: InsertClass): Promise<Class>;
  updateClass(id: number, cls: Partial<InsertClass>): Promise<Class | undefined>;
  deleteClass(id: number): Promise<boolean>;

  // Periods
  getPeriods(): Promise<Period[]>;
  getPeriodsWithDetails(): Promise<PeriodWithDetails[]>;
  getPeriodsForClass(classId: number): Promise<PeriodWithDetails[]>;
  getPeriodsForTeacher(teacherId: number): Promise<PeriodWithDetails[]>;
  getPeriodsForRoom(roomId: number): Promise<PeriodWithDetails[]>;
  getPeriod(id: number): Promise<Period | undefined>;
  createPeriod(period: InsertPeriod): Promise<Period>;
  updatePeriod(id: number, period: Partial<InsertPeriod>): Promise<Period | undefined>;
  deletePeriod(id: number): Promise<boolean>;

  // Conflict detection
  checkConflicts(period: InsertPeriod): Promise<string[]>;
}

export class MemStorage implements IStorage {
  private teachers: Map<number, Teacher> = new Map();
  private subjects: Map<number, Subject> = new Map();
  private rooms: Map<number, Room> = new Map();
  private classes: Map<number, Class> = new Map();
  private periods: Map<number, Period> = new Map();
  private currentIds = {
    teachers: 1,
    subjects: 1,
    rooms: 1,
    classes: 1,
    periods: 1,
  };

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Initialize with SVPHIS real data
    const sampleTeachers = [
      { name: "Ms. Anupama Chitrala", email: "anupama@svphis.edu", subject: "Mother Teacher" },
      { name: "Ms. Rekha Joshi", email: "rekha@svphis.edu", subject: "Mother Teacher" },
      { name: "Ms. Prabhavati Karigar", email: "prabhavati@svphis.edu", subject: "Mother Teacher" },
      { name: "Ms. Vidya Hiremath", email: "vidya@svphis.edu", subject: "Co-class teacher" },
      { name: "Ms. Ramya Upadhye", email: "ramya@svphis.edu", subject: "Kannada & Music" },
      { name: "Ms. Vinuta Patil", email: "vinuta@svphis.edu", subject: "Kannada" },
      { name: "Ms. Veena C Kamble", email: "veena@svphis.edu", subject: "English" },
      { name: "Ms. Bibi Hajira", email: "hajira@svphis.edu", subject: "Mathematics" },
      { name: "Ms. Laxmi Benakatti", email: "laxmi@svphis.edu", subject: "English & EVS" },
      { name: "Ms. Aishwarya Ganiger", email: "aishwarya@svphis.edu", subject: "EVS & Mathematics" },
      { name: "Ms. Kavya Ishwar", email: "kavya@svphis.edu", subject: "Mathematics" },
      { name: "Ms. Monica Halli", email: "monica@svphis.edu", subject: "English" },
      { name: "Ms. Basamma Olekar", email: "basamma@svphis.edu", subject: "Kannada" },
      { name: "Ms. Deepa Mahishi", email: "deepa@svphis.edu", subject: "Social Science" },
      { name: "Ms. Jyothi Kulkarni", email: "jyothi@svphis.edu", subject: "English" },
      { name: "Ms. Smita Sadanand", email: "smita@svphis.edu", subject: "English" },
      { name: "Ms. Ruksar Bareen Desai", email: "ruksar@svphis.edu", subject: "Biology & Chemistry" },
      { name: "Ms. Roopashree Navalgund", email: "roopashree@svphis.edu", subject: "Social Science" },
      { name: "Ms. Shailaja Lakshmeshwar", email: "shailaja@svphis.edu", subject: "Kannada" },
      { name: "Mr. Vishwanath S R", email: "vishwanath@svphis.edu", subject: "Physics & Chemistry" },
      { name: "Ms. Sunita Shinde", email: "sunita@svphis.edu", subject: "Mathematics" },
      { name: "Ms. Renuka Chulaki", email: "renuka.c@svphis.edu", subject: "EVS" },
      { name: "Ms. Renuka Benakatti", email: "renuka.b@svphis.edu", subject: "Hindi" },
      { name: "Dhariyappa S", email: "dhariyappa@svphis.edu", subject: "Physical Education" },
      { name: "Santosh S Gobbargumpi", email: "santosh@svphis.edu", subject: "Art & Craft" },
      { name: "Mr. Shashidhar Patil", email: "shashidhar@svphis.edu", subject: "Karate & Skating" },
      { name: "Ms. Chaitra Joshi", email: "chaitra@svphis.edu", subject: "Computer Science" },
      { name: "Ms. Waheeda Afrin", email: "waheeda@svphis.edu", subject: "Computer Science" },
      { name: "Librarian", email: "librarian@svphis.edu", subject: "Library" },
      { name: "Ms. Vedashree Marathe", email: "vedashree@svphis.edu", subject: "Dance" },
      { name: "Ms. Rajeshwari Kali", email: "rajeshwari@svphis.edu", subject: "Physical Education" },
      { name: "Ms. Vani Kulkarni", email: "vani@svphis.edu", subject: "Hindi" },
    ];

    const sampleSubjects = [
      { name: "Mathematics", color: "#3B82F6" },
      { name: "English", color: "#F59E0B" },
      { name: "Kannada", color: "#8B5CF6" },
      { name: "Hindi", color: "#EF4444" },
      { name: "Physics", color: "#10B981" },
      { name: "Chemistry", color: "#10B981" },
      { name: "Biology", color: "#10B981" },
      { name: "Social Science", color: "#8B5CF6" },
      { name: "EVS", color: "#10B981" },
      { name: "Computer Science", color: "#6366F1" },
      { name: "Physical Education", color: "#EF4444" },
      { name: "Art & Craft", color: "#14B8A6" },
      { name: "Music", color: "#14B8A6" },
      { name: "Dance", color: "#F97316" },
      { name: "Yoga", color: "#84CC16" },
      { name: "Karate & Skating", color: "#F59E0B" },
      { name: "Library", color: "#6B7280" },
      { name: "Life Skills", color: "#EC4899" },
      { name: "CCA", color: "#8B5CF6" },
      { name: "Spoken English", color: "#F59E0B" },
    ];

    const sampleRooms = [
      { name: "Room 101", capacity: 35, type: "classroom" },
      { name: "Room 102", capacity: 35, type: "classroom" },
      { name: "Room 103", capacity: 35, type: "classroom" },
      { name: "Room 201", capacity: 35, type: "classroom" },
      { name: "Room 202", capacity: 35, type: "classroom" },
      { name: "Room 203", capacity: 35, type: "classroom" },
      { name: "Physics Lab", capacity: 25, type: "lab" },
      { name: "Chemistry Lab", capacity: 25, type: "lab" },
      { name: "Biology Lab", capacity: 25, type: "lab" },
      { name: "Computer Lab 1", capacity: 30, type: "lab" },
      { name: "Computer Lab 2", capacity: 30, type: "lab" },
      { name: "Gymnasium", capacity: 100, type: "gym" },
      { name: "Art Studio", capacity: 25, type: "studio" },
      { name: "Music Room", capacity: 25, type: "studio" },
      { name: "Dance Hall", capacity: 40, type: "studio" },
      { name: "Library", capacity: 50, type: "library" },
      { name: "Nursery Room", capacity: 20, type: "classroom" },
      { name: "LKG Room", capacity: 25, type: "classroom" },
      { name: "UKG Room", capacity: 25, type: "classroom" },
    ];

    const sampleClasses = [
      { name: "Nursery - Blooming Buds", grade: "Nursery", studentCount: 18 },
      { name: "LKG - Little Learners", grade: "LKG", studentCount: 22 },
      { name: "UKG - Creative Champs", grade: "UKG", studentCount: 24 },
      { name: "Gr.1 - Dhruva", grade: "1", studentCount: 30 },
      { name: "Gr.1 - Nachiketa", grade: "1", studentCount: 28 },
      { name: "Gr.2 - Da.Ra.Bendre", grade: "2", studentCount: 32 },
      { name: "Gr.2 - D.V.Gundappa", grade: "2", studentCount: 30 },
      { name: "Gr.3 - Gangubai Hanagal", grade: "3", studentCount: 28 },
      { name: "Gr.3 - Akka Mahadevi", grade: "3", studentCount: 26 },
      { name: "Gr.4 - Purandaradasaru", grade: "4", studentCount: 29 },
      { name: "Gr.5 - Abhimanyu", grade: "5", studentCount: 31 },
      { name: "Gr.6 - Bhagat Singh", grade: "6", studentCount: 33 },
      { name: "Gr.6 - Chandrashekar Azad", grade: "6", studentCount: 32 },
      { name: "Gr.7 - Sir M.V", grade: "7", studentCount: 30 },
      { name: "Gr.7 - APJ Abdul Kalam", grade: "7", studentCount: 28 },
      { name: "Gr.8 - Cap. Vikram Batra", grade: "8", studentCount: 25 },
      { name: "Gr.8 - Maj. Somnath Sharma", grade: "8", studentCount: 27 },
      { name: "Gr.8 - WC Deepika Misra", grade: "8", studentCount: 26 },
      { name: "Gr.9 - Rajaram Mohan Roy", grade: "9", studentCount: 24 },
      { name: "Gr.9 - Jyothiba Phule", grade: "9", studentCount: 23 },
    ];

    sampleTeachers.forEach(teacher => {
      this.teachers.set(this.currentIds.teachers, { ...teacher, id: this.currentIds.teachers });
      this.currentIds.teachers++;
    });

    sampleSubjects.forEach(subject => {
      this.subjects.set(this.currentIds.subjects, { ...subject, id: this.currentIds.subjects });
      this.currentIds.subjects++;
    });

    sampleRooms.forEach(room => {
      this.rooms.set(this.currentIds.rooms, { ...room, id: this.currentIds.rooms });
      this.currentIds.rooms++;
    });

    sampleClasses.forEach(cls => {
      this.classes.set(this.currentIds.classes, { ...cls, id: this.currentIds.classes });
      this.currentIds.classes++;
    });

    // Add some sample periods based on SVPHIS schedule (8:50 AM - 4:00 PM)
    const samplePeriods = [
      // Monday - Gr.1 Dhruva (Prayer time is school-wide, periods start from 9:40)
      { classId: 4, teacherId: 5, subjectId: 3, roomId: 1, dayOfWeek: 1, startTime: "09:40", endTime: "10:25" },
      { classId: 4, teacherId: 7, subjectId: 2, roomId: 1, dayOfWeek: 1, startTime: "10:25", endTime: "10:55" },
      { classId: 4, teacherId: 8, subjectId: 1, roomId: 1, dayOfWeek: 1, startTime: "11:15", endTime: "12:00" },
      { classId: 4, teacherId: 22, subjectId: 9, roomId: 1, dayOfWeek: 1, startTime: "12:00", endTime: "12:45" },
      { classId: 4, teacherId: 23, subjectId: 4, roomId: 1, dayOfWeek: 1, startTime: "12:45", endTime: "13:15" },
      { classId: 4, teacherId: 27, subjectId: 10, roomId: 10, dayOfWeek: 1, startTime: "13:45", endTime: "14:30" },
      { classId: 4, teacherId: 25, subjectId: 12, roomId: 13, dayOfWeek: 1, startTime: "14:30", endTime: "15:15" },
      { classId: 4, teacherId: 30, subjectId: 13, roomId: 14, dayOfWeek: 1, startTime: "15:15", endTime: "16:00" },
      
      // Tuesday - Gr.1 Nachiketa
      { classId: 5, teacherId: 6, subjectId: 3, roomId: 2, dayOfWeek: 2, startTime: "09:40", endTime: "10:25" },
      { classId: 5, teacherId: 9, subjectId: 2, roomId: 2, dayOfWeek: 2, startTime: "10:25", endTime: "10:55" },
      { classId: 5, teacherId: 8, subjectId: 1, roomId: 2, dayOfWeek: 2, startTime: "11:15", endTime: "12:00" },
      { classId: 5, teacherId: 10, subjectId: 9, roomId: 2, dayOfWeek: 2, startTime: "12:00", endTime: "12:45" },
      { classId: 5, teacherId: 23, subjectId: 4, roomId: 2, dayOfWeek: 2, startTime: "12:45", endTime: "13:15" },
      { classId: 5, teacherId: 28, subjectId: 10, roomId: 11, dayOfWeek: 2, startTime: "13:45", endTime: "14:30" },
      { classId: 5, teacherId: 25, subjectId: 12, roomId: 13, dayOfWeek: 2, startTime: "14:30", endTime: "15:15" },
      { classId: 5, teacherId: 30, subjectId: 13, roomId: 14, dayOfWeek: 2, startTime: "15:15", endTime: "16:00" },
      
      // Wednesday - Gr.6 Bhagat Singh
      { classId: 12, teacherId: 11, subjectId: 1, roomId: 4, dayOfWeek: 3, startTime: "09:40", endTime: "10:25" },
      { classId: 12, teacherId: 15, subjectId: 2, roomId: 4, dayOfWeek: 3, startTime: "10:25", endTime: "10:55" },
      { classId: 12, teacherId: 20, subjectId: 5, roomId: 7, dayOfWeek: 3, startTime: "11:15", endTime: "12:00" },
      { classId: 12, teacherId: 17, subjectId: 7, roomId: 9, dayOfWeek: 3, startTime: "12:00", endTime: "12:45" },
      { classId: 12, teacherId: 14, subjectId: 8, roomId: 4, dayOfWeek: 3, startTime: "12:45", endTime: "13:15" },
      { classId: 12, teacherId: 28, subjectId: 10, roomId: 10, dayOfWeek: 3, startTime: "13:45", endTime: "14:30" },
      { classId: 12, teacherId: 24, subjectId: 11, roomId: 12, dayOfWeek: 3, startTime: "14:30", endTime: "15:15" },
      { classId: 12, teacherId: 30, subjectId: 13, roomId: 14, dayOfWeek: 3, startTime: "15:15", endTime: "16:00" },
      
      // Thursday - Physical Education and special classes
      { classId: 4, teacherId: 31, subjectId: 11, roomId: 12, dayOfWeek: 4, startTime: "09:40", endTime: "10:25" },
      { classId: 5, teacherId: 31, subjectId: 11, roomId: 12, dayOfWeek: 4, startTime: "10:25", endTime: "10:55" },
      { classId: 12, teacherId: 24, subjectId: 11, roomId: 12, dayOfWeek: 4, startTime: "11:15", endTime: "12:00" },
      
      // Friday - Art & Craft and other subjects
      { classId: 4, teacherId: 25, subjectId: 12, roomId: 13, dayOfWeek: 5, startTime: "09:40", endTime: "10:25" },
      { classId: 5, teacherId: 25, subjectId: 12, roomId: 13, dayOfWeek: 5, startTime: "10:25", endTime: "10:55" },
      { classId: 12, teacherId: 25, subjectId: 12, roomId: 13, dayOfWeek: 5, startTime: "11:15", endTime: "12:00" },
      
      // Saturday - Special activities and reviews
      { classId: 4, teacherId: 8, subjectId: 1, roomId: 1, dayOfWeek: 6, startTime: "09:40", endTime: "10:25" },
      { classId: 5, teacherId: 9, subjectId: 2, roomId: 2, dayOfWeek: 6, startTime: "10:25", endTime: "10:55" },
      { classId: 12, teacherId: 15, subjectId: 2, roomId: 4, dayOfWeek: 6, startTime: "11:15", endTime: "12:00" },
    ];

    samplePeriods.forEach(period => {
      this.periods.set(this.currentIds.periods, { ...period, id: this.currentIds.periods });
      this.currentIds.periods++;
    });
  }

  // Teachers
  async getTeachers(): Promise<Teacher[]> {
    return Array.from(this.teachers.values());
  }

  async getTeacher(id: number): Promise<Teacher | undefined> {
    return this.teachers.get(id);
  }

  async createTeacher(teacher: InsertTeacher): Promise<Teacher> {
    const id = this.currentIds.teachers++;
    const newTeacher: Teacher = { ...teacher, id };
    this.teachers.set(id, newTeacher);
    return newTeacher;
  }

  async updateTeacher(id: number, teacher: Partial<InsertTeacher>): Promise<Teacher | undefined> {
    const existing = this.teachers.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...teacher };
    this.teachers.set(id, updated);
    return updated;
  }

  async deleteTeacher(id: number): Promise<boolean> {
    return this.teachers.delete(id);
  }

  // Subjects
  async getSubjects(): Promise<Subject[]> {
    return Array.from(this.subjects.values());
  }

  async getSubject(id: number): Promise<Subject | undefined> {
    return this.subjects.get(id);
  }

  async createSubject(subject: InsertSubject): Promise<Subject> {
    const id = this.currentIds.subjects++;
    const newSubject: Subject = { ...subject, id };
    this.subjects.set(id, newSubject);
    return newSubject;
  }

  async updateSubject(id: number, subject: Partial<InsertSubject>): Promise<Subject | undefined> {
    const existing = this.subjects.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...subject };
    this.subjects.set(id, updated);
    return updated;
  }

  async deleteSubject(id: number): Promise<boolean> {
    return this.subjects.delete(id);
  }

  // Rooms
  async getRooms(): Promise<Room[]> {
    return Array.from(this.rooms.values());
  }

  async getRoom(id: number): Promise<Room | undefined> {
    return this.rooms.get(id);
  }

  async createRoom(room: InsertRoom): Promise<Room> {
    const id = this.currentIds.rooms++;
    const newRoom: Room = { ...room, id };
    this.rooms.set(id, newRoom);
    return newRoom;
  }

  async updateRoom(id: number, room: Partial<InsertRoom>): Promise<Room | undefined> {
    const existing = this.rooms.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...room };
    this.rooms.set(id, updated);
    return updated;
  }

  async deleteRoom(id: number): Promise<boolean> {
    return this.rooms.delete(id);
  }

  // Classes
  async getClasses(): Promise<Class[]> {
    return Array.from(this.classes.values());
  }

  async getClass(id: number): Promise<Class | undefined> {
    return this.classes.get(id);
  }

  async createClass(cls: InsertClass): Promise<Class> {
    const id = this.currentIds.classes++;
    const newClass: Class = { ...cls, id };
    this.classes.set(id, newClass);
    return newClass;
  }

  async updateClass(id: number, cls: Partial<InsertClass>): Promise<Class | undefined> {
    const existing = this.classes.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...cls };
    this.classes.set(id, updated);
    return updated;
  }

  async deleteClass(id: number): Promise<boolean> {
    return this.classes.delete(id);
  }

  // Periods
  async getPeriods(): Promise<Period[]> {
    return Array.from(this.periods.values());
  }

  async getPeriodsWithDetails(): Promise<PeriodWithDetails[]> {
    const periods = Array.from(this.periods.values());
    return periods.map(period => ({
      ...period,
      teacher: this.teachers.get(period.teacherId)!,
      subject: this.subjects.get(period.subjectId)!,
      room: this.rooms.get(period.roomId)!,
      class: this.classes.get(period.classId)!,
    }));
  }

  async getPeriodsForClass(classId: number): Promise<PeriodWithDetails[]> {
    const periods = Array.from(this.periods.values()).filter(p => p.classId === classId);
    return periods.map(period => ({
      ...period,
      teacher: this.teachers.get(period.teacherId)!,
      subject: this.subjects.get(period.subjectId)!,
      room: this.rooms.get(period.roomId)!,
      class: this.classes.get(period.classId)!,
    }));
  }

  async getPeriodsForTeacher(teacherId: number): Promise<PeriodWithDetails[]> {
    const periods = Array.from(this.periods.values()).filter(p => p.teacherId === teacherId);
    return periods.map(period => ({
      ...period,
      teacher: this.teachers.get(period.teacherId)!,
      subject: this.subjects.get(period.subjectId)!,
      room: this.rooms.get(period.roomId)!,
      class: this.classes.get(period.classId)!,
    }));
  }

  async getPeriodsForRoom(roomId: number): Promise<PeriodWithDetails[]> {
    const periods = Array.from(this.periods.values()).filter(p => p.roomId === roomId);
    return periods.map(period => ({
      ...period,
      teacher: this.teachers.get(period.teacherId)!,
      subject: this.subjects.get(period.subjectId)!,
      room: this.rooms.get(period.roomId)!,
      class: this.classes.get(period.classId)!,
    }));
  }

  async getPeriod(id: number): Promise<Period | undefined> {
    return this.periods.get(id);
  }

  async createPeriod(period: InsertPeriod): Promise<Period> {
    const id = this.currentIds.periods++;
    const newPeriod: Period = { ...period, id };
    this.periods.set(id, newPeriod);
    return newPeriod;
  }

  async updatePeriod(id: number, period: Partial<InsertPeriod>): Promise<Period | undefined> {
    const existing = this.periods.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...period };
    this.periods.set(id, updated);
    return updated;
  }

  async deletePeriod(id: number): Promise<boolean> {
    return this.periods.delete(id);
  }

  async checkConflicts(period: InsertPeriod): Promise<string[]> {
    const conflicts: string[] = [];
    const periods = Array.from(this.periods.values());

    for (const existingPeriod of periods) {
      if (existingPeriod.dayOfWeek === period.dayOfWeek) {
        const existingStart = existingPeriod.startTime;
        const existingEnd = existingPeriod.endTime;
        const newStart = period.startTime;
        const newEnd = period.endTime;

        // Check for time overlap
        if (newStart < existingEnd && newEnd > existingStart) {
          // Teacher conflict
          if (existingPeriod.teacherId === period.teacherId) {
            const teacher = this.teachers.get(period.teacherId);
            conflicts.push(`Teacher ${teacher?.name} is already scheduled at this time`);
          }

          // Room conflict
          if (existingPeriod.roomId === period.roomId) {
            const room = this.rooms.get(period.roomId);
            conflicts.push(`Room ${room?.name} is already booked at this time`);
          }

          // Class conflict
          if (existingPeriod.classId === period.classId) {
            const cls = this.classes.get(period.classId);
            conflicts.push(`Class ${cls?.name} already has a period at this time`);
          }
        }
      }
    }

    return conflicts;
  }
}

export class DatabaseStorage implements IStorage {
  private initialized = false;

  private async initializeData() {
    if (this.initialized) return;
    
    // Check if data already exists
    const existingTeachers = await db.select().from(teachers);
    if (existingTeachers.length > 0) {
      this.initialized = true;
      return;
    }

    // Initialize with SVPHIS real data
    const sampleTeachers = [
      { name: "Ms. Anupama Chitrala", email: "anupama@svphis.edu", subject: "Mother Teacher" },
      { name: "Ms. Rekha Joshi", email: "rekha@svphis.edu", subject: "Mother Teacher" },
      { name: "Ms. Prabhavati Karigar", email: "prabhavati@svphis.edu", subject: "Mother Teacher" },
      { name: "Ms. Vidya Hiremath", email: "vidya@svphis.edu", subject: "Co-class teacher" },
      { name: "Ms. Ramya Upadhye", email: "ramya@svphis.edu", subject: "Kannada & Music" },
      { name: "Ms. Vinuta Patil", email: "vinuta@svphis.edu", subject: "Kannada" },
      { name: "Ms. Veena C Kamble", email: "veena@svphis.edu", subject: "English" },
      { name: "Ms. Bibi Hajira", email: "hajira@svphis.edu", subject: "Mathematics" },
      { name: "Ms. Laxmi Benakatti", email: "laxmi@svphis.edu", subject: "English & EVS" },
      { name: "Ms. Aishwarya Ganiger", email: "aishwarya@svphis.edu", subject: "EVS & Mathematics" },
      { name: "Ms. Kavya Ishwar", email: "kavya@svphis.edu", subject: "Mathematics" },
      { name: "Ms. Monica Halli", email: "monica@svphis.edu", subject: "English" },
      { name: "Ms. Basamma Olekar", email: "basamma@svphis.edu", subject: "Kannada" },
      { name: "Ms. Deepa Mahishi", email: "deepa@svphis.edu", subject: "Social Science" },
      { name: "Ms. Jyothi Kulkarni", email: "jyothi@svphis.edu", subject: "English" },
      { name: "Ms. Smita Sadanand", email: "smita@svphis.edu", subject: "English" },
      { name: "Ms. Ruksar Bareen Desai", email: "ruksar@svphis.edu", subject: "Biology & Chemistry" },
      { name: "Ms. Roopashree Navalgund", email: "roopashree@svphis.edu", subject: "Social Science" },
      { name: "Ms. Shailaja Lakshmeshwar", email: "shailaja@svphis.edu", subject: "Kannada" },
      { name: "Mr. Vishwanath S R", email: "vishwanath@svphis.edu", subject: "Physics & Chemistry" },
      { name: "Ms. Sunita Shinde", email: "sunita@svphis.edu", subject: "Mathematics" },
      { name: "Ms. Renuka Chulaki", email: "renuka.c@svphis.edu", subject: "EVS" },
      { name: "Ms. Renuka Benakatti", email: "renuka.b@svphis.edu", subject: "Hindi" },
      { name: "Dhariyappa S", email: "dhariyappa@svphis.edu", subject: "Physical Education" },
      { name: "Santosh S Gobbargumpi", email: "santosh@svphis.edu", subject: "Art & Craft" },
      { name: "Mr. Shashidhar Patil", email: "shashidhar@svphis.edu", subject: "Karate & Skating" },
      { name: "Ms. Chaitra Joshi", email: "chaitra@svphis.edu", subject: "Computer Science" },
      { name: "Ms. Waheeda Afrin", email: "waheeda@svphis.edu", subject: "Computer Science" },
      { name: "Librarian", email: "librarian@svphis.edu", subject: "Library" },
      { name: "Ms. Vedashree Marathe", email: "vedashree@svphis.edu", subject: "Dance" },
      { name: "Ms. Rajeshwari Kali", email: "rajeshwari@svphis.edu", subject: "Physical Education" },
      { name: "Ms. Vani Kulkarni", email: "vani@svphis.edu", subject: "Hindi" },
    ];

    const sampleSubjects = [
      { name: "Mathematics", color: "#3B82F6" },
      { name: "English", color: "#F59E0B" },
      { name: "Kannada", color: "#8B5CF6" },
      { name: "Hindi", color: "#EF4444" },
      { name: "Physics", color: "#10B981" },
      { name: "Chemistry", color: "#10B981" },
      { name: "Biology", color: "#10B981" },
      { name: "Social Science", color: "#8B5CF6" },
      { name: "EVS", color: "#10B981" },
      { name: "Computer Science", color: "#6366F1" },
      { name: "Physical Education", color: "#EF4444" },
      { name: "Art & Craft", color: "#14B8A6" },
      { name: "Music", color: "#14B8A6" },
      { name: "Dance", color: "#F97316" },
      { name: "Yoga", color: "#84CC16" },
      { name: "Karate & Skating", color: "#F59E0B" },
      { name: "Library", color: "#6B7280" },
      { name: "Life Skills", color: "#EC4899" },
      { name: "CCA", color: "#8B5CF6" },
      { name: "Spoken English", color: "#F59E0B" },
    ];

    const sampleRooms = [
      { name: "Room 101", capacity: 35, type: "classroom" },
      { name: "Room 102", capacity: 35, type: "classroom" },
      { name: "Room 103", capacity: 35, type: "classroom" },
      { name: "Room 201", capacity: 35, type: "classroom" },
      { name: "Room 202", capacity: 35, type: "classroom" },
      { name: "Room 203", capacity: 35, type: "classroom" },
      { name: "Physics Lab", capacity: 25, type: "lab" },
      { name: "Chemistry Lab", capacity: 25, type: "lab" },
      { name: "Biology Lab", capacity: 25, type: "lab" },
      { name: "Computer Lab 1", capacity: 30, type: "lab" },
      { name: "Computer Lab 2", capacity: 30, type: "lab" },
      { name: "Gymnasium", capacity: 100, type: "gym" },
      { name: "Art Studio", capacity: 25, type: "studio" },
      { name: "Music Room", capacity: 25, type: "studio" },
      { name: "Dance Hall", capacity: 40, type: "studio" },
      { name: "Library", capacity: 50, type: "library" },
      { name: "Nursery Room", capacity: 20, type: "classroom" },
      { name: "LKG Room", capacity: 25, type: "classroom" },
      { name: "UKG Room", capacity: 25, type: "classroom" },
    ];

    const sampleClasses = [
      { name: "Nursery - Blooming Buds", grade: "Nursery", studentCount: 18 },
      { name: "LKG - Little Learners", grade: "LKG", studentCount: 22 },
      { name: "UKG - Creative Champs", grade: "UKG", studentCount: 24 },
      { name: "Gr.1 - Dhruva", grade: "1", studentCount: 30 },
      { name: "Gr.1 - Nachiketa", grade: "1", studentCount: 28 },
      { name: "Gr.2 - Da.Ra.Bendre", grade: "2", studentCount: 32 },
      { name: "Gr.2 - D.V.Gundappa", grade: "2", studentCount: 30 },
      { name: "Gr.3 - Gangubai Hanagal", grade: "3", studentCount: 28 },
      { name: "Gr.3 - Akka Mahadevi", grade: "3", studentCount: 26 },
      { name: "Gr.4 - Purandaradasaru", grade: "4", studentCount: 29 },
      { name: "Gr.5 - Abhimanyu", grade: "5", studentCount: 31 },
      { name: "Gr.6 - Bhagat Singh", grade: "6", studentCount: 33 },
      { name: "Gr.6 - Chandrashekar Azad", grade: "6", studentCount: 32 },
      { name: "Gr.7 - Sir M.V", grade: "7", studentCount: 30 },
      { name: "Gr.7 - APJ Abdul Kalam", grade: "7", studentCount: 28 },
      { name: "Gr.8 - Cap. Vikram Batra", grade: "8", studentCount: 25 },
      { name: "Gr.8 - Maj. Somnath Sharma", grade: "8", studentCount: 27 },
      { name: "Gr.8 - WC Deepika Misra", grade: "8", studentCount: 26 },
      { name: "Gr.9 - Rajaram Mohan Roy", grade: "9", studentCount: 24 },
      { name: "Gr.9 - Jyothiba Phule", grade: "9", studentCount: 23 },
    ];

    // Insert data
    await db.insert(teachers).values(sampleTeachers);
    await db.insert(subjects).values(sampleSubjects);
    await db.insert(rooms).values(sampleRooms);
    await db.insert(classes).values(sampleClasses);

    // Add some sample periods with proper time structure
    const samplePeriods = [
      { classId: 1, teacherId: 5, subjectId: 3, roomId: 17, dayOfWeek: 1, startTime: "09:40", endTime: "10:25" },
      { classId: 1, teacherId: 7, subjectId: 2, roomId: 17, dayOfWeek: 1, startTime: "10:25", endTime: "10:55" },
      { classId: 4, teacherId: 8, subjectId: 1, roomId: 1, dayOfWeek: 1, startTime: "11:15", endTime: "12:00" },
      { classId: 4, teacherId: 22, subjectId: 9, roomId: 1, dayOfWeek: 1, startTime: "12:00", endTime: "12:45" },
      { classId: 4, teacherId: 23, subjectId: 4, roomId: 1, dayOfWeek: 1, startTime: "12:45", endTime: "13:15" },
      { classId: 4, teacherId: 27, subjectId: 10, roomId: 10, dayOfWeek: 1, startTime: "13:45", endTime: "14:30" },
      { classId: 4, teacherId: 25, subjectId: 12, roomId: 13, dayOfWeek: 1, startTime: "14:30", endTime: "15:15" },
      { classId: 4, teacherId: 30, subjectId: 13, roomId: 14, dayOfWeek: 1, startTime: "15:15", endTime: "16:00" },
    ];

    await db.insert(periods).values(samplePeriods);
    this.initialized = true;
  }

  async getTeachers(): Promise<Teacher[]> {
    await this.initializeData();
    return await db.select().from(teachers);
  }

  async getTeacher(id: number): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.id, id));
    return teacher || undefined;
  }

  async createTeacher(insertTeacher: InsertTeacher): Promise<Teacher> {
    const [teacher] = await db
      .insert(teachers)
      .values(insertTeacher)
      .returning();
    return teacher;
  }

  async updateTeacher(id: number, teacher: Partial<InsertTeacher>): Promise<Teacher | undefined> {
    const [updatedTeacher] = await db
      .update(teachers)
      .set(teacher)
      .where(eq(teachers.id, id))
      .returning();
    return updatedTeacher || undefined;
  }

  async deleteTeacher(id: number): Promise<boolean> {
    const result = await db.delete(teachers).where(eq(teachers.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getSubjects(): Promise<Subject[]> {
    return await db.select().from(subjects);
  }

  async getSubject(id: number): Promise<Subject | undefined> {
    const [subject] = await db.select().from(subjects).where(eq(subjects.id, id));
    return subject || undefined;
  }

  async createSubject(insertSubject: InsertSubject): Promise<Subject> {
    const [subject] = await db
      .insert(subjects)
      .values(insertSubject)
      .returning();
    return subject;
  }

  async updateSubject(id: number, subject: Partial<InsertSubject>): Promise<Subject | undefined> {
    const [updatedSubject] = await db
      .update(subjects)
      .set(subject)
      .where(eq(subjects.id, id))
      .returning();
    return updatedSubject || undefined;
  }

  async deleteSubject(id: number): Promise<boolean> {
    const result = await db.delete(subjects).where(eq(subjects.id, id));
    return result.rowCount > 0;
  }

  async getRooms(): Promise<Room[]> {
    return await db.select().from(rooms);
  }

  async getRoom(id: number): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.id, id));
    return room || undefined;
  }

  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const [room] = await db
      .insert(rooms)
      .values(insertRoom)
      .returning();
    return room;
  }

  async updateRoom(id: number, room: Partial<InsertRoom>): Promise<Room | undefined> {
    const [updatedRoom] = await db
      .update(rooms)
      .set(room)
      .where(eq(rooms.id, id))
      .returning();
    return updatedRoom || undefined;
  }

  async deleteRoom(id: number): Promise<boolean> {
    const result = await db.delete(rooms).where(eq(rooms.id, id));
    return result.rowCount > 0;
  }

  async getClasses(): Promise<Class[]> {
    return await db.select().from(classes);
  }

  async getClass(id: number): Promise<Class | undefined> {
    const [cls] = await db.select().from(classes).where(eq(classes.id, id));
    return cls || undefined;
  }

  async createClass(insertClass: InsertClass): Promise<Class> {
    const [cls] = await db
      .insert(classes)
      .values(insertClass)
      .returning();
    return cls;
  }

  async updateClass(id: number, cls: Partial<InsertClass>): Promise<Class | undefined> {
    const [updatedClass] = await db
      .update(classes)
      .set(cls)
      .where(eq(classes.id, id))
      .returning();
    return updatedClass || undefined;
  }

  async deleteClass(id: number): Promise<boolean> {
    const result = await db.delete(classes).where(eq(classes.id, id));
    return result.rowCount > 0;
  }

  async getPeriods(): Promise<Period[]> {
    return await db.select().from(periods);
  }

  async getPeriodsWithDetails(): Promise<PeriodWithDetails[]> {
    return await db.query.periods.findMany({
      with: {
        teacher: true,
        subject: true,
        room: true,
        class: true,
      },
    });
  }

  async getPeriodsForClass(classId: number): Promise<PeriodWithDetails[]> {
    return await db.query.periods.findMany({
      where: eq(periods.classId, classId),
      with: {
        teacher: true,
        subject: true,
        room: true,
        class: true,
      },
    });
  }

  async getPeriodsForTeacher(teacherId: number): Promise<PeriodWithDetails[]> {
    return await db.query.periods.findMany({
      where: eq(periods.teacherId, teacherId),
      with: {
        teacher: true,
        subject: true,
        room: true,
        class: true,
      },
    });
  }

  async getPeriodsForRoom(roomId: number): Promise<PeriodWithDetails[]> {
    return await db.query.periods.findMany({
      where: eq(periods.roomId, roomId),
      with: {
        teacher: true,
        subject: true,
        room: true,
        class: true,
      },
    });
  }

  async getPeriod(id: number): Promise<Period | undefined> {
    const [period] = await db.select().from(periods).where(eq(periods.id, id));
    return period || undefined;
  }

  async createPeriod(insertPeriod: InsertPeriod): Promise<Period> {
    const [period] = await db
      .insert(periods)
      .values(insertPeriod)
      .returning();
    return period;
  }

  async updatePeriod(id: number, period: Partial<InsertPeriod>): Promise<Period | undefined> {
    const [updatedPeriod] = await db
      .update(periods)
      .set(period)
      .where(eq(periods.id, id))
      .returning();
    return updatedPeriod || undefined;
  }

  async deletePeriod(id: number): Promise<boolean> {
    const result = await db.delete(periods).where(eq(periods.id, id));
    return result.rowCount > 0;
  }

  async checkConflicts(period: InsertPeriod): Promise<string[]> {
    const conflicts: string[] = [];
    
    // Check for teacher conflicts
    const teacherConflicts = await db.query.periods.findMany({
      where: eq(periods.teacherId, period.teacherId),
      with: {
        teacher: true,
        class: true,
      },
    });

    for (const conflict of teacherConflicts) {
      if (conflict.dayOfWeek === period.dayOfWeek && 
          conflict.startTime === period.startTime) {
        conflicts.push(`Teacher ${conflict.teacher.name} is already teaching ${conflict.class.name} at this time`);
      }
    }

    // Check for room conflicts
    const roomConflicts = await db.query.periods.findMany({
      where: eq(periods.roomId, period.roomId),
      with: {
        room: true,
        class: true,
      },
    });

    for (const conflict of roomConflicts) {
      if (conflict.dayOfWeek === period.dayOfWeek && 
          conflict.startTime === period.startTime) {
        conflicts.push(`Room ${conflict.room.name} is already occupied by ${conflict.class.name} at this time`);
      }
    }

    return conflicts;
  }
}

export const storage = new DatabaseStorage();
