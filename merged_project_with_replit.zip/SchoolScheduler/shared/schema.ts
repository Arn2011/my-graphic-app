import { pgTable, text, serial, integer, varchar, time } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  subject: varchar("subject", { length: 255 }).notNull(),
});

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  color: varchar("color", { length: 7 }).notNull(), // hex color
});

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  capacity: integer("capacity").notNull(),
  type: varchar("type", { length: 100 }).notNull(), // classroom, lab, gym, etc.
});

export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  grade: varchar("grade", { length: 50 }).notNull(),
  studentCount: integer("student_count").notNull(),
});

export const periods = pgTable("periods", {
  id: serial("id").primaryKey(),
  classId: integer("class_id").references(() => classes.id).notNull(),
  teacherId: integer("teacher_id").references(() => teachers.id).notNull(),
  subjectId: integer("subject_id").references(() => subjects.id).notNull(),
  roomId: integer("room_id").references(() => rooms.id).notNull(),
  dayOfWeek: integer("day_of_week").notNull(), // 1-5 (Monday-Friday)
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
});

export const insertTeacherSchema = createInsertSchema(teachers).omit({
  id: true,
});

export const insertSubjectSchema = createInsertSchema(subjects).omit({
  id: true,
});

export const insertRoomSchema = createInsertSchema(rooms).omit({
  id: true,
});

export const insertClassSchema = createInsertSchema(classes).omit({
  id: true,
});

export const insertPeriodSchema = createInsertSchema(periods).omit({
  id: true,
});

export type InsertTeacher = z.infer<typeof insertTeacherSchema>;
export type InsertSubject = z.infer<typeof insertSubjectSchema>;
export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type InsertClass = z.infer<typeof insertClassSchema>;
export type InsertPeriod = z.infer<typeof insertPeriodSchema>;

export type Teacher = typeof teachers.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type Room = typeof rooms.$inferSelect;
export type Class = typeof classes.$inferSelect;
export type Period = typeof periods.$inferSelect;

export type PeriodWithDetails = Period & {
  teacher: Teacher;
  subject: Subject;
  room: Room;
  class: Class;
};

// Relations
export const teachersRelations = relations(teachers, ({ many }) => ({
  periods: many(periods),
}));

export const subjectsRelations = relations(subjects, ({ many }) => ({
  periods: many(periods),
}));

export const roomsRelations = relations(rooms, ({ many }) => ({
  periods: many(periods),
}));

export const classesRelations = relations(classes, ({ many }) => ({
  periods: many(periods),
}));

export const periodsRelations = relations(periods, ({ one }) => ({
  teacher: one(teachers, {
    fields: [periods.teacherId],
    references: [teachers.id],
  }),
  subject: one(subjects, {
    fields: [periods.subjectId],
    references: [subjects.id],
  }),
  room: one(rooms, {
    fields: [periods.roomId],
    references: [rooms.id],
  }),
  class: one(classes, {
    fields: [periods.classId],
    references: [classes.id],
  }),
}));
